�undefined               F  �     �B    /************************************************
Copyright (c) 2013-2017 by Progress Software Corporation 
and/or one of its subsidiaries or affiliates. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : Assert
    Purpose     : General assertions of truth. 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Wed Mar 03 10:08:57 EST 2010
    Notes       : * This version based on the AutoEdge|TheFactory version 
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.Assertion.AssertArray.
using OpenEdge.Core.Assertion.AssertObject.
using OpenEdge.Core.AssertionFailedError.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.DataTypeEnum.
using Progress.Lang.Object.

class OpenEdge.Core.Assert:
    
    method public static void Equals(input a as Object, input b as Object):
        AssertObject:Equals(a, b).
    end method.
    
    method public static void Equals(input a as rowid, input b as rowid):
        define variable failMessage as character no-undo.
        if not a = b then
        do:
            failMessage = substitute("Expected: &1 but was: &2", a, b).
            return error new AssertionFailedError(failMessage, 0).
        end.        
    end method.
    
    method public static void Equals(input a as recid, input b as recid):
        define variable failMessage as character no-undo.
        if not a = b then
        do:
            failMessage = substitute("Expected: &1 but was: &2", a, b).
            return error new AssertionFailedError(failMessage, 0).
        end.        
    end method.
    
    method public static void Equals(input a as handle, input b as handle):
        define variable failMessage as character no-undo.
        if not a = b then
        do:
            failMessage = substitute("Expected: &1 but was: &2", a, b).
            return error new AssertionFailedError(failMessage, 0).
        end.        
    end method.
    
    method public static void Equals(input a as longchar, input b as longchar):
        define variable failMessage as character no-undo.
        if not a = b then
        do:
            failMessage = substitute("Expected: &1 but was: &2", a, b).
            return error new AssertionFailedError(failMessage, 0).
        end.        
    end method.
    
    method public static void Equals(input a as decimal, input b as decimal):
        define variable failMessage as character no-undo.
        if not a = b then
        do:
            failMessage = substitute("Expected: &1 but was: &2", a, b).
            return error new AssertionFailedError(failMessage, 0).
        end.        
    end method.
    
    method public static void Equals(input a as int64, input b as int64):
        define variable failMessage as character no-undo.
        if not a = b then
        do:
            failMessage = substitute("Expected: &1 but was: &2", a, b).
            return error new AssertionFailedError(failMessage, 0).
        end.        
    end method.
    
    method public static void Equals(input a as integer, input b as integer):
        define variable failMessage as character no-undo.
        if not a = b then
        do:
            failMessage = substitute("Expected: &1 but was: &2", a, b).
            return error new AssertionFailedError(failMessage, 0).
        end.
    end method.

    method public static void Equals(input a as character, input b as character):
        define variable failMessage as character no-undo.
        if not a = b then
        do:
            failMessage = substitute("Expected: &1 but was: &2", a, b).
            return error new AssertionFailedError(failMessage, 0).
        end.
    end method.

    method public static void Equals(input a as date, input b as date):
        if not a eq b then
            return error new AssertionFailedError(
                            substitute("Expected: &1 but was: &2", a, b), 
                                0).
    end method.

    method public static void Equals(input a as datetime, input b as datetime):
        if not a eq b then
            return error new AssertionFailedError(
                            substitute("Expected: &1 but was: &2", a, b), 
                                0).
    end method.

    method public static void Equals(input a as datetime-tz, input b as datetime-tz):
        if not a eq b then
            return error new AssertionFailedError(
                            substitute("Expected: &1 but was: &2", a, b), 
                                0).
    end method.
    
    method public static void Equals(input a as logical, input b as logical):
        if not a eq b then
            return error new AssertionFailedError(
                            substitute("Expected: &1 but was: &2", a, b), 
                                0).
    end method.
    
    method public static void NotEqual(input a as character, input b as character):
        if a eq b then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a, b), 0).
    end method.

    method public static void NotEqual(input a as decimal, input b as decimal):
        if a eq b then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a, b), 0).
    end method.

    method public static void NotEqual(input a as handle, input b as handle):
        if a eq b then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a, b), 0).
    end method.

    method public static void NotEqual(input a as int64, input b as int64):
        if a eq b then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a, b), 0).
    end method.

    method public static void NotEqual(input a as integer, input b as integer):
        if a eq b then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a, b), 0).
    end method.

    method public static void NotEqual(input a as longchar, input b as longchar):
        if a eq b then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a, b), 0).
    end method.

    method public static void NotEqual(input a as Object, input b as Object):
        AssertObject:NotEqual(a, b).
    end method.

    method public static void NotEqual(input a as recid, input b as recid):
        if a eq b then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a, b), 0).
    end method.

    method public static void NotEqual(input a as rowid, input b as rowid):
        if a eq b then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a, b), 0).
    end method.

    method public static void IsTrue(input a as logical):
        define variable failMessage as character no-undo.
        if not a then
        do:
            failMessage = "Expected: TRUE but was: FALSE".
            return error new AssertionFailedError(failMessage, 0).
        end.        

    end method.

    method public static void IsFalse(input a as logical):
        define variable failMessage as character no-undo.
        if a then
        do:
            failMessage = "Expected: FALSE but was: TRUE".
            return error new AssertionFailedError(failMessage, 0).
        end.        
    end method.
    
    method public static void NotNull(input poArgument as Object , pcName as char):
        AssertObject:NotNull(poArgument, pcName).
    end method.

    method public static void NotNull(input poArgument as Object):
        NotNull(poArgument, "argument").
    end method.
    
    method public static void IsNull(input poArgument as Object , input pcName as character):
        AssertObject:IsNull(poArgument, pcName).
    end method.

    method public static void IsNull(input poArgument as Object):
        IsNull(poArgument, "argument").
    end method.
    
    method public static void NotNull(input poArgument as Object extent, pcName as char):
        AssertObject:NotNull(poArgument, pcName).
    end method.

    method public static void NotNull(input poArgument as Object extent):
        NotNull(poArgument, "argument").
    end method.
    
    method public static void IsNull(input poArgument as Object extent, pcName as char):
        AssertObject:IsNull(poArgument, pcName).
    end method.
    
    method public static void IsNull(input poArgument as Object extent):
        IsNull(poArgument, "argument").
    end method.
    
    method public static void NotNull(pcArgument as character, pcName as character):
        if pcArgument eq ? then 
            undo, throw new AssertionFailedError(substitute('&1 cannot be unknown', pcName), 0).
    end method.

    method public static void NotNull(pcArgument as character):
        NotNull(pcArgument, "argument").
    end method.

    method public static void NotNull(prArgument as raw, pcName as character):
        if prArgument eq ? then 
            undo, throw new AssertionFailedError(substitute('&1 cannot be unknown', pcName), 0).
    end method.

    method public static void NotNull(prArgument as raw):
        NotNull(prArgument, 'argument').
    end method.

    method public static void IsNull(prArgument as raw, pcName as character):
        if prArgument ne ? then 
            undo, throw new AssertionFailedError(substitute('&1 must be unknown', pcName), 0).
    end method.

    method public static void IsNull(prArgument as raw):
        IsNull(prArgument, 'argument').
    end method.
    
    method public static void IsNull(input pcArgument as character, input pcName as character):
        if pcArgument ne ? then 
            undo, throw new AssertionFailedError(substitute('&1 must be unknown', pcName), 0).
    end method.
    
    method public static void IsNull(input pcArgument as character):
        IsNull(pcArgument, "argument").
    end method.
    
    method public static void NotNull(pcArgument as longchar, pcName as character):
        if pcArgument eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be unknown', pcName), 0).
    end method.

    method public static void NotNull(pcArgument as longchar):
        NotNull(pcArgument, "argument").
    end method.
    
    method public static void NotNullOrEmpty(input poArgument as ICollection, pcName as char):
        AssertObject:NotNullOrEmpty(poArgument, pcName).
    end method.

    method public static void NotNullOrEmpty(input poArgument as ICollection):
        NotNullOrEmpty(poArgument, "argument").
    end method.
    
    method public static void IsEmpty(input phArgument as handle, pcName as character):
        Assert:NotNull(phArgument, pcName).

        phArgument:find-first() no-error.
        Assert:NotAvailable(phArgument, pcName).
    end method.

    method public static void IsEmpty(input phArgument as handle):
        IsEmpty(phArgument, "argument").
    end method.
    
    method public static void NotEmpty(input phArgument as handle, pcName as character):
        Assert:NotNull(phArgument, pcName).

        phArgument:find-first() no-error.
        Assert:IsAvailable(phArgument, pcName).
    end method.

    /* Validates that the argument is empy (blank)
       @param character The value to check
       @throws AssertionFailedError */
    method public static void IsEmpty(input pcArgument as character):
        IsEmpty(pcArgument, "argument").
    end method.
    
    /* Validates that the argument is empy (blank)
       
       @param character The value to check
       @param character The name of the argument (for errors)
       @throws AssertionFailedError */
    method public static void IsEmpty(input pcArgument as longchar, input pcName as character):
        define variable iRawLength as int64 no-undo.
        
        Assert:NotNull(pcArgument, pcName).
        /* number of bytes in the argument */
        assign iRawLength = length(pcArgument, 'raw':u).
        
           /* no characters is pretty empty */
        if iRawLength gt 0 or
           /* TRIM converts everything to cpinternal, which may not be able to 'see' all the characters
              that are in the argument. So, if the lengths differ, then there's something that's not a space
              (strong assumption) and we're OK, Jack.
              If the lengths match, we are ok to convert and we try to trim. */
           (iRawLength eq length(pcArgument) and trim(pcArgument) ne '':u) then
            undo, throw new AssertionFailedError(substitute('&1 must be empty', pcName), 0).
    end method.
    
    method public static void NotEmpty(input phArgument as handle):
        NotEmpty(phArgument, "argument").
    end method.
    
    method public static void NotNullOrEmpty(input poArgument as IMap, pcName as char):
        AssertObject:NotNullOrEmpty(poArgument, pcName).
    end method.

    method public static void NotNullOrEmpty(input poArgument as IMap):
        NotNullOrEmpty(poArgument, "argument").
    end method.
    
    method public static void NotNullOrEmpty(input poArgument as Object extent, pcName as char):
        AssertObject:NotNullOrEmpty(poArgument, pcName).
    end method.

    method public static void NotNullOrEmpty(input poArgument as Object extent):
        NotNullOrEmpty(poArgument, "argument").
    end method.
    
    method public static void NotNullOrEmpty(pcArgument as character, pcName as character):
        define variable cLongCharArg as longchar no-undo.
        cLongCharArg = pcArgument.
        Assert:NotNullOrEmpty(cLongCharArg, pcName).
    end method.

    method public static void NotNullOrEmpty(pcArgument as character):
        NotNullOrEmpty(pcArgument, "argument").
    end method.
    
    method public static void NotNullOrEmpty(input pcArgument as character extent, pcName as character):
        define variable cLongCharArg as longchar no-undo.

        if extent(pcArgument) eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
        
        cLongCharArg = pcArgument[1].
        Assert:NotNullOrEmpty(cLongCharArg, pcName).
    end method.

    method public static void NotNullOrEmpty(input pcArgument as character extent):
        NotNullOrEmpty(pcArgument, "argument").
    end method.

    method public static void NotNull(input pcArgument as character extent, pcName as character):
        define variable cLongCharArg as longchar no-undo.

        if extent(pcArgument) eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
        
        cLongCharArg = pcArgument[1].
        Assert:NotNull(cLongCharArg, pcName).
    end method.

    method public static void NotNull(input pcArgument as character extent):
        NotNull(pcArgument, "argument").
    end method.
    
    method public static void NotEmpty(pcArgument as longchar, pcName as character):
        define variable iRawLength as int64 no-undo.
        
        /* number of bytes in the argument */
        assign iRawLength = length(pcArgument, 'raw':u).
        
           /* no characters is pretty empty */
        if iRawLength eq 0 or
           /* TRIM converts everything to cpinternal, which may not be able to 'see' all the characters
              that are in the argument. So, if the lengths differ, then there's something that's not a space
              (strong assumption) and we're OK, Jack.
              If the lengths match, we are ok to convert and we try to trim. */
           (iRawLength eq length(pcArgument) and trim(pcArgument) eq '':u) then
            undo, throw new AssertionFailedError(substitute('&1 cannot be empty', pcName), 0).
    end method.

    method public static void NotEmpty(pcArgument as longchar):
        NotEmpty(pcArgument, "argument").
    end method.
    
    method public static void NotNullOrEmpty(pcArgument as longchar, pcName as character):
        Assert:NotNull(pcArgument, pcName).
        Assert:NotEmpty(pcArgument, pcName).
    end method.

    method public static void NotNullOrEmpty(pcArgument as longchar):
        NotNullOrEmpty(pcArgument, "argument").
    end method.
    
    method public static void NonZero(piArgument as integer, pcName as character):
        if piArgument eq 0 then
            undo, throw new AssertionFailedError(substitute('&1 cannot be zero', pcName), 0).
    end method.

    method public static void NonZero(piArgument as integer):
        NonZero(piArgument, "argument").
    end method.
    
    method public static void NonZero(piArgument as int64, pcName as character):
        if piArgument eq 0 then
            undo, throw new AssertionFailedError(substitute('&1 cannot be zero', pcName), 0).
    end method.
    
    method public static void NonZero(piArgument as int64):
        NonZero(piArgument, "argument").
    end method.
    
    method public static void NonZero(piArgument as integer extent, pcName as character):
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.

        AssertArray:HasDeterminateExtent(piArgument, pcName).
        iMax = extent(piArgument).
        do iLoop = 1 to iMax:
            Assert:NonZero(piArgument[iLoop], substitute('Extent &2 of &1', pcName, iLoop)).
        end.
    end method.

    method public static void NonZero(piArgument as integer extent):
        NonZero(piArgument, "argument").
    end method.
    
    method public static void NonZero(piArgument as int64 extent, pcName as character):
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.

        AssertArray:HasDeterminateExtent(piArgument, pcName).
        iMax = extent(piArgument).
        do iLoop = 1 to iMax:
            Assert:NonZero(piArgument[iLoop], substitute('Extent &2 of &1', pcName, iLoop)).
        end.
    end method.

    method public static void NonZero(piArgument as int64 extent):
        NonZero(piArgument, "argument").
    end method.
    
    method public static void NonZero(piArgument as decimal, pcName as character):
        if piArgument eq 0 then
            undo, throw new AssertionFailedError(substitute('&1 cannot be zero', pcName), 0).
    end method.

    method public static void NonZero(piArgument as decimal):
        NonZero(piArgument, "argument").
    end method.
    
    method public static void IsInterface(input poArgument as Progress.Lang.Class):
        AssertObject:IsInterface(poArgument).
    end method.

    method public static void NotInterface(input poArgument as Progress.Lang.Class):
        AssertObject:NotInterface(poArgument).
    end method.

    method public static void IsAbstract(input poArgument as Progress.Lang.Class):
         AssertObject:IsAbstract(poArgument).        
    end method.

    method public static void NotAbstract(input poArgument as Progress.Lang.Class):
        AssertObject:NotAbstract(poArgument).      
    end method.
        
    method public static void IsFinal(input poArgument as Progress.Lang.Class):
        AssertObject:IsFinal(poArgument). 
    end method.
    
    method public static void NotFinal(input poArgument as Progress.Lang.Class):
        AssertObject:NotFinal(poArgument).                       
    end method.
    
    method public static void IsType(input poArgument as Object extent, poType as Progress.Lang.Class):
        AssertObject:IsType(poArgument, poType).
    end method.
    
    method public static void IsType(input poArgument as Object, poType as Progress.Lang.Class):
        AssertObject:IsType(poArgument, poType).
    end method.
    
    method public static void NotType(input poArgument as Object, poType as Progress.Lang.Class):
        AssertObject:NotType(poArgument, poType).
    end method.
    
    /** Asserts that a handle is valid.
        
        @param handle The handle being checked.
        @param character The name of the handle/variable being checked. */
    method public static void NotNull(input phArgument as handle, input pcName as character):
        if not valid-handle(phArgument) then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.

    method public static void NotNull(input phArgument as handle):
        NotNull(phArgument, "argument").
    end method.
    
    /** Asserts that a handle is valid and of a particular datatype
        
        @param handle The handle being checked.
        @param DataTypeEnum The type the handle/variable being checked should be.
        @param character The name of the variable/handle.   */
    method public static void IsType(input phArgument as handle,
                                     input poCheckType as DataTypeEnum,
                                     input pcName as character):
        AssertObject:IsType(phArgument, poCheckType, pcName).        
    end method.

    method public static void IsType(input phArgument as handle,
                                     input poCheckType as DataTypeEnum):
        IsType(phArgument, poCheckType, "argument").
    end method.
    
    /** Asserts that a handle is valid and not of a particular datatype
        
        @param handle The handle being checked.
        @param DataTypeEnum The type the handle/variable being checked should be.
        @param character The name of the variable/handle.   */
    method public static void NotType(input phArgument as handle,
                                             input poCheckType as DataTypeEnum,
                                             input pcName as character):
        AssertObject:NotType(phArgument, poCheckType, pcName).
    end method.

    method public static void NotType(input phArgument as handle,
                                             input poCheckType as DataTypeEnum):
        NotType(phArgument, poCheckType, "argument").
    end method.
        
    method public static void IsNull(input phArgument as handle, input pcName as character):
        if valid-handle(phArgument) then
            undo, throw new AssertionFailedError(substitute('&1 must be null', pcName), 0).
    end method.
    
    method public static void IsNull(input phArgument as handle):
        IsNull(phArgument, "argument").
    end method.
    
    method public static void HasDeterminateExtent(input pcArgument as character extent,
                                                           input pcName as character):
        AssertArray:HasDeterminateExtent(pcArgument, pcName).
    end method.
    
    method public static void HasDeterminateExtent(input pcArgument as character extent):
        AssertArray:HasDeterminateExtent(pcArgument, "argument").
    end method.
    
    method public static void IsIndeterminateArray(input pcArgument as character extent,
                                                           input pcName as character):
        AssertArray:IsIndeterminateArray(pcArgument, pcName).
    end method.
    
    method public static void IsIndeterminateArray(input pcArgument as character extent):
        AssertArray:IsIndeterminateArray(pcArgument, "argument").
    end method.

    method public static void IsIndeterminateArray(input poArgument as Object extent,
                                                           input pcName as character):
        AssertArray:IsIndeterminateArray(poArgument, pcName).
    end method.
    
    method public static void HasDeterminateExtent(input poArgument as Object extent,
                                                           input pcName as character):
        AssertArray:HasDeterminateExtent(poArgument, pcName).
    end method.
    
    method public static void HasDeterminateExtent(input piArgument as integer extent,
                                                           input pcName as character):
        AssertArray:HasDeterminateExtent(piArgument, pcName).
    end method.

    method public static void HasDeterminateExtent(input piArgument as integer extent):
        AssertArray:HasDeterminateExtent(piArgument, "argument").
    end method.
    
    method public static void IsIndeterminateArray(input piArgument as integer extent,
                                                           input pcName as character):
        AssertArray:IsIndeterminateArray(piArgument, pcName).
    end method.

    method public static void IsIndeterminateArray(input piArgument as integer extent):
        AssertArray:IsIndeterminateArray(piArgument, "argument").
    end method.
    
    method public static void HasDeterminateExtent(input piArgument as int64 extent,
                                                           input pcName as character):
        AssertArray:HasDeterminateExtent(piArgument, pcName).
    end method.

    method public static void HasDeterminateExtent(input piArgument as int64 extent):
        AssertArray:HasDeterminateExtent(piArgument, "argument").
    end method.
    
    method public static void IsIndeterminateArray(input piArgument as int64 extent,
                                                           input pcName as character):
        AssertArray:IsIndeterminateArray(piArgument, pcName).
    end method.

    method public static void IsIndeterminateArray(input piArgument as int64 extent):
        AssertArray:IsIndeterminateArray(piArgument, "argument").
    end method.
    
    method public static void IsAvailable(input phArgument as handle,
                                          input pcName as character):
        Assert:NotNull(phArgument, pcName).
        
        if not phArgument:available then
            undo, throw new AssertionFailedError(substitute('record in buffer &1 is not available', pcName), 0).
    end method.

    method public static void IsAvailable(input phArgument as handle):
        IsAvailable(phArgument, "argument").
    end method.
       
    method public static void NotAvailable(input phArgument as handle,
                                           input pcName as character):
        Assert:NotNull(phArgument, pcName).

        if phArgument:available then
            undo, throw new AssertionFailedError(substitute('record in buffer &1 is available', pcName), 0).
    end method.

    method public static void NotAvailable(input phArgument as handle):
        NotAvailable(phArgument, "argument").
    end method.
    
    method public static void IsInteger(input pcArgument as character,
                                        input pcName as character):
        define variable iCheckVal as integer no-undo.

        iCheckVal = int(pcArgument) no-error.
        if error-status:error then
            undo, throw new AssertionFailedError(substitute('&1 is not an integer value', pcName), 0).
    end method.

    method public static void IsInteger(input pcArgument as character):
        IsInteger(pcArgument, "argument").
    end method.
    
    method public static void IsDecimal(input pcArgument as character,
                                        input pcName as character):
        define variable iCheckVal as integer no-undo.

        iCheckVal = decimal(pcArgument) no-error.
        if error-status:error then
            undo, throw new AssertionFailedError(substitute('&1 is not a decimal value', pcName), 0).
    end method.
    
    method public static void IsDecimal(input pcArgument as character):
        IsDecimal(pcArgument, "argument").
    end method.
        
    method public static void IsInt64(input pcArgument as character,
                                      input pcName as character):
        define variable iCheckVal as integer no-undo.

        iCheckVal = int64 (pcArgument) no-error.
        if error-status:error then
            undo, throw new AssertionFailedError(substitute('&1 is not an int64 value', pcName), 0).
    end method.

    method public static void IsInt64(input pcArgument as character):
       IsInt64(pcArgument, "argument").
    end method.
        
    method public static void IsTrue(input plArgument as logical,
                                     input pcName as character):
        /* deliberate not true */
        if not (plArgument eq true) then
            undo, throw new AssertionFailedError(substitute('&1 is not true', pcName), 0).
    end method.

    method public static void IsFalse(input plArgument as logical,
                                      input pcName as character):
        /* deliberate not false */
        if not (plArgument eq false) then
            undo, throw new AssertionFailedError(substitute('&1 is not false', pcName), 0).
    end method.
   
    method public static void IsUnknown(input plArgument as logical,
                                        input pcName as character):
        /* deliberate not ? */
        if not (plArgument eq ?) then
            undo, throw new AssertionFailedError(substitute('&1 is unknown', pcName), 0).
    end method.

    method public static void IsUnknown(input plArgument as logical):
       IsUnknown(plArgument, "argument").
    end method.
    
    method public static void NotTrue(input plArgument as logical,
                                      input pcName as character):
        if plArgument eq true then
            undo, throw new AssertionFailedError(substitute('&1 is true', pcName), 0).
    end method.

    method public static void NotTrue(input plArgument as logical):
        NotTrue(plArgument, "argument").
    end method.
    
    method public static void NotFalse(input plArgument as logical,
                                               input pcName as character):
        if plArgument eq false then
            undo, throw new AssertionFailedError(substitute('&1 is false', pcName), 0).
    end method.

    method public static void NotFalse(input plArgument as logical):
        NotFalse(plArgument, "argument").
    end method.
    
    method public static void NotUnknown(input plArgument as logical,
                                                 input pcName as character):
        if plArgument eq ? then
            undo, throw new AssertionFailedError(substitute('&1 is unknown', pcName), 0).
    end method.
    
    method public static void NotUnknown(input plArgument as logical):
        NotUnknown(plArgument, "argument").
    end method.
    
    method public static void NotNull(piArgument as integer, pcName as character):
        if piArgument eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.
    
    method public static void NotNull(piArgument as integer):
        NotNull(piArgument, "argument").
    end method.
    
    method public static void NotNull(input ptArgument as date, pcName as character):
        if ptArgument eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.

    method public static void NotNull(input ptArgument as date):
        NotNull(ptArgument, "argument").
    end method.
    
    method public static void NotNull(input ptArgument as datetime, pcName as character):
        if ptArgument eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.

    method public static void NotNull(input ptArgument as datetime):
        NotNull(ptArgument, "argument").
    end method.
    
    method public static void NotNull(input ptArgument as datetime-tz, pcName as character):
        if ptArgument eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.

    method public static void NotNull(input ptArgument as datetime-tz):
        NotNull(ptArgument, "argument").
    end method.
    
    method public static void IsNull(piArgument as integer, pcName as character):
        if piArgument ne ? then
            undo, throw new AssertionFailedError(substitute('&1 must be null', pcName), 0).
    end method.

    method public static void IsNull(piArgument as integer):
         IsNull(piArgument, "argument").
    end method.
        
    method public static void NotNull(piArgument as int64, pcName as character):
        if piArgument eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.

    method public static void NotNull(piArgument as int64):
        NotNull(piArgument, "argument").
    end method.
    
    method public static void IsNull(piArgument as int64, pcName as character):
        if piArgument ne ? then
            undo, throw new AssertionFailedError(substitute('&1 must be null', pcName), 0).
    end method.
    
    method public static void IsNull(piArgument as int64):
        IsNull(piArgument, "argument").
    end method.
        
    method public static void NotZero(piArgument as decimal, pcName as character):
        if piArgument eq 0 then
            undo, throw new AssertionFailedError(substitute('&1 cannot be zero', pcName), 0).
    end method.

    method public static void NotZero(piArgument as decimal):
       NotZero(piArgument, "argument").
    end method.
    
    method public static void NotNull(pdArgument as decimal, pcName as character):
        if pdArgument eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.

    method public static void NotNull(pdArgument as decimal):
        NotNull(pdArgument, "argument").
    end method.
    
    method public static void IsNull(pdArgument as decimal, pcName as character):
        if pdArgument ne ? then
            undo, throw new AssertionFailedError(substitute('&1 must be null', pcName), 0).
    end method.

    method public static void IsNull(pdArgument as decimal):
        IsNull(pdArgument, "argument").
    end method.
    
    method public static void NotNullOrZero(piArgument as integer, pcName as character):
        Assert:NotNull(piArgument, pcName).
        Assert:NotZero(piArgument, pcName).
    end method.

    method public static void NotNullOrZero(piArgument as integer):
        NotNullOrZero(piArgument, "argument").
    end method.
    
    method public static void NotZero(piArgument as integer, pcName as character):
        if piArgument eq 0 then
            undo, throw new AssertionFailedError(substitute('&1 cannot be zero', pcName), 0).
    end method.

    method public static void NotZero(piArgument as integer):
        NotZero(piArgument, "argument").
    end method.
    
    method public static void IsZero(piArgument as integer, pcName as character):
        if piArgument ne 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero', pcName), 0).
    end method.

    method public static void IsZero(piArgument as integer):
        IsZero(piArgument, "argument").
    end method.
        
    method public static void IsNegative(piArgument as integer, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument ge 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be negative', pcName), 0).
    end method.

    method public static void IsNegative(piArgument as integer):
        IsNegative(piArgument, "argument").
    end method.
        
    method public static void IsPositive(piArgument as integer, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument le 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be positive', pcName), 0).
    end method.

    method public static void IsPositive(piArgument as integer):
       IsPositive(piArgument, "argument").
    end method.
    
    method public static void IsZeroOrNegative(piArgument as integer, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument gt 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero or negative', pcName), 0).
    end method.
    
    method public static void IsZeroOrNegative(piArgument as integer):
        IsZeroOrNegative(piArgument, "argument").
    end method.
    
    method public static void IsZeroOrPositive(piArgument as integer, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument lt 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero or positive', pcName), 0).
    end method.

    method public static void IsZeroOrPositive(piArgument as integer):
        IsZeroOrPositive(piArgument, "argument").
    end method.
        
    method public static void NotZero(piArgument as int64, pcName as character):
        if piArgument eq 0 then
            undo, throw new AssertionFailedError(substitute('&1 cannot be zero', pcName), 0).
    end method.

    method public static void NotZero(piArgument as int64):
        NotZero(piArgument, "argument").
    end method.
        
    method public static void IsZero(piArgument as int64, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument ne 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero', pcName), 0).
    end method.

    method public static void IsZero(piArgument as int64):
        IsZero(piArgument, "argument").
    end method.
        
    method public static void IsNegative(piArgument as int64, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument ge 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be negative', pcName), 0).
    end method.

    method public static void IsNegative(piArgument as int64):
        IsNegative(piArgument, "argument").
    end method.
        
    method public static void IsPositive(piArgument as int64, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument le 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be positive', pcName), 0).
    end method.

    method public static void IsPositive(piArgument as int64):
        IsPositive(piArgument, "argument").
    end method.
    
    method public static void IsZeroOrNegative(piArgument as int64, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument gt 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero or negative', pcName), 0).
    end method.

    method public static void IsZeroOrNegative(piArgument as int64):
        IsZeroOrNegative(piArgument, "argument").
    end method.
        
    method public static void IsZeroOrPositive(piArgument as int64, pcName as character):
        NotNull(piArgument, pcName).
        if piArgument lt 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero or positive', pcName), 0).
    end method.    

    method public static void IsZeroOrPositive(piArgument as int64):
        IsZeroOrPositive(piArgument, "argument").
    end method.    
    
    method public static void IsZero(pdArgument as decimal, pcName as character):
        if pdArgument ne 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero', pcName), 0).
    end method.

    method public static void IsZero(pdArgument as decimal):
        IsZero(pdArgument, "argument").
    end method.
    
    method public static void IsNegative(pdArgument as decimal, pcName as character):
        NotNull(pdArgument, pcName).
        if pdArgument ge 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be negative', pcName), 0).
    end method.
    
    method public static void IsNegative(pdArgument as decimal):
        IsNegative(pdArgument, "argument").
    end method.
    
    method public static void IsPositive(pdArgument as decimal, pcName as character):
        NotNull(pdArgument, pcName).
        if pdArgument le 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be positive', pcName), 0).
    end method.

    method public static void IsPositive(pdArgument as decimal):
        IsPositive(pdArgument, "argument").
    end method.
    
    method public static void IsZeroOrNegative(pdArgument as decimal, pcName as character):
        NotNull(pdArgument, pcName).
        if pdArgument gt 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero or negative', pcName), 0).
    end method.
    
    method public static void IsZeroOrNegative(pdArgument as decimal):
        IsZeroOrNegative(pdArgument, "argument").
    end method.
    
    method public static void IsZeroOrPositive(pdArgument as decimal, pcName as character):
        NotNull(pdArgument, pcName).
        if pdArgument lt 0 then
            undo, throw new AssertionFailedError(substitute('&1 must be zero or positive', pcName), 0).
    end method.    

    method public static void IsZeroOrPositive(pdArgument as decimal):
        IsZeroOrPositive(pdArgument, "argument").
    end method.
    
    /* Asserts that the input value can be converted to a logical value 
    
       @param character A character expression to evaluate
       @param character The format mask for the logical value 
       @param character The name of the argument
       @throws AssertionFailedError */
    method public static void IsLogical(input pcValue as character, 
                                        input pcMask as character,
                                        input pcName as character):
        define variable lValue as logical no-undo.
        
        NotNullOrEmpty(pcMask, 'Format mask').
        
        assign lValue = logical(pcValue, pcMask) no-error.
        if error-status:error then
            undo, throw new AssertionFailedError(
                                    substitute('&1 does not evaluate to a logical value with mask &2',
                                        pcName,
                                        pcMask),
                                    0).
    end method.

    /* Asserts that the input value can be converted to a logical value with the
       default/built-in format mask (see doc) 
    
       @param character A character expression to evaluate
       @throws AssertionFailedError */
    method public static void IsLogical(input pcValue as character):
        IsLogical(pcValue, 'arg').
    end method.
    
    /* Asserts that the input value can be converted to a logical value with the
       default/built-in format mask (see doc) 
    
       @param character A character expression to evaluate
       @param character The name of the argument
       @throws AssertionFailedError */
    method public static void IsLogical(input pcValue as character, 
                                        input pcName as character):
        define variable lValue as logical no-undo.
        
        assign lValue = logical(pcValue) no-error.
        if error-status:error then
            undo, throw new AssertionFailedError(
                                    substitute('&1 does not evaluate to a logical value',
                                        pcName),
                                    0).
    end method.
    
    /** Raises an AssertionFailedError.
        
        @param mesg the message to be used for the AssertionFailedError
        @throws AssertionFailedError Error thrown */
    method public static void RaiseError(mesg as character):
        NotNull(mesg).
        return error new AssertionFailedError(mesg, 0).
    end method.
end class.
/************************************************
Copyright (c) 2014, 2017 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
   File        : AssertionFailedError
   Purpose     : The exception thrown when an assertion fails. 
   Syntax      : 
   Description : 
   Author(s)   : hgarapat
   Created     : Wed Jul 18 16:10:35 IST 2012
   Notes       : 
 ----------------------------------------------------------------------*/
BLOCK-LEVEL ON ERROR UNDO, THROW.

CLASS OpenEdge.Core.AssertionFailedError INHERITS Progress.Lang.AppError: 
    DEFINE VARIABLE exceptionMessage AS CHARACTER NO-UNDO.    
		
    CONSTRUCTOR PUBLIC AssertionFailedError (INPUT failMessage AS CHARACTER):
        this-object(failMessage, 0).
    END CONSTRUCTOR.
    
    CONSTRUCTOR PUBLIC AssertionFailedError (INPUT failMessage AS CHARACTER, INPUT val AS INTEGER):
        SUPER(failMessage, val).
        exceptionMessage = failMessage.
    END CONSTRUCTOR.
    
    METHOD PUBLIC CHARACTER GetMessage():
        RETURN exceptionMessage.
    END METHOD.
    
END CLASS./************************************************
Copyright (c) 2014-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ByteBucket
    Purpose     : An extensible bucket/container for byte-based data. The bucket
                  consists of temp-table with a RAW field 
    Author(s)   : pjudge
    Created     : Wed May 14 16:26:38 EDT 2014
    Notes       : * Bucket size is initially 3 x 30k records, and will expand
                    to contain whatever's passed in.
                  * Resize can be used to grow and shrink the number of rows in
                    the bucket. The number of rows cannot shrink below the number
                    needed to contain the current data (ie :Size ).
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.ByteBucket.
using OpenEdge.Core.HashAlgorithmEnum.
using OpenEdge.Core.ISupportInitialize.
using OpenEdge.Core.Memptr.
using OpenEdge.Core.String.
using OpenEdge.Core.Util.MathUtil.

class OpenEdge.Core.ByteBucket implements ISupportInitialize:
    // about 30k of data in a DITEM
    define static private property MAX_BYTES_PER_ROW as integer initial 0x7800  no-undo get.
    
    // the default number of initial rows 
    define private variable mInitialNumRecs as integer initial 3 no-undo.
    
    define static private temp-table MemptrData no-undo
        field ParentBucket  as int64
        field DataIndex     as int64
        field Data          as raw
        // the actual number of bytes written into this row. RAW may be up to 32-ish k in size, and we may re-use this row
        field BytesWritten  as integer
        index idx1 as primary unique ParentBucket DataIndex.
    
    // The current row index for this bucket. may correspond to the number of records in the TT 
    define private variable miCurrentDataIndex as int64 no-undo.
    
    /** The current read position */
    define public property Position as int64 no-undo get. set.
    
    /* global/stateful variable to avoid deep copies of memptrs being passed internally/this class */
    define private variable mmTempBytes as memptr no-undo.
    
    /** The initial size of the memptrs that are held in the Bucket's array. 
        Each memptr is the same size */
    define public property DefaultCapacity as int64 no-undo get. private set.
    
    /** Returns the size of the data in the bucket */    
    define public property Size as int64 no-undo get. private set.
    
    /** Constructor for a ByteBucket. Defaults to 2 memptrs of 16k each */
    constructor public ByteBucket():
        /* initialise to 3 16k memptrs */
        this-object(mInitialNumRecs).
    end method.
    
    /** Constructor for a ByteBucket
        @param int64 The size of each memptr in the array */
    @deprecated(since='11.7.0':u).
    constructor public ByteBucket(input piDefaultCapacity as int64):
        this-object(mInitialNumRecs).
    end constructor.
    
    destructor ByteBucket():
        Destroy().
    end destructor.
    
    /** Constructor for a ByteBucket
        
        @param integer  The initial size of the array (ie how many extents)
        @param int64 The size of each memptr in the array */
    @deprecated(since='11.7.0':u).
    constructor public ByteBucket(input piInitialSize as integer, input piDefaultCapacity as int64):
        this-object(piInitialSize).
    end constructor.
    
    /** Constructor for a ByteBucket
        
        @param integer The initial size of the bucket (ie how many 32k rows) */
    constructor public ByteBucket(input piInitialSize as integer):
        define variable loop as integer no-undo.
        define buffer data for MemptrData.
        
        Assert:IsPositive(piInitialSize, 'Initial size').
        
        assign miCurrentDataIndex          = 1
               this-object:Position        = 1
               this-object:DefaultCapacity = MAX_BYTES_PER_ROW
               mInitialNumRecs             = piInitialSize
               .
    end constructor.
    
    /** Factory method for creating a ByteBucket.
    
        @param integer  The initial size of the array (ie how many extents)
        @param int64 The size of each memptr in the array */
    method public static ByteBucket Instance(input piInitialSize as integer, input piDefaultCapacity as int64):
        define variable oBB as ByteBucket no-undo.
        
        assign oBB = new ByteBucket(piInitialSize, piDefaultCapacity).
        oBB:Initialize().
        
        return oBB. 
    end method.

    /** Factory method for creating a ByteBucket.
    
        @param int64 The size of each memptr in the array */
    method public static ByteBucket Instance(input piDefaultCapacity as int64):
        define variable oBB as ByteBucket no-undo.
        
        assign oBB = new ByteBucket(piDefaultCapacity).
        oBB:Initialize().
        
        return oBB. 
    end method.
    
    /** Factory method for creating a ByteBucket. */
    method public static ByteBucket Instance():
        define variable oBB as ByteBucket no-undo.
        
        assign oBB = new ByteBucket().
        oBB:Initialize().
        
        return oBB. 
    end method.
    
    /** Clears/resets the ByteBucket. Does not de-allocate the memory, just the
        various pointers/counters/cursors. */
    method public void Clear():
        define buffer data for MemptrData.
        
        assign this-object:Position = 1
               this-object:Size     = 0
               miCurrentDataIndex   = 1
               .
        for each data where data.ParentBucket eq int64(this-object):
            assign data.BytesWritten = 0.
        end.
        
        if get-size(mmTempBytes) gt 0 then
            set-size(mmTempBytes) = 0.
    end method.
    
    /** Default object initialization
        
        Clears and resizes the bucket's internals to the initial size (num records) */
    method public void Initialize():
        this-object:Clear().
        this-object:Resize(mInitialNumRecs).
    end method.
    
    /** Destroy/Shutdown/Anti-Initializer */
    method public void Destroy():
        define buffer data for MemptrData.
        
        assign this-object:Position = 1
               this-object:Size     = 0
               miCurrentDataIndex   = 1
               .
        for each data where data.ParentBucket eq int64(this-object):
            delete data.
        end.
        
        if get-size(mmTempBytes) gt 0 then
            set-size(mmTempBytes) = 0.
    end method.
    
    /** Resizes the internal 'array' of records.
        We can shrink down the number of rows, but not smaller than the 
        bucket's size. 
        
        @param integer The new size (number of extents) for the array */
    method public void ResizeArray(input piSize as integer):
        this-object:Resize(piSize).    
    end method.
    
    /** Resizes the internal 'array' of records.
        We can shrink down the number of rows, but not smaller than the 
        bucket's size in bytes. 
        
        @param integer The new size (number of records) for the internal structure */
    method public void Resize(input piSize as integer):
        define variable loop as integer no-undo.
        
        define buffer data for MemptrData.
        
        if piSize gt miCurrentDataIndex then
        do loop = (miCurrentDataIndex + 1) to piSize:
            if can-find(data where data.ParentBucket eq int64(this-object) and
                        data.DataIndex eq loop) then
                next.
            
            create data.
            assign data.ParentBucket = int64(this-object)
                   data.DataIndex    = loop
                   data.BytesWritten = 0
                   .
        end.
        else
        for each data where data.ParentBucket eq int64(this-object) and
                 data.DataIndex gt MathUtil:Ceiling(piSize / DefaultCapacity) and
                 data.BytesWritten eq 0:
            delete data.
        end.
        
        // the 'array' is now the input size 
        assign miCurrentDataIndex = piSize.
        
        return.
    end method.
    
    /** Copies all of the bytes from a memptr into this bucket. The
        caller is responsible for cleaning up the memptr.
    
        @param int64 The pointer to memory represented by a memptr (via get-pointer-value). 
        @param int64 The size of the memptr represented by the pointer value. */
    method public void PutBytes(input piPointerValue as int64,
                                input piSize as int64):
        // Nothing to do if there's no data
        if piSize eq 0 then
            return.
        
        Assert:IsPositive(piPointerValue, 'Pointer Value').
        Assert:IsPositive(piSize, 'Memptr Size').
        
        /* jiggery-pokery so we can reuse code without deep-copying memptr's all over the show */
        set-size(mmTempBytes) = 1. /* allocate a new 1-byte memptr */
        set-size(mmTempBytes) = 0. /* free this 1-byte memptr, which also clears the size */
        set-pointer-value(mmTempBytes) = piPointerValue.
        set-size(mmTempBytes) = piSize.
        
        /* Start at the first byte of the input memptr */
        WriteBytes(1, piSize).
        
        finally:
            /* First de-reference the mmTempBytes variable before
               calling SET-SIZE() = 0 on it. */
            set-pointer-value(mmTempBytes) = 0.
            if get-size(mmTempBytes) gt 0 then
                set-size(mmTempBytes) = 0.
        end finally.
    end method.
    
    /** Copies all of the bytes from a String object (longchar) into this bucket. 
        
        @param String The longchar containing the source data. */
    method public void PutString(input poData as String):
        Assert:NotNull(poData, 'String data').
        
        PutString(poData:Value, poData:Encoding).
    end method.
    
    /** Copies all of the bytes from a longchar into this bucket. 
        
        @param longchar The longchar containing the source data */
    method public void PutString(input pcData as longchar):
        PutString(pcData, 'utf-8':u).
    end method.
    
    /** Copies all of the bytes from a longchar into this bucket.
        
        @param longchar The longchar containing the source data 
        @param longchar The target codepage used to write data into the bucket. Defaults to UTF-8 */
    @deprecated(since="11.7.3", use="PutString(longchar,character)").
    method public void PutString(input pcData as longchar,
                                 input pcTargetCodepage as longchar):
        PutString(pcData, string(pcTargetCodepage)).
    end method.
    
    /** Copies all of the bytes from a longchar into this bucket.
        
        @param longchar The longchar containing the source data
        @param character The target codepage used to write data into the bucket. Defaults to UTF-8 */
    method public void PutString(input pcData as longchar,
                                 input pcTargetCodepage as character):
        define variable mData as memptr no-undo.
        
        // Nothing to do if there's no data
        if length(pcData, 'raw':u) eq 0 then
            return.
        
        if    pcTargetCodepage eq '':u
           or pcTargetCodepage eq ? 
        then
            assign pcTargetCodepage = 'UTF-8':u.
        
        copy-lob pcData to mData
                 // the source codepage is taken from the longchar itself
                 convert target codepage pcTargetCodepage.
        
        PutBytes(get-pointer-value(mData), get-size(mData)).
        
        finally:
            if get-size(mData) gt 0 then
                set-size(mData) = 0.
        end finally.
    end method.
    
    /** Copies all of the bytes from a Memptr instance into this bucket. The
        caller is responsible for cleaning up the memptr.
    
        @param OpenEdge.Core.Memptr The Memptr instance containing the data. */
    method public void PutBytes(input poData as class Memptr):
        Assert:NotNull(poData, 'Data').
        if poData:Size gt 0 then
            PutBytes(poData:GetPointerValue(), poData:Size).
    end method.

    /** Copies all of the bytes from a ByteBucket instance into this bucket. The
        caller is responsible for cleaning up the source ByteBucket.
            
        @param ByteBucket The ByteBucket instance containing the data. */
    method public void PutBytes(input poData as class ByteBucket):
        Assert:NotNull(poData, 'Input data').
        // Nothing to do if there's no data
        if poData:Size eq 0 then
            return.
        
        /* We use a static method because it gives us access to the private/
           internal members of both instances. We want to do this merge as 
           quickly as possible  */
        ByteBucket:MergeBuckets(poData, this-object).
    end method.
    
    /** Merges the contents of 2 ByteBuckets
    
        @param ByteBucket The source bucket (ie where we are copying FROM ) 
        @param ByteBucket The target bucket (ie where we are copying TO) */
    method static private void MergeBuckets (input poSource as ByteBucket,
                                             input poTarget as ByteBucket):
        define variable iLoop as integer no-undo.
        define variable iNumBytes as integer no-undo.
        define variable iPutAt as integer no-undo.
        define variable iStartIndex as integer no-undo.
        define variable iBytesLeft as integer no-undo.
        define variable iStartPos as integer no-undo.
        define variable mTemp as memptr no-undo.
        
        define buffer sourceData for MemptrData.
        
        assign iBytesLeft   = poSource:Size
               iPutAt       = 1
               iStartPos    = 1
               iStartIndex  = 1.
        
        for each sourceData where sourceData.ParentBucket eq int64(poSource)
                 while iBytesLeft gt 0:
            
            /* read the number of bytes. if we need to read the whole
               memptr, then do so. otherwise just the number of remaining
               bytes. */
            assign iNumBytes  = min(length(sourceData.Data, 'raw':u), iBytesLeft)
                   iBytesLeft = iBytesLeft - iNumBytes.

            /* jiggery-pokery so we can reuse code without deep-copying memptr's all over the show */
            set-size(poTarget:mmTempBytes)     = 1.  /* allocate a new 1-byte memptr */
            set-size(poTarget:mmTempBytes)     = 0.  /* free this 1-byte memptr, which also clears the size */
            set-size(poTarget:mmTempBytes)     = iNumBytes.
            
            if iNumBytes gt 0 then
            do:
                set-size(mTemp) = iNumBytes.
                assign mTemp = get-bytes(sourceData.Data, 1, iNumBytes).
                put-bytes(poTarget:mmTempBytes, 1) = mTemp.
                set-size(mTemp) = 0.
                
                /* Start at the first byte of the input memptr */
                poTarget:WriteBytes(1, iNumBytes).
            end.
            
            finally:
                if get-size(poTarget:mmTempBytes) gt 0 then
                    set-size(poTarget:mmTempBytes) = 0.
            end finally.
        end.
    end method.
    
    /** Copies all of the bytes from a memptr (primitive) into this bucket. The
        caller is responsible for cleaning up the memptr. 
    
        @param memptr The memptr containing the data. */
    method public void PutBytes(input pmData as memptr):
        // Nothing to do if there's no data
        if get-size(pmData) eq 0 then
            return.
        
        /* jiggery-pokery so we can reuse code without deep-copying memptr's all over the show */
        PutBytes(get-pointer-value(pmData), get-size(pmData)). 
    end method.
    
    /** Writes the contents/bytes of the currently-read memptr (mmTempBytes) 
        into this bucket. This method writes bytes until the current bucket is
        full, then resizes the bucket appropriately and calls itself. 
        
        @param int64 The start position in the memptr.
        @param int64 The number of bytes to write */
    method private void WriteBytes(input piStartPos as int64, 
                                   input piBytesLeft as int64):
        define variable iArrayLoop as integer no-undo.
        define variable iNumBytes as integer no-undo.
        define variable iByteLoop as integer no-undo.
        define variable iMaxBytes as integer no-undo.
        define variable mTemp as memptr no-undo.
        
        define buffer data for MemptrData.
        
        Assert:IsPositive(piStartPos,  'Start position').
        Assert:IsPositive(piBytesLeft, 'Num bytes left').
        
        do while piBytesLeft gt 0:
            // force the TT record out of scope so that there's nothing left-over for the next AVAILABLE check
            release data.
            
            if can-find (data where data.ParentBucket eq int64(this-object) and
                                    data.DataIndex    eq miCurrentDataIndex) 
            then
                find data where data.ParentBucket eq int64(this-object) and
                                data.DataIndex    eq miCurrentDataIndex.
            if not available data then
            do:
                create data.
                assign data.ParentBucket  = int64(this-object)
                       data.DataIndex     = miCurrentDataIndex
                       .
            end.
            
            // we can only write so many bytes into this record set
            assign iNumBytes = min(MAX_BYTES_PER_ROW - data.BytesWritten,
                                   piBytesLeft)
                   piBytesLeft = piBytesLeft - iNumBytes
                   .
            if iNumBytes gt 0 then
            do:
                // start writing at the end of the existing data
                // Use a local var to avoid PSC00295004 
                set-size(mTemp) = iNumBytes.
                assign mTemp = get-bytes(mmTempBytes, piStartPos, iNumBytes).
                
                put-bytes(data.Data, data.BytesWritten + 1) = mTemp.
                
                /* Increment */
                assign data.BytesWritten    = data.BytesWritten + iNumBytes
                       piStartPos           = piStartPos + iNumBytes
                       this-object:Position = this-object:Position + iNumBytes
                       this-object:Size     = this-object:Size + iNumBytes
                       .
                set-size(mTemp) = 0.
            end.
            // this record is full, move along
            if data.BytesWritten eq MAX_BYTES_PER_ROW then
                assign  miCurrentDataIndex = miCurrentDataIndex + 1.
        end.
    end method.
    
    /** Returns a byte at the current position , and increments the
        position marker.
        
        @return integer The byte value at the current position */
    method public integer GetByte():
        define variable iByte as integer no-undo.
        
        assign iByte                = GetByte(this-object:Position)
               this-object:Position = this-object:Position + 1.
        
        return iByte.
    end method.
    
    /** Returns a byte at the specified position, and increments the
        position marker.
        
        @param int64 The position at which to return the byte.
        @return integer The byte value at the current position */
    
    method public integer GetByte(input piStartPos as int64):
        define variable iStartIndex as integer no-undo.
        define variable iGetFrom as integer no-undo.
        
        define buffer data for MemptrData.
        
        Assert:IsPositive(piStartPos, 'Start position').
                
        assign iStartIndex  = MathUtil:Ceiling(piStartPos / DefaultCapacity)
               /* Figure out where to start in the array entry */
               iGetFrom     = piStartPos modulo DefaultCapacity.
        
        /* if get from is 0 then piStartPos is a multiple of DefaultCapacity (ie the last
           byte of a particular array). */
        if iGetFrom eq 0 then
            assign iGetFrom = DefaultCapacity.
        
        if can-find(data where data.ParentBucket eq int64(this-object) and
                               data.DataIndex    eq miCurrentDataIndex) 
        then
            find data where
                 data.ParentBucket eq int64(this-object) and
                 data.DataIndex    eq iStartIndex
                 .
        if available data then
            return get-byte(data.Data, iGetFrom).
        
        return 0.
    end method.
    
    /** Returns a string/character representation a particular number of bytes,
        from a given start position.
    
        @param int64 The start potision
        @param int64 The size of the data (in bytes) to return 
        @return longchar The character/string data requested     */
    method public longchar GetString(input piStartPos as int64,
                                     input piSliceSize as int64):
        return GetString(piStartPos, piSliceSize, session:cpinternal, 'UTF-8':u).         
    end method.

    /** Returns a string/character representation a particular number of bytes,
        from a given start position.
    
        @param  int64 The start potision
        @param  int64 The size of the data (in bytes) to return 
        @param  character The target codepage for the character data
        @return longchar The character/string data requested     */
    method public longchar GetString(input piStartPos as int64,
                                     input piSliceSize as int64,
                                     input pcTargetCodepage as character):
        return GetString(piStartPos, piSliceSize, session:cpinternal, pcTargetCodepage).                                                
    end method. 
                                                                                        
    /** Returns a string/character representation a particular number of bytes,
        from a given start position.
    
        @param  int64 The start potision
        @param  int64 The size of the data (in bytes) to return 
        @param  character The source codepage for the character data
        @param  character The target codepage for the character data
        @return longchar The character/string data requested     */
    method public longchar GetString(input piStartPos as int64,
                                     input piSliceSize as int64,
                                     input pcSourceCodepage as character,
                                     input pcTargetCodepage as character):
        define variable rawData as memptr no-undo.
        define variable stringData as longchar no-undo.
        
        Assert:IsPositive(piStartPos, 'Start position').
        Assert:IsZeroOrPositive(piSliceSize, 'Slice size').
        
        if    pcTargetCodepage eq '':u
           or pcTargetCodepage eq ? then
            assign pcTargetCodepage = 'utf-8':u.
        
        fix-codepage(stringData) = pcTargetCodepage.
        
        if    this-object:Size eq 0 
           or piSliceSize eq 0 then
            return stringData.
        
        if    pcSourceCodepage eq '':u
           or pcSourceCodepage eq ? then
            assign pcSourceCodepage = 'utf-8':u.
        
        set-size(rawData) = piSliceSize.
        
        ReadBytes(piStartPos, rawData).
        
        copy-lob from rawData to stringData
                 convert source codepage pcSourceCodepage
                         target codepage pcTargetCodepage.
        
        return stringData.
        finally:
            if get-size(rawData) gt 0 then
                set-size(rawData) = 0.
        end finally.
    end method.

    /** Returns a string/character representation a particular number of bytes,
        from the current Position.
    
        @param int64 The size of the data (in bytes) to return 
        @return longchar The character/string data requested     */
    method public longchar GetString(input piSliceSize as int64):
        return GetString(this-object:Position, piSliceSize).
    end method.
    
    /** Returns a string/character representation of the entire set of bytes.
        
        @return longchar The character/string data requested     */
    method public longchar GetString():
        return GetString(1, this-object:Size).
    end method.
    
    /** Returns the entire contents of this bucket as a Memptr instance.
    
        @return Memptr The complete bucket data */
    method public class Memptr GetBytes():
        return GetBytes(1, this-object:Size).
    end method.
    
    /** Returns a Memptr instance containing the specified number of bytes,
        starting at the current Position.
    
        @param int64 The number of bytes to return
        @return Memptr The complete bucket data */
    method public class Memptr GetBytes(input piSliceSize as int64):
        return GetBytes(this-object:Position, piSliceSize).
    end method.
    
    /** Returns a Memptr instance containing the specified number of bytes,
        starting at the specified postition.
    
        @param int64 The starting position
        @param int64 The number of bytes to return
        @return Memptr The complete bucket data */
    method public class Memptr GetBytes(input piStartPos as int64,
                                        input piSliceSize as int64):
        define variable data as memptr no-undo.
        
        /* return an empty Memptr */
        if    this-object:Size eq 0 
           or piSliceSize eq 0 
        then
            return Memptr:Empty.
        
        set-size(data) = piSliceSize.
        
        ReadBytes(piStartPos, data).
        
        return new Memptr(data).
        
        finally:
            if get-size(data) gt 0 then
                set-size(data) = 0.
        end finally.
    end method.
    
    /* Reads data from the internal TT records into a memptr
       for return by GetBytes() and GetString() and friends.
       
       - The caller is responsible for cleaning up the memptr.
       - The memptr size is also the number of bytes to read  
       
       @param int64  The start position to read
       @param memptr The memptr into which to read the data */
    method private void ReadBytes(input piStartPos as int64,
                                  input pData as memptr):
        define variable iLoop as integer no-undo.
        define variable iNumBytes as integer no-undo.
        define variable iPutAt as integer no-undo.
        define variable iStartIndex as integer no-undo.
        define variable iGetFrom as integer no-undo.
        define variable iBytesLeft as integer no-undo.
        define variable mTemp as memptr no-undo.
        
        define buffer data for MemptrData.
        
        Assert:IsPositive(piStartPos, 'Start position').                         
        
        assign iBytesLeft   = get-size(pData)   //piSliceSize
               iPutAt       = 1
               
               iStartIndex  = MathUtil:Ceiling(piStartPos / DefaultCapacity).
               
               /* Figure out where to start in the array entry */               
               iGetFrom     = piStartPos modulo DefaultCapacity.
        
        /* if get from is 0 then piStartPos is a multiple of DefaultCapacity (ie the last
           byte of a particular array). */
        if iGetFrom eq 0 then
            assign iGetFrom = DefaultCapacity.
        
        for each data where
                 data.ParentBucket eq int64(this-object) and
                 data.DataIndex    ge iStartIndex and
                 data.DataIndex    le miCurrentDataIndex
            while iBytesLeft gt 0:
            
            /* read the number of bytes. if we need to read the whole
               memptr, then do so. otherwise just the number of remaining
               bytes. */
            if iGetFrom eq DefaultCapacity then
                assign iNumBytes = 1.
            else
                /* we may have a get-from value somewhere in the middle */
                assign iNumBytes = min(data.BytesWritten - iGetFrom + 1, iBytesLeft).
            
            if iNumBytes gt 0 then
            do:
                // Use a local var to avoid PSC00295004 
                set-size(mTemp) = iNumBytes.
                assign mTemp = get-bytes(data.Data, iGetFrom, iNumBytes).
                
                put-bytes(pData, iPutAt) = mTemp.
                
                set-size(mTemp) = 0.
            end.
            
            assign iPutAt      = iPutAt     + iNumBytes
                   iBytesLeft  = iBytesLeft - iNumBytes
                   /* start from the beginning of the next chunk */
                   iGetFrom    = 1.
        end.
    end method.
    
    /* Debug method to dump out current RAW bytes into numbered files 
       Files are named bytebucket-memptr-<number>.bin */
    method public void Debug():
        define variable mTemp as memptr no-undo.
        define buffer data for MemptrData.
        
        for each data where data.ParentBucket eq int64(this-object):
            set-size(mTemp) = MAX_BYTES_PER_ROW.
            assign mTemp = data.Data.
            copy-lob from mTemp to file session:temp-dir + 'bytebucket-memptr-':u + string(data.DataIndex) + '.bin':u.
            finally:
                set-size(mTemp) = 0.
            end finally.
        end.
    end method.
    
    /** Returns a hash of the current contents of the memptr. This can be used
        for comparing memptr values quickly.  
        
        @return raw The hashed value of the memptr. */
    method public raw GetHash():
        return GetHash(HashAlgorithmEnum:MD5).
    end method.
    
    /** Returns a hash of the current contents of the memptr. This can be used
        for comparing memptr values quickly.  
        
        @param HashAlgorithmEnum The algorithm to use for the message
        @return raw The hashed value of the memptr. */
    method public raw GetHash(input poAlgorithm as HashAlgorithmEnum):
        Assert:NotNull(poAlgorithm, 'Algorithm').
        
        /* hash of all the bytes */
        return GetBytes():GetHash(poAlgorithm). 
    end method.
    
end class./************************************************
Copyright (c)  2013, 2015-2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : DataTypeEnum
    Purpose     : Enumeration of ABL datatypes
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Mon Mar 16 13:44:09 EDT 2009
    Notes       : * EnumMember numeric values taken from ADE
                  * This version based on the AutoEdgeTheFactory version
  ---------------------------------------------------------------------- */
block-level on error undo, throw.
  
enum OpenEdge.Core.DataTypeEnum:
    define enum       None               
                      
                      /* ABL Primitives */
                      Character          
                      CharacterArray     
                      LongChar           
                      LongCharArray      
                      Integer            
                      IntegerArray       
                      Int64              
                      Int64Array         
                      Decimal            
                      DecimalArray       
                      Logical            
                      LogicalArray       
                      Rowid              
                      RowidArray         
                      Recid              
                      RecidArray         
                      Date               
                      DateArray          
                      Datetime           
                      DatetimeArray      
                      DatetimeTZ         
                      DatetimeTZArray    
                      Raw                
                      RawArray           
                      Memptr             
                      MemptrArray        
                      Handle             
                      HandleArray        
                      BLOB               
                      CLOB               
                      ComHandle          
                      ComHandleArray     
                    
                      /* Data structures */
                      Dataset            
                      Buffer             
                      TempTable   
                      ClientPrincipal       
                    
                      /* User-defined types */
                      ProgressLangObject 
                      Enumeration        
                      Class              
                      ClassArray         
                
                      /* Streams */
                      Stream 
                    
                      /* Query Where clause 'types' */
                      RowState 
                    
                      /* XML */
                      XmlDocument 
                      XmlNodeRef
                      
                      
                      Default = Character.  
end enum.
/************************************************
Copyright (c)  2013, 2015-2016 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : DataTypeHelper
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Apr 09 15:21:48 EDT 2015
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.DataTypeEnum.

class OpenEdge.Core.DataTypeHelper:
    
    method static public character GetMask(input poDataType as DataTypeEnum):
        Assert:NotNull(poDataType, 'Data type').
        
        case poDataType:
            when DataTypeEnum:None               then return '':u.
            when DataTypeEnum:Character          then return 'Character':u.
            when DataTypeEnum:CharacterArray     then return 'Character Extent':u.
            when DataTypeEnum:LongChar           then return 'Longchar':u.
            when DataTypeEnum:LongCharArray      then return 'Longchar Extent':u.
            when DataTypeEnum:Integer            then return 'Integer':u.
            when DataTypeEnum:IntegerArray       then return 'Integer Extent':u.
            when DataTypeEnum:Int64              then return 'Int64':u.
            when DataTypeEnum:Int64Array         then return 'Int64 Extent':u.
            when DataTypeEnum:Decimal            then return 'Decimal':u.
            when DataTypeEnum:DecimalArray       then return 'Decimal Extent':u.
            when DataTypeEnum:Logical            then return 'Logical':u.
            when DataTypeEnum:LogicalArray       then return 'Logical Extent':u.
            when DataTypeEnum:Rowid              then return 'Rowid':u.
            when DataTypeEnum:RowidArray         then return 'Rowid Extent':u.
            when DataTypeEnum:Recid              then return 'Recid':u.
            when DataTypeEnum:RecidArray         then return 'Recid Extent':u.
            when DataTypeEnum:Date               then return 'Date':u.
            when DataTypeEnum:DateArray          then return 'Date Extent':u.
            when DataTypeEnum:Datetime           then return 'Datetime':u.
            when DataTypeEnum:DatetimeArray      then return 'Datetime Extent':u.
            when DataTypeEnum:DatetimeTZ         then return 'Datetime-TZ':u.
            when DataTypeEnum:DatetimeTZArray    then return 'Datetime-TZ Extent':u.
            when DataTypeEnum:Raw                then return 'Raw':u.
            when DataTypeEnum:RawArray           then return 'Raw Extent':u.
            when DataTypeEnum:Memptr             then return 'Memptr':u.
            when DataTypeEnum:MemptrArray        then return 'Memptr Extent':u.
            when DataTypeEnum:Handle             then return 'Handle':u.
            when DataTypeEnum:HandleArray        then return 'Handle Extent':u.
            when DataTypeEnum:Class              then return 'Class &1':u.
            when DataTypeEnum:ClassArray         then return 'Class &1 Extent':u.
            when DataTypeEnum:ProgressLangObject then return 'Progress.Lang.Object':u.
            when DataTypeEnum:BLOB               then return 'BLOB':u.
            when DataTypeEnum:CLOB               then return 'CLOB':u.
            when DataTypeEnum:ComHandle          then return 'Com-Handle':u.
            when DataTypeEnum:ComHandleArray     then return 'Com-Handle Extent':u.
            when DataTypeEnum:Dataset            then return 'Dataset':u.
            when DataTypeEnum:Buffer             then return 'Buffer':u.
            when DataTypeEnum:TempTable          then return 'Temp-Table':u.
            when DataTypeEnum:ClientPrincipal    then return 'Client-Principal':u.
            
            when DataTypeEnum:Enumeration        then return 'Enumeration':u.
            when DataTypeEnum:Stream             then return 'Stream':u.
            when DataTypeEnum:RowState           then return 'row-state':u.
            
            when DataTypeEnum:XmlNodeRef         then return 'x-noderef':u.
            when DataTypeEnum:XmlDocument        then return 'x-document':u.
        end.        
    end method.
          
    method static public logical IsPrimitive(poDataType as DataTypeEnum):
        define variable lPrimitive as logical no-undo.
        
        case poDataType:
            when DataTypeEnum:Class or
            when DataTypeEnum:ClassArray or
            when DataTypeEnum:ProgressLangObject or
            when DataTypeEnum:Enumeration or
            when DataTypeEnum:None then 
                lPrimitive = false.
            otherwise
                lPrimitive = true.
        end case.
        
        return lPrimitive.
    end method.
    
    method static public logical IsArray(input poDataType as DataTypeEnum):
        return (entry(num-entries(string(poDataType), ' ':u), string(poDataType), ' ':u) eq 'extent':u).
    end method.
    
    /** Mapping from ABL data type to XML Schema supported data types. Taken from 
        the Working With XML book from the documentation set.
        
        Note that the converse is not supported, since there are multiple ABL types
        that map to a single XML schema type.
        
        @param DataTypeEnum The ABL data type
        @return character The XML data type. */
    method static public character ToXmlSchemaType(input poDataType as DataTypeEnum):
        define variable cXmlSchemaType as character no-undo.
        
        case poDataType:
            when DataTypeEnum:BLOB       then assign cXmlSchemaType = 'base64Binary':u.
            when DataTypeEnum:Character  then assign cXmlSchemaType = 'string':u.
            when DataTypeEnum:CLOB       then assign cXmlSchemaType = 'string':u.
            when DataTypeEnum:ComHandle  then assign cXmlSchemaType = 'long':u.
            when DataTypeEnum:Date       then assign cXmlSchemaType = 'date':u.
            when DataTypeEnum:DateTime   then assign cXmlSchemaType = 'dateTime':u.
            when DataTypeEnum:DatetimeTZ then assign cXmlSchemaType = 'dateTime':u.
            when DataTypeEnum:Decimal    then assign cXmlSchemaType = 'decimal':u.
            when DataTypeEnum:Int64      then assign cXmlSchemaType = 'long':u.
            when DataTypeEnum:Integer    then assign cXmlSchemaType = 'int':u.
            when DataTypeEnum:Logical    then assign cXmlSchemaType = 'boolean':u.
            when DataTypeEnum:Raw        then assign cXmlSchemaType = 'base64Binary':u.
            when DataTypeEnum:Recid      then assign cXmlSchemaType = 'long':u.
            when DataTypeEnum:Rowid      then assign cXmlSchemaType = 'base64Binary':u.
            when DataTypeEnum:Handle     then assign cXmlSchemaType = 'long':u.
            /*@todo(task="question", action="decent default?").*/
            otherwise                         assign cXmlSchemaType = poDataType:ToString().
        end case.
        
        return cXmlSchemaType.
    end method.
                
end class./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : DateArrayHolder
    Purpose     : OO holder for an array of date values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.IDateArrayHolder.

class OpenEdge.Core.DateArrayHolder implements IDateArrayHolder: 

	define public property Value as date extent no-undo get. set. 
		
	constructor public DateArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public DateArrayHolder(input pValue as date extent):
        this-object().
        assign this-object:Value = pValue.
    end constructor.

    method override public character ToString():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cValue as character no-undo.
        define variable cDelim as character no-undo.
        
        assign iMax = extent(this-object:Value)
               cDelim = '':u. 
        do iLoop = 1 to iMax:
            assign cValue = substitute('&1&2&3':u,
                                cValue,
                                cDelim,
                                this-object:Value[iLoop])
                   cDelim = ',':u.
        end.
        
        return cValue.
    end method.

end class./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : DateHolder
    Purpose     : OO holder for a primitive ABL DATE value. 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-07-29
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.TimeStamp.
using Ccs.Common.Support.IDateHolder.

class OpenEdge.Core.DateHolder 
        implements IDateHolder:
             
    define variable moTimeStamp as TimeStamp no-undo.

    define public property Value as date no-undo
        get():
            return moTimeStamp:ToDate().
        end get.
    set(input pValue as date):
        assign moTimeStamp = new OpenEdge.Core.TimeStamp(pValue).
    end set.

	constructor public DateHolder(  ):
		super ().
	end constructor.
		
	constructor public DateHolder ( input pcTimeStamp as character ):
		super ().
		
		assign moTimeStamp = new OpenEdge.Core.TimeStamp(pcTimeStamp).
	end constructor.
		
	constructor public DateHolder ( input ptDate as date ):
		super().
		
		assign this-object:Value = ptDate.
	end constructor.

end class./************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : DateTimeAddIntervalEnum
    Purpose     : Enumeration of intervals for DATETIME and -TZ operations
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Mar 11 11:35:55 EST 2010
    Notes       : * Taken from ABL documentation
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

enum OpenEdge.Core.DateTimeAddIntervalEnum: 
    define enum       Default 
                      Years   
                      Months  
                      Weeks   
                      Days    
                      Hours   
                      Minutes 
                      Seconds 
                      Milliseconds .
end enum.
/************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : DateTimeArrayHolder
    Purpose     : OO holder for an array of datetime values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.IDateTimeArrayHolder.

class OpenEdge.Core.DateTimeArrayHolder implements IDateTimeArrayHolder: 

	define public property Value as datetime extent no-undo get. set. 
		
	constructor public DateTimeArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public DateTimeArrayHolder(input pValue as datetime extent):
        this-object().
        assign this-object:Value = pValue.
    end constructor.

    method override public character ToString():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cValue as character no-undo.
        define variable cDelim as character no-undo.
        
        assign iMax = extent(this-object:Value)
               cDelim = '':u. 
        do iLoop = 1 to iMax:
            assign cValue = substitute('&1&2&3':u,
                                cValue,
                                cDelim,
                                this-object:Value[iLoop])
                   cDelim = ',':u.
        end.
        
        return cValue.
    end method.

end class./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : DateTimeHolder
    Purpose     : OO holder for a primitive ABL DATE value. 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-07-29
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.TimeStamp.
using Ccs.Common.Support.IDateTimeHolder.

class OpenEdge.Core.DateTimeHolder 
        implements IDateTimeHolder:
             
    define variable moTimeStamp as TimeStamp no-undo.

    define public property Value as datetime no-undo
        get():
            return moTimeStamp:ToDateTime().
        end get.
    set(input pValue as datetime):
        assign moTimeStamp = new OpenEdge.Core.TimeStamp(pValue).
    end set.

	constructor public DateTimeHolder(  ):
		super ().
	end constructor.
		
	constructor public DateTimeHolder ( input pcTimeStamp as character ):
		super ().
		
		assign moTimeStamp = new OpenEdge.Core.TimeStamp(pcTimeStamp).
	end constructor.
		
	constructor public DateTimeHolder ( input ptDateTime as datetime ):
		super().
		
		assign this-object:Value = ptDateTime.
	end constructor.

end class./* *************************************************************************************************************************
Copyright (c) 2016 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : DateTimeTzArrayHolder
    Purpose     : OO holder for an array of datetime values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.IDateTimeTzArrayHolder.

class OpenEdge.Core.DateTimeTzArrayHolder implements IDateTimeTzArrayHolder: 

	define public property Value as datetime-tz extent no-undo get. set. 
		
	constructor public DateTimeTzArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public DateTimeTzArrayHolder(input pValue as datetime-tz extent):
        this-object().
        assign this-object:Value = pValue.
    end constructor.

    method override public character ToString():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cValue as character no-undo.
        define variable cDelim as character no-undo.
        
        assign iMax = extent(this-object:Value)
               cDelim = '':u. 
        do iLoop = 1 to iMax:
            assign cValue = substitute('&1&2&3':u,
                                cValue,
                                cDelim,
                                this-object:Value[iLoop])
                   cDelim = ',':u.
        end.
        
        return cValue.
    end method.

end class./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : DateTimeTzHolder
    Purpose     : OO holder for a primitive ABL DATE value. 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-07-29
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.TimeStamp.
using Ccs.Common.Support.IDateTimeTzHolder.

class OpenEdge.Core.DateTimeTzHolder 
        implements IDateTimeTzHolder:
             
    define variable moTimeStamp as TimeStamp no-undo.

    define public property Value as datetime-tz no-undo
        get():
            return moTimeStamp:ToDateTimeTz().
        end get.
    set(input pValue as datetime-tz):
        assign moTimeStamp = new OpenEdge.Core.TimeStamp(pValue).
    end set.

	constructor public DateTimeTzHolder(  ):
		super ().
	end constructor.
		
	constructor public DateTimeTzHolder ( input pcTimeStamp as character ):
		super ().
		
		assign moTimeStamp = new OpenEdge.Core.TimeStamp(pcTimeStamp).
	end constructor.
		
	constructor public DateTimeTzHolder ( input ptDateTime as datetime-tz ):
		super().
		
		assign this-object:Value = ptDateTime.
	end constructor.

end class./************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : Decimal
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Mon Jun 06 12:27:33 EDT 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using Ccs.Common.Support.IDecimalHolder.

class OpenEdge.Core.Decimal implements IDecimalHolder:
    define public property Value as decimal  no-undo get.
        private set.
        
    constructor public Decimal (input pdVal as decimal):
        assign this-object:Value = pdVal.
    end constructor.        

    method override public character ToString():
        return string(this-object:Value).
    end method.

end class./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : DecimalArrayHolder
    Purpose     : OO holder for an array of Decimal or int64 values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.IDecimalArrayHolder.

class OpenEdge.Core.DecimalArrayHolder implements IDecimalArrayHolder: 

	define public property Value as decimal extent no-undo get. set. 
		
	constructor public DecimalArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public DecimalArrayHolder(input piValue as decimal extent):
        this-object().
        assign this-object:Value = piValue.
    end constructor.

    method override public character ToString():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cValue as character no-undo.
        define variable cDelim as character no-undo.
        
        assign iMax = extent(this-object:Value)
               cDelim = '':u. 
        do iLoop = 1 to iMax:
            assign cValue = substitute('&1&2&3':u,
                                cValue,
                                cDelim,
                                this-object:Value[iLoop])
                   cDelim = ',':u.
        end.
        
        return cValue.
    end method.

end class./************************************************
Copyright (c) 2016-2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/* ------------------------------------------------------------------------
    File        : EventArgs
    Purpose     : Generic event arguments class, including static 'Empty'
                  option. 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Mon Jul 27 11:45:09 EDT 2009
    Notes       : * Using EventArgs allows us to extend arguments without
                    changing event signatures.
                  * this class is likely to be specialised, but there's no 
                    requirement for that to happen. although outside of 
                    'empty' this is a somewhat useless class :)
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.EventArgs.

class OpenEdge.Core.EventArgs serializable:

    /** A single instance of this class so that we don't have
        to pass nulls around (ie we can depend on there always being
        a value if we so desire).   */
    define static public property Empty as EventArgs 
        get():
            if not valid-object(EventArgs:Empty) then
                EventArgs:Empty = new EventArgs().
             
             return EventArgs:Empty.
        end.
        private set.
    
    constructor public EventArgs():
    end constructor.
    
end class.
/************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : HandleArrayHolder
    Purpose     : OO holder for an array of handle values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.IHandleArrayHolder.

class OpenEdge.Core.HandleArrayHolder implements IHandleArrayHolder: 

	define public property Value as handle extent no-undo get. set. 
		
	constructor public HandleArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public HandleArrayHolder(input pValue as handle extent):
        this-object().
        assign this-object:Value = pValue.
    end constructor.

end class./************************************************
Copyright (c)  2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : HashAlgorithmEnum
    Purpose     : Enumeration of ABL-supported digest algorithms, from the doc
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Mon Nov 03 15:00:23 EST 2014
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

enum OpenEdge.Core.HashAlgorithmEnum: 
    define enum       /* RSA Message Digest Hash Algorithm, 
                         returns a 16-byte RAW binary message digest value.*/
                      MD5     =  0
                      /*  United States Government Secure Hash Algorithm, 
                          returns a RAW 20-byte binary message digest value.*/
                      SHA-1
                      /*  United States Government Secure Hash Algorithm,
                          returns a RAW 32-byte binary message digest value.*/
                      SHA-256
                      /*  United States Government Secure Hash Algorithm, 
                          returns a RAW 64-byte binary message digest value.*/
                      SHA-512
                      .
end enum.
/************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : IAdaptable
    Purpose     : General interface for allowing classes to provide adapters
                  via the Adapter design pattern https://en.wikipedia.org/wiki/Adapter_pattern  
    Author(s)   : pjudge
    Created     : 2016-10-12
    Notes       : 
  ----------------------------------------------------------------------*/
interface OpenEdge.Core.IAdaptable:
    
    /* Returns an adapter for this message 
       
       @param P.L.Class The type we want to adapt to
       @return P.L.Object The adapter. SHOULD be of the type specified by the input argument */
    method public Progress.Lang.Object GetAdapter(input poAdaptTo as class Progress.Lang.Class).
    
end interface./************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : Integer
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Fri Jun 03 13:54:42 EDT 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using Ccs.Common.Support.IInt64Holder.

class OpenEdge.Core.Integer implements IInt64Holder: 

    define public property Value as int64 no-undo get. set.
        
    constructor public Integer(input piValue as int64):
        assign this-object:Value = piValue.
    end constructor.

    constructor public Integer(input piValue as integer):
        assign this-object:Value = piValue.
    end constructor.

    method override public character ToString():
        return string(this-object:Value).
    end method.
    
end class./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IntegerArrayHolder
    Purpose     : OO holder for an array of integer or int64 values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using Ccs.Common.Support.IInt64ArrayHolder.

class OpenEdge.Core.IntegerArrayHolder implements IInt64ArrayHolder: 
    define public property Value as int64 extent no-undo get. set. 
        
    constructor public IntegerArrayHolder (  ):
        super ().
    end constructor.

    constructor public IntegerArrayHolder (input piValue as int64 extent):
        this-object().
        assign  this-object:Value = piValue. 
    end constructor.
    
    constructor public IntegerArrayHolder(input piValue as integer extent):
        this-object().
        assign this-object:Value = piValue.
    end constructor.

    method override public character ToString():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cValue as character no-undo.
        define variable cDelim as character no-undo.
        
        assign iMax = extent(this-object:Value)
               cDelim = '':u. 
        do iLoop = 1 to iMax:
            assign cValue = substitute('&1&2&3':u,
                                cValue,
                                cDelim,
                                this-object:Value[iLoop])
                   cDelim = ',':u.
        end.
        
        return cValue.
    end method.

end class./************************************************
Copyright (c)  2013-2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : IOModeEnum
    Purpose     : IO Mode enumeration (for parameters). 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Fri Mar 20 11:22:58 EDT 2009
    Notes       : * This version based on the AutoEdge|TheFactory version
                  * The hyphenated versions are added since the underlying
                    values were always those, and the name shortened. Built-in
                    enums don't allow you to set these independently
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

enum OpenEdge.Core.IOModeEnum flags:
    
    define enum // directions
                Input
                Output
                Return
                
                // modifiers
                Append
                Bind
                
                By-Reference
                ByReference = By-Reference
                
                By-Value
                ByValue = By-Value
                
                Default = Input
                
                // supported combos
                Input-By-Reference = Input, ByReference
                InputByReference   = Input-By-Reference
                
                Input-Bind = Input, Bind
                InputBind  = Input-Bind
                
                Output-By-Reference = Output, ByReference
                OutputByReference  = Output-By-Reference
                
                Output-Append = Output, Append
                OutputAppend  = Output-Append
                
                Output-Bind = Output, Bind
                OutputBind  = Output-Bind
                
                Input-Output = Input, Output
                InputOutput  = Input-Output
                
                Input-Output-By-Reference = Input, Output, ByReference
                InputOutputByReference    = Input-Output-By-Reference
                
                //@deprecated(since="11.7.2").
                Dataset-Handle
                
                //@deprecated(since="11.7.2").
                DatasetHandle  = Dataset-Handle
                
                //@deprecated(since="11.7.2").
                Dataset-Handle-By-Reference = DatasetHandle, ByReference
                //@deprecated(since="11.7.2").
                DatasetHandleByReference    = Dataset-Handle-By-Reference
                
                //@deprecated(since="11.7.2").
                Dataset-Handle-By-Value = DatasetHandle, ByValue
                //@deprecated(since="11.7.2").
                DatasetHandleByValue    = Dataset-Handle-By-Value
                
                //@deprecated(since="11.7.2").
                Table-Handle
                //@deprecated(since="11.7.2").
                TableHandle  = Table-Handle
                
                //@deprecated(since="11.7.2").
                Table-Handle-By-Reference = TableHandle, ByReference
                //@deprecated(since="11.7.2").
                TableHandleByReference    = Table-Handle-By-Reference
                
                //@deprecated(since="11.7.2").
                Table-Handle-By-Value = TableHandle, ByValue
                //@deprecated(since="11.7.2").
                TableHandleByValue    = Table-Handle-By-Value
                .
end enum./* *************************************************************************************************************************
Copyright (c) 2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
 /*------------------------------------------------------------------------
    File        : IOModeHelper
    Purpose     : Helper methods for the OpenEdge.Core.IoModeEnum enum
    Author(s)   : pjudge
    Created     : 2017-08-25
    Notes       : * This type is abstract to prevent instantiation
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.IOModeEnum.
using Progress.Lang.ParameterList.
using OpenEdge.Core.StringConstant.

class OpenEdge.Core.IOModeHelper abstract:
    
    /** Returns a formatted string representation of an IoMode, specific to
        the parameter type (ParamList, DYN-CALL etc).
        
        Defaults to a simple stringification of the enum.
        
        @param IOModeEnum The enumeration to format
        @param character The parameter type. Typically a type name (like Progress.Lang.ParameterList);
                         if unknown or empty, the default format is used.
        @return character A formated string value of the enumeration 
        @throws AssertionFailedError Thrown when an invalid enum is passed in */
    method static public character ToString(input pMode as IOModeEnum,
                                            input pParameterType as character):
        define variable dashPos as integer no-undo.
        define variable mode as character no-undo.
        
        Assert:NotNull(pMode, 'IO Mode').
        
        case pParameterType:
            // Per the doc on SetParameter, only the following are supported
            // "INPUT", "OUTPUT", "INPUT-OUTPUT", "OUTPUT APPEND", "OUTPUT BIND", "INPUT BY-REFERENCE", "OUTPUT BY-REFERENCE", 
            // "INPUT-OUTPUT BY-REFERENCE", and "INPUT BIND". 
            when get-class(ParameterList):TypeName then
                assign mode = substitute('&1&2&3 &4':u,
                                    string(pMode and IOModeEnum:Input),
                                    (if (pMode and IOModeEnum:InputOutput) eq IOModeEnum:InputOutput then '-':u else '':u),
                                    string(pMode and IOModeEnum:Output),
                                    string(pMode and (IOModeEnum:By-Reference or IOModeEnum:Append or IOModeEnum:Bind))).
            otherwise
                assign mode = string(pMode).
        end.
        
        Assert:NotNull(mode, 'Formatted IO Mode').
        
        // get the whitespace off
        return trim(mode).
    end method.
    
end class./************************************************
Copyright (c) 2017 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : ISupportEncoding
    Purpose     : Indicates whether a writer supports character encoding 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2017-01-27
    Notes       : 
  ----------------------------------------------------------------------*/
interface OpenEdge.Core.ISupportEncoding:
    
    /* Content encoding (eg utf-8) used by the implementer */ 
    define public property Encoding as character no-undo get. set.
    
end interface./************************************************
Copyright (c)  2015 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : ISupportInitialize
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Jan 28 22:55:39 EST 2015
    Notes       : 
  ----------------------------------------------------------------------*/
interface OpenEdge.Core.ISupportInitialize:  

    /* Initializer/Startup */
    method public void Initialize().
    
    /* Destroy/Shutdown/Anti-Initializer */
    method public void Destroy().
  
end interface./************************************************
Copyright (c)  2014, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : JsonDataTypeEnum
    Purpose     : Enumaeration of JSON data typed. Taken from the ABL doc. 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 05 16:42:01 EST 2014
    Notes       : Based on the values in Progress.Json.ObjectModel.JsonDataType
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

enum OpenEdge.Core.JsonDataTypeEnum :
    define enum       String      =  1 /* = JsonDataType:STRING */ 
                      Number   /* =  2 = JsonDataType:NUMBER */     
                      Boolean  /* =  3 = JsonDataType:BOOLEAN */
                      Object   /* =  4 = JsonDataType:OBJECT */
                      Array    /* =  5 = JsonDataType:ARRAY */
                      Null     /* =  6 = JsonDataType:NULL */
                      .
end enum.
/************************************************
Copyright (c) 2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : KeyValuePair
    Purpose     : Holds a key and value tuple/pair
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2017-08-30
    Notes       : * these are untyped values
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.KeyValuePair.
using OpenEdge.Core.String.
 
class OpenEdge.Core.KeyValuePair serializable:
    
    // (mandatory) The key for this tuple  
    define public property Key as Progress.Lang.Object no-undo get. private set.
    
    // The value for this tuple
    define public property Value as Progress.Lang.Object no-undo get. set.
    
    /* Default coonstructor.
       
       Private since we don't want to allow an object without a key */
    constructor private KeyValuePair ():
    end constructor.
    
    /* Constructor
       
       @param P.L.Object A key value */
    constructor public KeyValuePair (input pKey as Progress.Lang.Object):
        Assert:NotNull(pKey, 'Key').
        
        assign this-object:Key = pKey.
    end constructor.
    
    /* Constructor
    
       @param character A String key value
       @param P.L.Object A value associated with the key */
    constructor public KeyValuePair(input pcKey as character,
                                    input pValue as Progress.Lang.Object):
        this-object(new String(pcKey), pValue).
    end constructor.
    
    /* Constructor
    
       @param P.L.Object A key value
       @param P.L.Object A value associated with the key */
    constructor public KeyValuePair(input pKey as Progress.Lang.Object,
                                    input pValue as Progress.Lang.Object):
        this-object(pKey).
        
        assign this-object:Value = pValue.
    end constructor.
    
    /* Compares an input object to this instance
       Objects are equal if
       - they are the same instance, OR
       - they are both of type KeyValuePair AND
            the Key and Value values are equal
       
       @param P.L.Object  An object to compare
       @return logical TRUE if the input object matchs this object */
    method public override logical Equals(o as Progress.Lang.Object):
         define variable kvp as KeyValuePair no-undo.
         
         if o:Equals(this-object) then
             return true.
             
         if type-of(o, KeyValuePair) then
         do: 
             kvp = cast(o, KeyValuePair).
             return this-object:Key:Equals(kvp:Key) 
                    and 
                    this-object:Value:Equals(kvp:Value).
         end.
         
         return false.
    end method.
end class.
/************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LogicalArray
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Jun 08 21:05:28 EDT 2016
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.ILogicalArrayHolder.

class OpenEdge.Core.LogicalArray implements ILogicalArrayHolder: 

	define public property Value as logical extent no-undo get. private set.	 

    constructor public LogicalArray(input plVal as logical extent):
        assign this-object:Value = plVal.
    end constructor.

end class./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LogicalArrayHolder
    Purpose     : OO holder for an array of Decimal or int64 values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.ILogicalArrayHolder.

class OpenEdge.Core.LogicalArrayHolder implements ILogicalArrayHolder: 

	define public property Value as logical extent no-undo get. set. 
		
	constructor public LogicalArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public LogicalArrayHolder(input piValue as logical extent):
        this-object().
        assign this-object:Value = piValue.
    end constructor.

    method override public character ToString():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cValue as character no-undo.
        define variable cDelim as character no-undo.
        
        assign iMax = extent(this-object:Value)
               cDelim = '':u. 
        do iLoop = 1 to iMax:
            assign cValue = substitute('&1&2&3':u,
                                cValue,
                                cDelim,
                                this-object:Value[iLoop])
                   cDelim = ',':u.
        end.
        
        return cValue.
    end method.

end class./************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LogicalValue
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Mon Jun 06 12:27:33 EDT 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using Ccs.Common.Support.ILogicalHolder.

class OpenEdge.Core.LogicalValue implements ILogicalHolder:
    define public property Format as character no-undo get. set.
    
    define public property Value as logical  no-undo get.
        private set.
        
    constructor public LogicalValue(input plVal as logical):
        assign this-object:Value = plVal
               this-object:Format = 'yes/no':u.
    end constructor.

    method override public character ToString():
        return trim(string(this-object:Value, this-object:Format)).
    end method.
        
end class./************************************************
  Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LogLevelEnum
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Feb 24 10:00:26 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

enum OpenEdge.Core.LogLevelEnum:
    define enum     
                    // The highest possible rank and is intended to turn off logging.
                    OFF = 0 
                    // Severe errors that cause premature termination. Expect these to be immediately visible on a status console.
                    FATAL
                    // Other runtime errors or unexpected conditions. Expect these to be immediately visible on a status console.
                    ERROR
                    // Use of deprecated APIs, poor use of API, 'almost' errors, other runtime situations that are undesirable 
                    // or unexpected, but not necessarily "wrong". Expect these to be immediately visible on a status console.
                    WARN   
                    // Interesting runtime events (startup/shutdown). Expect these to be immediately visible on a console, 
                    // so be conservative and keep to a minimum.
                    INFO
                    // Detailed information on the flow through the system. Expect these to be written to logs only.
                    DEBUG
                    // Most detailed information. Expect these to be written to logs only.
                    TRACE
                .
end enum./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LongcharArrayHolder
    Purpose     : OO holder for an array of character or long values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/
using Ccs.Common.Support.ILongcharArrayHolder.

block-level on error undo, throw.

class OpenEdge.Core.LongcharArrayHolder implements ILongcharArrayHolder: 
	define public property Value as longchar extent no-undo get. set. 
		
	constructor public LongcharArrayHolder ( ):
		super ().
	end constructor.
	
	constructor public LongcharArrayHolder (input pcValue as longchar extent):
        this-object().
        assign this-object:Value = pcValue.
    end constructor.
    
    constructor public LongcharArrayHolder (input pcValue as character extent):
        this-object().
        assign this-object:Value = pcValue.
    end constructor.    
    
end class./************************************************
Copyright (c) 2014-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : Memptr
    Purpose     : Object representation of an ABL primitive MEMPTR. 
    Author(s)   : pjudge
    Created     : Wed Apr 02 16:42:15 EDT 2014
    Notes       : * The constructor with the memptr input is a deep copy/clone 
                    of the input memptr. The caller is responsible for cleanup
                    of that input memptr. If a shallow copy is desired, then the
                    (size, pointer-value) constructor should be used.
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using Ccs.Common.Support.IMemptrHolder.
using OpenEdge.Core.Assert.
using OpenEdge.Core.HashAlgorithmEnum.
using OpenEdge.Core.Memptr.
using OpenEdge.Core.StringConstant.
using Progress.Lang.AppError.

class OpenEdge.Core.Memptr implements IMemptrHolder:
    /**  the actual memptr under management here */
    define private variable mmValue as memptr no-undo.
    
    /** Indicates whether the memptr will be destroyed/cleared when this object
        is destroyed. Default is TRUE. */
    define public property AutoDestroy as logical initial true no-undo get. set.
    
    /** indicates whether the memory is being managed by  */
    define public property ExternalAllocation as logical no-undo get. private set.
    
    /** A public representation of the memptr. */
    define public property Value as memptr no-undo
        get():
            return mmValue.
        end get.
    
    /** The size of the current memptr */
    define public property Size as int64 no-undo
        get():
            return get-size(mmValue). 
        end get.
        set(input piSize as int64):
            if get-size(mmValue) eq 0 then
                set-size(mmValue) = piSize.
        end set.
    
    /** Returns a new, empty/null Memptr */
    define static public property Empty as class Memptr no-undo
        get().
            return new Memptr(0).
        end get.
    
    constructor protected Memptr():
        assign AutoDestroy = true
               ExternalAllocation = false.
    end constructor.
    
    /** Constructor.
    
        @param int64 The pointer to memory represented by a memptr (via get-pointer-value). 
        @param int64 The size of the memptr represented by the pointer value. */          
    constructor public Memptr(input piPtr as int64, input piSize as int64):
        /* this-object(piSize). - don't use this constructor, it calls set-size() */
        this-object().
        /* copy of code from this-object(size) constructor */
        Assert:IsZeroOrPositive(piSize, 'Size').
        set-pointer-value(mmValue) = piPtr.
        set-size(mmValue) = piSize.
        
        /* this is an externally-managed memptr. Caller is responsible for cleanup. */
        assign ExternalAllocation = true.
    end constructor.
    
    /** Constructor.
    
        @param int64 The size of the memptr to be created. */          
    constructor public Memptr(input piSize as int64):
        this-object().
        
        Assert:IsZeroOrPositive(piSize, 'Size').
        set-size(mmValue) = piSize.
    end constructor.
    
    /** Deep copy/clone of the input memptr. Caller is responsible for cleanup. */
    constructor public Memptr(input pmValue as memptr):
        this-object(get-size(pmValue)).
        
        if get-size(pmValue) gt 0 then 
            put-bytes(mmValue, 1) = pmValue.
    end constructor.
    
    /** Deep copy/clone of the input memptr. */
    constructor public Memptr(input prValue as raw):
        this-object(length(prValue)).
        
        if length(prValue) gt 0 then
            put-bytes(mmValue, 1) = prValue.
    end constructor.
    
    destructor public Memptr():
        if this-object:AutoDestroy then
        do:
            /* externally-allocated memptrs must let go of the pointer and THEN
               set size to zero */
            if this-object:ExternalAllocation then
                set-pointer-value(mmValue) = 0.
            if get-size(mmValue) gt 0 then
                set-size(mmValue) = 0.
        end.            
    end destructor.
    
    /** Returns the pointer value of the current memptr.
    
        @param int64 The pointer to memory represented by this memptr */ 
    method public int64 GetPointerValue():
        define variable iPtr as int64 no-undo.
        
        iPtr = get-pointer-value(mmValue).
        return iPtr.
    end method.
    
    /** Clears/resets the current memptr. Clears the memory and resets it to
        its former size. */
    method public void Clear():
        define variable iOldSize as integer no-undo.
        if not this-object:ExternalAllocation then
        do:
            assign iOldSize = this-object:Size.
            if get-size(mmValue) gt 0 then
                set-size(mmValue) = 0.
            set-size(mmValue) = iOldSize.
        end.
    end method.
    
    /** Returns a hash of the current contents of the memptr. This can be used
        for comparing memptr values quickly.  
        
        @return raw The hashed value of the memptr. */
    method public raw GetHash():
        return GetHash(HashAlgorithmEnum:MD5).
    end method.

    /** Returns a hash of the current contents of the memptr. This can be used
        for comparing memptr values quickly.  
        
        @param HashAlgorithmEnum The algorithm to use for the message
        @return raw The hashed value of the memptr. */
    method public raw GetHash(input poAlgorithm as HashAlgorithmEnum):
        Assert:NotNull(poAlgorithm, 'Algorithm').
        return message-digest(string(poAlgorithm), mmValue).
    end method.
    
    /** Returns a byte at the specified position
        
        @param int64 The position at which to return the byte.
        @return integer The byte value at the current position */
    method public integer GetByte(input piPos as int64):        
        Assert:IsPositive(piPos, 'Position').
        
        return get-byte(mmValue, piPos).        
    end method.

    /** Returns a string/character representation from a given start position,
        for the remainder of the data.
    
        @param  int64 The start potision
        @return longchar The character/string data requested     */
    method public longchar GetString(input piStartPos as int64):
        return GetString(piStartPos, this-object:Size - piStartPos + 1).
    end.

    /** Returns a string/character representation a particular number of bytes,
        from a given start position.
    
        @param  int64 The start potision
        @param  int64 The size of the data (in bytes) to return 
        @return longchar The character/string data requested     */
    method public longchar GetString(input piStartPos as int64,
                                     input piSliceSize as int64):
        return GetString(piStartPos, piSliceSize, session:cpinternal, 'UTF-8':u).
    end.
        
    /** Returns a string/character representation a particular number of bytes,
        from a given start position.
        
        @param  int64 The start potision
        @param  int64 The size of the data (in bytes) to return 
        @param  character The target codepage for the character data
        @return longchar The character/string data requested     */
    method public longchar GetString(input piStartPos as int64,
                                     input piSliceSize as int64,
                                     input pcTargetCodepage as character):
        return GetString(piStartPos, piSliceSize, session:cpinternal, pcTargetCodepage).                                         
    end method.
    
    /** Returns a string/character representation a particular number of bytes,
        from a given start position.
    
        @param  int64 The start potision
        @param  int64 The size of the data (in bytes) to return 
        @param  character The source codepage for the character data
        @param  character The target codepage for the character data
        @return longchar The character/string data requested     */
    method public longchar GetString(input piStartPos as int64,
                                     input piSliceSize as int64,
                                     input pcSourceCodepage as character,
                                     input pcTargetCodepage as character):
        define variable lcData as longchar no-undo.

        Assert:IsPositive(piStartPos, 'Start position').
        Assert:IsZeroOrPositive(piSliceSize, 'Slice size').
        Assert:NotNullOrEmpty(pcSourceCodepage, 'Source codepage').
        Assert:NotNullOrEmpty(pcTargetCodepage, 'Target codepage').
        
        fix-codepage(lcData) = pcTargetCodepage.
        
        if this-object:Size gt 0 then
            copy-lob from mmValue starting at piStartPos for piSliceSize
                     to lcData
                     convert
                        source codepage pcSourceCodepage 
                        target codepage pcTargetCodepage.
        
        return lcData.        
    end method.
    
    /** Returns a Memptr instance containing the specified number of bytes,
        starting at the current Position.
        
        @param int64 The number of bytes to return
        @return Memptr The complete data */
    method public class Memptr GetBytes(input piStartPos as int64):
        Assert:IsPositive(piStartPos, 'Start position').
        
        return GetBytes(piStartPos, this-object:Size - piStartPos).
    end method.
    
    /** Returns a Memptr instance containing the specified number of bytes,
        starting at the specified postition.
    
        @param int64 The starting position
        @param int64 The number of bytes to return
        @return Memptr The complete bucket data */
    method public class Memptr GetBytes(input piStartPos as int64,
                                        input piSliceSize as int64):
        define variable mSlice as memptr no-undo.
        define variable oSlice as class Memptr no-undo.
        
        Assert:IsPositive(piStartPos, 'Start position').
        Assert:IsPositive(piSliceSize, 'Slice size').
        
        /* return an empty Memptr */
        if    this-object:Size eq 0 
           or piSliceSize eq 0 then
            oSlice = new Memptr(0).
        else
        do:
            set-size(mSlice) = piSliceSize.
            
            assign mSlice = get-bytes(mmValue, piStartPos, piSliceSize)
                   oSlice = new Memptr(mSlice).
        end.
        
        return oSlice.
        finally:
            if get-size(mSlice) gt 0 then
                set-size(mSlice) = 0.
        end finally.
    end method.
    
    /** Copies all of the bytes from a memptr into this memptr. The
        caller is responsible for cleaning up the memptr.
    
        @param int64 The pointer to memory represented by a memptr (via get-pointer-value). 
        @param int64 The size of the memptr represented by the pointer value. */
    method public void PutBytes(input piPointerValue as int64,
                                input piSize as int64):
        define variable iLoop as integer no-undo.
        define variable mTemp as memptr no-undo.
        
        Assert:IsZeroOrPositive(piPointerValue, 'Pointer').
        Assert:IsZeroOrPositive(piSize, 'Size').
        
        if this-object:Size eq 0 then
           assign this-object:Size = piSize.
        else  
        if piSize gt this-object:Size then
            return error new AppError('Input memptr larger than available size', 0).
        
        set-size(mTemp) = 1. 
        set-size(mTemp) = 0. 
        set-pointer-value(mTemp) = piPointerValue.
        set-size(mTemp) = piSize.
        
        put-bytes(mmValue, 1) = mTemp.
        
        finally:
            set-pointer-value(mTemp) = 0.
            if get-size(mTemp) gt 0 then
                set-size(mTemp) = 0.
        end finally.
    end method.
    
    /** Copies all of the bytes from a memptr (primitive) into this bucket. The
        caller is responsible for cleaning up the memptr. 
    
        @param memptr The memptr containing the data. */
    method public void PutBytes(input pmData as memptr):
        /* jiggery-pokery so we can reuse code without deep-copying 
           memptr's all over the show */
        PutBytes(get-pointer-value(pmData), get-size(pmData)).
    end method.
    
    /** Copies all of the bytes from a raw into this memptr. 
        
        @param raw The raw variable containing the source data */
    method public void PutBytes(input prData as raw):
        define variable mData as memptr no-undo.
        
        set-size(mData) = length(prData).
        put-bytes(mData,1) = prData.
        
        PutBytes(get-pointer-value(mData), get-size(mData)).
        
        finally:
            if get-size(mData) gt 0 then
                set-size(mData) = 0.
        end finally.
    end method.
    
    /** Debug/dump of the contents of this object on a per-byte basic. COPY-LOB 
        can also be used for debug purposes (COPY-LOB objMemptr:Value TO FILE). */
    method public void _Debug ():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable iByte as integer no-undo.
        define variable cDumpFile as character no-undo.
        
        assign iMax      = get-size(mmValue)
               cDumpFile = session:temp-directory + this-object:ToString() + '.bin':u.
        
        output to value(cDumpFile).
        do iLoop = 1 to iMax:
            assign iByte = get-byte(mmValue, iLoop).
            
            put unformatted 
                iByte StringConstant:TAB.
                
            if iByte <> 10 and iByte <> 13 then
                put unformatted
                    StringConstant:TAB StringConstant:TAB chr(iByte).
                  
             put unformatted skip. 
        end.
        output close.
    end method.
    
    method override public character ToString():
        return substitute('&1_&2':u, this-object:GetClass():TypeName, get-pointer-value(mmValue)).
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : MemptrArrayHolder
    Purpose     : OO holder for an array of datetime values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.IMemptrArrayHolder.

class OpenEdge.Core.MemptrArrayHolder implements IMemptrArrayHolder: 

	define public property Value as memptr extent no-undo get. set. 
		
	constructor public MemptrArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public MemptrArrayHolder(input pValue as memptr extent):
        this-object().
        assign this-object:Value = pValue.
    end constructor.

end class./************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ObjectArrayHolder
    Purpose     : OO holder for an array of objects
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

class OpenEdge.Core.ObjectArrayHolder : 
	define public property Value as Progress.Lang.Object extent no-undo get. set. 
		
	constructor public ObjectArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public ObjectArrayHolder(input pValue as Progress.Lang.Object extent):
        this-object().
        assign this-object:Value = pValue.
    end constructor.

    method override public character ToString():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cValue as character no-undo.
        define variable cDelim as character no-undo.
        
        assign iMax = extent(this-object:Value)
               cDelim = '':u. 
        do iLoop = 1 to iMax:
            assign cValue = substitute('&1&2&3':u,
                                cValue,
                                cDelim,
                                this-object:Value[iLoop]:ToString())
                   cDelim = ',':u.
        end.
        
        return cValue.
    end method.

end class./* *************************************************************************************************************************
Copyright (c) 2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : ReadModeEnum
    Purpose     : Enumeration of read-mode for READ-JSON and READ-XML
    Description : 
    Author(s)   : pjudge
    Created     : 2017-05-31
    Notes       : * Based on the ABL documentation 
  ----------------------------------------------------------------------*/
enum OpenEdge.Core.ReadModeEnum :  
    define enum Append  
                Empty   
                Replace 
                Merge
                 
                Default = Merge
                .
end enum./************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : RoutineTypeEnum
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Nov 18 15:25:50 EST 2010
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

enum OpenEdge.Core.RoutineTypeEnum:
    
    define enum       Constructor
                      Destructor
                      Method
                      PropertySetter
                      PropertyGetter
                      UserDefinedFunction
                      Procedure
                      . 
end enum.
/************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : RowidArrayHolder
    Purpose     : OO holder for an array of rowid values 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-01
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using Ccs.Common.Support.IRowidArrayHolder.

class OpenEdge.Core.RowidArrayHolder implements IRowidArrayHolder: 

	define public property Value as rowid extent no-undo get. set. 
		
	constructor public RowidArrayHolder (  ):
		super ().
	end constructor.
    
    constructor public RowidArrayHolder(input pValue as rowid extent):
        this-object().
        assign this-object:Value = pValue.
    end constructor.

    method override public character ToString():
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cValue as character no-undo.
        define variable cDelim as character no-undo.
        
        assign iMax = extent(this-object:Value)
               cDelim = '':u. 
        do iLoop = 1 to iMax:
            assign cValue = substitute('&1&2&3':u,
                                cValue,
                                cDelim,
                                this-object:Value[iLoop])
                   cDelim = ',':u.
        end.
        
        return cValue.
    end method.

end class./* *************************************************************************************************************************
Copyright (c) 2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : SemanticVersion
    Purpose     : A semantic version representation. A semver is 
                    MAJOR.MINOR.PATCH-PRERELEASE+BUILDMETADATA
                  
                  where the prerelease part is optional. 
                  The MAJOR, MINOR and PATCH releases are integer values.
                  The PRERELEASE is a string/character
                  The BUILDMETADATA is a string/characaer
                  The delimiters ("." / "-" / "+") are not stored in the object  
    Author(s)   : pjudge
    Created     : 2017-09-05
    Notes       : * From http://semver.org/spec/v2.0.0.html
                  * Defaults to 1.0.0 with no prerelease or build metadata
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.SemanticVersion.
using Progress.Lang.Object.

class OpenEdge.Core.SemanticVersion serializable:
    /* The major version */
    define public property Major as integer no-undo get. private set.
    
    /* The minor version */
    define public property Minor as integer no-undo get. private set.
    
    /* The patch version */
    define public property Patch as integer no-undo get. private set.
    
    /* The pre-release version. This is dash/"-" prefixed  */
    define public property Prerelease as character no-undo get. private set.

    /* (optional) The buld metadata. This is plus/"+" prefixed */ 
    define public property BuildMetadata as character no-undo get. private set.
    
    /* Default constructor */
    constructor public SemanticVersion():
        this-object(1, 0, 0).
    end method.
    
    /* Constructor
       
       @param integer The major version; must be >= 0
       @param integer The minor version; must be >= 0
       @param integer The patch version; must be >= 0  */
    constructor public SemanticVersion(input pMajor as integer,
                                       input pMinor as integer,
                                       input pPatch as integer):
        this-object(pMajor, pMinor, pPatch, '':u).
    end constructor.
    
    /* Constructor
       
       @param integer The major version; must be >= 0
       @param integer The minor version; must be >= 0
       @param integer The patch version; must be >= 0
       @param character the prelease version; must be non-null */
    constructor public SemanticVersion(input pMajor as integer,
                                       input pMinor as integer,
                                       input pPatch as integer,
                                       input pPreRel as character):
        this-object(pMajor, pMinor, pPatch, '':u, '':u).
    end method.
    
    /* Constructor
       
       @param integer The major version; must be >= 0
       @param integer The minor version; must be >= 0
       @param integer The patch version; must be >= 0
       @param character the prelease version; must be non-null 
       @param character build metadata ; must be non-null */
    constructor public SemanticVersion(input pMajor as integer,
                                       input pMinor as integer,
                                       input pPatch as integer,
                                       input pPreRel as character,
                                       input pBuildMeta as character):
        Assert:IsZeroOrPositive(pMajor, 'Major version').
        Assert:IsZeroOrPositive(pMinor, 'Minor version').
        Assert:IsZeroOrPositive(pPatch, 'Patch version').
        Assert:NotNull(pPreRel, 'Prerelease version').
        Assert:NotNull(pBuildMeta, 'Build metadata').
        
        assign this-object:Major      = pMajor
               this-object:Minor      = pMinor
               this-object:Patch      = pPatch
               this-object:PreRelease = pPreRel
               this-object:BuildMetadata     = pBuildMeta
               .
    end method.
    
    method override public character ToString():
        define variable version as character no-undo.
        
        assign version = substitute('&1.&2.&3':u,
                              Major,
                              Minor,
                              Patch).
        
        if PreRelease ne '':u then
            assign version = substitute('&1-&2':u,
                                version,
                                PreRelease).
        
        if BuildMetadata ne '':u then
            assign version = substitute('&1+&2':u,
                                version,
                                BuildMetadata).
        
        return version.
    end method. 
    
    /* Parses a version string and returns a SemanticVerison object
       
       @param character An appropriately-formatted version string
       @return SemanticVersion A SemanticVersion object */
    method static public SemanticVersion Parse(input pVersion as character):
        define variable chrPos as integer no-undo.
        define variable dotPos as integer no-undo.
        define variable semVer as SemanticVersion no-undo.
        
        Assert:NotNull(pVersion, 'Version string').
        
        // Use a simple default version
        assign semVer = new SemanticVersion(1, 0, 0).
        
        // BUILD METADATA
        assign chrPos = index(pVersion, '+':u). 
        if chrPos gt 0 then
            assign semVer:BuildMetadata = substring(pVersion, chrPos + 1)
                   pVersion             = substring(pVersion, 1, chrPos - 1)
                   .
        // PRERELEASE
        assign chrPos = index(pVersion, '-':u). 
        if chrPos gt 0 then
            assign semVer:PreRelease = substring(pVersion, chrPos + 1)
                   pVersion          = substring(pVersion, 1, chrPos - 1)
                   .
        // MAJOR.MINOR.PATCH
        if num-entries(pVersion, '.':u) ge 1 then
            assign semVer:Major = integer(entry(1, pVersion, '.':u)).
        if num-entries(pVersion, '.':u) ge 2 then
            assign semVer:Minor = integer(entry(2, pVersion, '.':u)).
        if num-entries(pVersion, '.':u) ge 3 then
            assign semVer:Patch = integer(entry(3, pVersion, '.':u)).
        
        return semVer.
    end method.
    
    method override public logical Equals(input pCompare as Object):
        if super:Equals(pCompare) then
            return true.
        // BUILD METADATA is NOT 
        if type-of(pCompare, SemanticVersion) then
            return (    this-object:Major         eq cast(pCompare, SemanticVersion):Major
                    and this-object:Minor         eq cast(pCompare, SemanticVersion):Minor
                    and this-object:Patch         eq cast(pCompare, SemanticVersion):Patch
                    and this-object:PreRelease    eq cast(pCompare, SemanticVersion):PreRelease
                    and this-object:BuildMetadata eq cast(pCompare, SemanticVersion):BuildMetadata ).
        
        return false.
    end method.
    
end class./************************************************
Copyright (c)  2015 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : SerializationFormatEnum
    Purpose     : Enumeration of serialization format types
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Fri Aug 28 09:02:56 EDT 2015
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

enum OpenEdge.Core.SerializationFormatEnum:
    define enum JSON
                QuotedJSON
                
                XML
                QuotedXML
                
                Binary
                .
end enum./************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : SerializationModeEnum
    Purpose     : Enumeration of WRITE-*() and READ-*() method modes.
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Oct 12 14:17:26 EDT 2010
    Notes       : * Based on the ABL documentation 
                  * This program based on the AutoEdge|TheFactory version
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

enum OpenEdge.Core.SerializationModeEnum:
    define enum       File
                      Stream
                      Stream-Handle
                      StreamHandle = Stream-Handle 
                      Memptr
                      Handle
                      LongChar.
end enum.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : Session
    Purpose     : An extension of the SESSION system handle. 
    Description : Session object : this object lives for the lifespan of 
                  an AVM Session. 
    @author pjudge
    Created     : Fri Jun 04 15:00:56 EDT 2010
    Notes       : * Discover handle- and object- references for given names
                  * Resolves weak references
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.Session.
using OpenEdge.Core.Collections.Array.
using OpenEdge.Core.String.
using OpenEdge.Core.WidgetHandle.
using OpenEdge.Core.Assert.
using Progress.Lang.Class.
using Progress.Lang.Object.

class OpenEdge.Core.Session:
    /** Returns the first running persistent procedure instance found
        for a given name.
        
        @param character The (relative) path name for a procedure.
        @return handle The handle to that procedure, if any. Unknown value if
                       there's no running instance of that name. */
    method static public WidgetHandle GetFirstRunningProc (input pcName as character):
        define variable hProc as handle no-undo.
        
        hProc = session:first-procedure.
        do while valid-handle(hProc) and hProc:file-name ne pcName:
            hProc = hProc:next-sibling. 
        end.
        
        return new WidgetHandle(hProc).
    end method.

    /** Returns all the running persistent procedure instances found
        for a given name.
        
        @param character The (relative) path name for a procedure.
        @return handle An array of handles to that procedure, if any.
                       If there's no running instance of that name, then
                       the array has an extent of 1 (one) which contains the 
                       unknown value.       */ 
    method static public Array GetAllRunningProcs (input pcName as character):
        define variable oProcedures as Array no-undo.        
        define variable hTemp as handle no-undo.
        define variable cProcs as character no-undo.
        define variable iMax as integer no-undo.
        define variable iLoop as integer no-undo.
        
        oProcedures = new Array().
        hTemp = session:first-procedure.
        do while valid-handle(hTemp):         
            if hTemp:file-name eq pcName then
                oProcedures:Add(new WidgetHandle(hTemp)).

            hTemp = hTemp:next-sibling. 
        end.
        
        return oProcedures.        
    end method.
    
    /** Resolves a weak reference into an object instance. A weak reference is an integer
        representation of an object reference. This method is analogous to the WIDGET-HANDLE()
        function.
        
        Notes: * Based on http://msdn.microsoft.com/en-us/library/ms404247(v=VS.90).aspx
               * Performance of ResolveWeakReference() will probably suck.
               * An ABL statement "OBJECT-REFERENCE(int)" would entirely replace this method.    
        @param integer A weak reference to an object.
        @return Object The object instance corresponding to that reference. The unknown value/null
                is returned if the referecen cannot be resolved.  */
    method static public Object ResolveWeakReference(input piReference as integer):
        define variable oInstance as Object no-undo.
        define variable oReference as Object no-undo.
        
        oInstance = session:first-object.
        do while valid-object(oInstance) and not valid-object(oReference):
            if piReference eq int(oInstance) then
                oReference = oInstance.
            oInstance = oInstance:Next-Sibling.
        end.
        
        return oReference.        
    end method.
    
    /** Returns the first object instance found that is of the type given.
        
        @param Class The type. This can be a class or an interface. 
        @return Object The reference to that type, if any. Unknown value if
                       there's no running instance of that name. */
    method static public Object GetFirstClassInstance(input poType as Progress.Lang.Class):
        define variable oInstance as Object no-undo.
        
        Assert:NotNull(poType, 'type').
        
        oInstance = session:first-object.
        do while valid-object(oInstance) and oInstance:GetClass():IsA(poType):
            oInstance = oInstance:next-sibling. 
        end.
        
        return oInstance.
    end method.
    
    /** Returns all the object instances found that are of the type given.
        
        @param Class The type. This can be a class or an interface.
        @return Object The reference to that type, if any. Unknown value if
                       there's no running instance of that name. */
    method static public Array GetAllInstances(input poType as Progress.Lang.Class):
        define variable oInstance as Array no-undo.
        define variable oTemp as Object no-undo.
        
        Assert:NotNull(poType, 'type').
        
        oInstance = new Array().
        
        oTemp = session:first-object.
        do while valid-object(oTemp):
            if oTemp:GetClass():IsA(poType) then
                oInstance:Add(oTemp).
            
            oTemp = oTemp:next-sibling. 
        end.
        
        return oInstance.
    end method.
    
end class./************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : SessionClientTypeEnum
    Purpose     : Enumeration of ABL client types, as per the SESSION:CLIENT-TYPE 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Feb 18 15:08:28 EST 2010
    Notes       : * Descriptions appear in the ABL documentation.
                  * This class based on the AutoEdge|TheFactory version
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

enum OpenEdge.Core.SessionClientTypeEnum:
    define enum       ABLClient 
                      WebClient 
                      AppServer 
                      WebSpeed  
                      Multi-Session-Agent
                      PacificAS = Multi-Session-Agent 
                      Other.
end enum.
/************************************************
Copyright (c) 2013-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : String
    Purpose     : Primitive class for character/longchar variables
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Aug 11 13:08:46 EDT 2009
    Notes       : * Named 'String' because of keyword/namespace conflicts with
                    ABL Primitive 'character'. There's no built-in class for this.
                  * Initial requirement for collections; having a class for the
                    primitive value means that we don't have to distinguish between
                    primitives and types, which makes the code more readable.
                  * This class based on the AutoEdge|TheFactory version 
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using Ccs.Common.Support.ILongcharHolder.
using OpenEdge.Core.Assert.
using OpenEdge.Core.Collections.Array.
using OpenEdge.Core.ISupportEncoding.
using OpenEdge.Core.StringConstant.
using Progress.Lang.Object.

/* Don't have a USING for this class, so that we can avoid conflicts with the STRING() ABL keyword/function
using OpenEdge.Core.String.*/

class OpenEdge.Core.String serializable
        implements ILongcharHolder, ISupportEncoding:
    
    /* Helper/holder for an empty String instance.  */  
    define static private variable moEmptyString as OpenEdge.Core.String no-undo.
    
    /* Holds the actual value, in UTF-8. UTF-8 can hold pretty much all characters, so let's be smart and use that. 
       SERIALIZABLE since this is the actual value 'holder' */
    define private serializable variable mUTF8Value as longchar no-undo. 
    
    /* Content encoding (eg utf-8) of this string. Defaults to CPINTERNAL if not specified */ 
    define public property Encoding as character no-undo get. set.
    
    /** Contains the actual string value. Marked as NON-SERIALIZABLE since the actual value is derived, 
        and stored in the private mUTF8Value variable */
    define public non-serializable property Value as longchar no-undo
        get():
            // always deallocate/reset/clear
            assign this-object:Value = ?.
            
            // no need for changes if we're using UTF-8 as CPINTERNAL
            if get-codepage(mUTF8Value) eq this-object:Encoding then
                return mUTF8Value.
            else
            do:
                fix-codepage(this-object:Value) = this-object:Encoding.
                
                assign this-object:Value = mUTF8Value.
                
                return this-object:Value.
            end.
        end get.
        private set.
    
    /** Returns the size of the contained string, in characters */
    define public property Size as int64 no-undo
        get():
            return length(mUTF8Value).
        end get.
    
    /* Default constructor */
    constructor public String():
        super().
        
        fix-codepage(mUTF8Value) = 'UTF-8':u.
        assign mUTF8Value           = '':u
               this-object:Encoding = session:cpinternal
               .
    end constructor.
    
    /* Constructor 
       
       @param longchar A string value */
    constructor public String(input pcString as longchar):
        this-object().
        
        assign mUTF8Value           = pcString
               this-object:Encoding = get-codepage (pcString)
               .
    end constructor.
    
    /* Constructor 
       
       @param longchar A string value */
    constructor public String(input pcString as char):
        this-object().
        
        assign mUTF8Value = pcString.
    end constructor.
    
    /** Trims whitespace off the contained string */
    method public void Trim():
        /* we can't use the ABL TRIM keyword, since we run into 
           name conflicts, so do a left- and right-trim instead. */
        right-trim(left-trim(mUTF8Value)).
    end method.
    
    /** Trims the specified character off the contained string
        
        @param character The non-null character to trim */
    method public void Trim(input pCharacter as character):
        Assert:NotNull(pCharacter, 'Trim character').
        
        /* we can't use the ABL TRIM keyword, since we run into 
           name conflicts, so do a left- and right-trim instead. */
        right-trim(left-trim(mUTF8Value, pCharacter), pCharacter).
    end method.
    
    /* Returns a single/the same empty/non-null String object.
       
       @return OpenEdge.Core.String An empty string */
    method static public OpenEdge.Core.String Empty ():
        if not valid-object(moEmptyString) then
            assign moEmptyString = new OpenEdge.Core.String().
        
        return moEmptyString.
    end method.
    
    method override public logical Equals(input p0 as Object):
        if type-of(p0, OpenEdge.Core.String) then
            return (mUTF8Value eq cast(p0, OpenEdge.Core.String):mUTF8Value).
        else
            return super:Equals(p0).
    end method.
    
    /** Splits the value of this string into an array based on 
        a specified delimiter
        
        @param character A delimter used to split the string
        @return Array  An array object of strings */
    method public Array Split(input pcDelimiter as character):
        return OpenEdge.Core.String:Split(this-object, pcDelimiter).
    end method.
    
    /** Splits the value of this string into an array based on 
        a default delimiter
        
        @return Array  An array object of strings */
    method public Array Split():
        return OpenEdge.Core.String:Split(this-object).
    end method.
        
    /** Splits the value of this string into an array using
        a default delmiter 
        
        @param OpenEdge.Core.String A value to split
        @return Array  An array object of strings */
    method static public Array Split(input poValue as OpenEdge.Core.String):
        return OpenEdge.Core.String:Split(poValue, ',':u).
    end method.
    
    /** Splits the value of this string into an array using
        a specified delmiter 
        
        @param OpenEdge.Core.String A value to split
        @param character A delimter used to split the string
        @return Array  An array object of strings */
    method static public Array Split(input poValue as OpenEdge.Core.String,
                                     input pcDelimiter as character):
        define variable oArray as Array no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        assign iMax = num-entries(poValue:mUTF8Value, pcDelimiter)
               oArray = new Array(iMax)
               .
        do iLoop = 1 to iMax:
            oArray:SetValue(new OpenEdge.Core.String(entry(iLoop, poValue:mUTF8Value, pcDelimiter)),
                            iLoop).
        end.
        
        return oArray.
    end method.
    
    // Splits: ABL primitives
    
    /** Splits the value of this string into an array using
        a default delmiter 
        
        @param longchar A value to split
        @return character[] An array of strings */
    method static public character extent Split(input pcValue as longchar):
        return OpenEdge.Core.String:Split(pcValue, ',':u).
    end method.
            
    /** Splits the value of this string into an array using
        a specified delimiter 
        
        @param longchar A value to split
        @param character A delimter used to split the string
        @return character[] An array of strings */
    method static public character extent Split(input pcValue as longchar,
                                                input pcDelimiter as character):
        define variable cArray as character extent no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        assign iMax = num-entries(pcValue, pcDelimiter)
               extent(cArray) = iMax.
        
        do iLoop = 1 to iMax:
            assign cArray[iLoop] = entry(iLoop, pcValue, pcDelimiter).
        end. 
        
        return cArray.
    end method.
    
    /* Join: OE.Core.String */
    /** Joins an array's contents into a delimited string
        
        @param Array An array object containing of OpenEdge.Core.String objects
        @param character The delimiter used to join them
        @return OpenEdge.Core.String A single, delimited string object */
    method static public OpenEdge.Core.String Join(input poValue as Array,
                                                   input pcDelimiter as character):
        Assert:IsType(poValue, get-class(OpenEdge.Core.String)).
        return OpenEdge.Core.String:Join(cast(poValue:ToArray(), OpenEdge.Core.String), pcDelimiter).                    
    end method.
    
    /** Joins an array's contents into a delimited string
        
        @param OpenEdge.Core.String[] An array of OpenEdge.Core.String objects to join
        @param character The delimiter used to join them
        @return OpenEdge.Core.String A single, delimited string object */
    method static public OpenEdge.Core.String Join(input poValue as OpenEdge.Core.String extent,
                                                   input pcDelimiter as character):
        define variable cJoinedString as longchar no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        iMax = extent(poValue).
        do iLoop = 1 to iMax:
            if iLoop eq 1 then
                assign cJoinedString = poValue[iLoop]:mUTF8Value.
            else
                assign cJoinedString = cJoinedString + pcDelimiter + poValue[iLoop]:mUTF8Value.
        end.
        
        return new OpenEdge.Core.String(cJoinedString).
    end method.

    /* Join: ABL primitive */
    /** Joins an array's contents into a delimited string
        
        @param character[] An array of character values to join
        @param character The delimiter used to join them
        @return longchar A single, delimited string */
    method static public longchar Join(input pcValue as character extent,
                                       input pcDelimiter as character):
        define variable cJoinedString as longchar no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.

        iMax = extent(pcValue).
        do iLoop = 1 to iMax:
            if iLoop eq 1 then
                assign cJoinedString = pcValue[iLoop].
            else
                assign cJoinedString = cJoinedString + pcDelimiter + pcValue[iLoop].
        end.
        
        return cJoinedString.
    end method.
    
    /** Returns a string value for this object
       
        @return character A string representation of this object. May be truncated. */
    method override public character ToString():
        define variable cValue as character no-undo.
        
        /* characters are nominally 32k long, but not always in practice. for values that approach
           exceeding 'about 32k' we'll take the first 30000 bytes or so. the entire value is available
           through the :Value property anyway. */
        if this-object:Size ge 30000 then
            assign cValue = substring(this-object:Value, 1, 29985) + ' <<...MORE...>>':u.
        else
            assign cValue = this-object:Value.
        
        return cValue.
    end method.
        
    /* Adds the input string to the end of the current string.
       No validation (for unknowns in particular) is done on either 
       string value.
       
       @param longchar A value to append */
    method public void Append(input pcValue as longchar):
        // no-op allowed on the special Empty string. don't use the Equals() 
        // overload cos it checks values first
        if int64(this-object) eq int64(moEmptyString) then
            return.
        
        assign mUTF8Value = mUTF8Value + pcValue.
    end method.
    
    /* Adds the input string to the end of the current string.
       No validation (for unknowns in particular) is done on either 
       string value.
       
       @param OpenEdge.Core.String A value to append */
    method public void Append(input poValue as OpenEdge.Core.String):
        // no-op allowed on the special Empty string. don't use the Equals() 
        // overload cos it checks values first
        if int64(this-object) eq int64(moEmptyString) then
            return.
        
        assign mUTF8Value = mUTF8Value  + poValue:mUTF8Value . 
    end method.

    /* Adds the input string to the beginning of the current string.
       No validation (for unknowns in particular) is done on either 
       string value.
       
       @param longchar A value to prepend */
    method public void Prepend(input pcValue as longchar):
        // no-op allowed on the special Empty string. don't use the Equals() 
        // overload cos it checks values first
        if int64(this-object) eq int64(moEmptyString) then
            return.
        
        assign mUTF8Value = pcValue + mUTF8Value.
    end method.

    /* Adds the input string to the beginning of the current string.
       No validation (for unknowns in particular) is done on either 
       string value.
       
       @param OpenEdge.Core.String A value to prepend */
    method public void Prepend(input poValue as OpenEdge.Core.String):
        // no-op allowed on the special Empty string. don't use the Equals() 
        // overload cos it checks values first
        if int64(this-object) eq int64(moEmptyString) then
            return.
        
        assign mUTF8Value = poValue:mUTF8Value + mUTF8Value. 
    end method.
    
    /* Indicates whether the string is quoted with either double (") or single (') quotes.
       The first AND last characters must be the same and must either the quote character
       
       @param longchar  A string to check
       @return logical TRUE if the string is non-null and has matching leading and trailing quotes. */    
    method static public logical IsQuoted(input pcValue as longchar):        
        if IsQuoted(pcValue, StringConstant:DOUBLE_QUOTE) then
            return true.
        
        return IsQuoted(pcValue, StringConstant:SINGLE_QUOTE).
    end method.
    
    /* Indicates whether the string is quoted with the quote character ,
       The first AND last characters must be the same and be the quote character
       
       @param longchar  A string to check
       @param character The quote character
       @return logical TRUE if the string is non-null and has matching leading and trailing quotes. */    
    method static public logical IsQuoted(input pcValue as longchar,
                                          input pcQuote as character):
        // left- and right-trim since this class has a Trim() method and we cannot disambiguate
        if pcValue eq ? or length(right-trim(left-trim(pcValue)), 'character':u) lt 2 then
            return false.
        
        Assert:NotNullOrEmpty(pcQuote, 'Quote character').
        
        return (index(pcValue, pcQuote)   eq 1 and 
                r-index(pcValue, pcQuote) eq length(pcValue, 'character':u)). 
    end method.
    
    method public logical IsNullOrEmpty():
        return OpenEdge.Core.String:IsNullOrEmpty(this-object:mUTF8Value).
    end method.
    
    /* Indicates whether a string is null or empty: empty having no
       non-whitespace characters
       
       @param longchar The value being checked
       @return logical TRUE if the string is null or empty */
    method static public logical IsNullOrEmpty(input pcValue as longchar):
        define variable iRawLength as int64 no-undo.
        
        if pcValue eq ? then
            return true.
        
        assign iRawLength = length(pcValue, 'raw':u).
        
           /* no characters is pretty empty */
        if iRawLength eq 0 or
           /* TRIM converts everything to cpinternal, which may not be able to 'see' all the characters
              that are in the argument. So, if the lengths differ, then there's something that's not a space
              (strong assumption) and we're OK, Jack.
              If the lengths match, we are ok to convert and we try to trim. */
           (iRawLength eq length(pcValue) and right-trim(left-trim(pcValue)) eq '':u) then
            return true.
        
        return false.            
    end method.
    
end class.

 /*------------------------------------------------------------------------
    File        : StringArray
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Tue Jun 07 09:40:26 EDT 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using Ccs.Common.Support.ILongcharArrayHolder.

class OpenEdge.Core.StringArray     implements ILongcharArrayHolder: 

	define public property Value as longchar extent no-undo get. private set.

    constructor public StringArray(input pcValue as longchar extent):
        assign this-object:Value = pcValue.
    end constructor.

end class./* *************************************************************************************************************************
Copyright (c) 2016-2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : StringConstant
    Purpose     : Tilde-escaped string contstants 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Dec 07 10:25:16 EST 2016
    Notes       :* Taken from the ~ Special character Help 
                 * abstract since it's a kinda-sort enum
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.StringConstant.

class OpenEdge.Core.StringConstant abstract:
    // Control characters
    // Tab - octal 011
    define static public property TAB   as character no-undo initial '~t':u    get.
    // Carriage return - octal 015
    define static public property CR    as character no-undo initial '~r':u    get.
    // Line feed / new line - octal 012
    define static public property LF    as character no-undo initial '~n':u    get.
    define static public property CRLF  as character no-undo initial '~r~n':u  get.
    // Escape - octal 033
    define static public property ESC   as character no-undo initial '~E':u    get.
    // Backspace - octal 010
    define static public property BACK  as character no-undo initial '~b':u    get.
    // Form feed - octal 014
    define static public property FF    as character no-undo initial '~f':u    get.
    
    // Escaped strings
    define static public property TILDE         as character no-undo initial '~~':u    get.
    define static public property SEMICOLON     as character no-undo initial '~;':u    get.
    // Use within quoted strings as an alternative to two apostrophes ('').
    define static public property SINGLE_QUOTE  as character no-undo initial '~'':u    get.
    // Use within quoted strings as an alternative to two quotes ("").
    define static public property DOUBLE_QUOTE  as character no-undo initial '~"':u    get.
    define static public property BACKSLASH     as character no-undo initial '~\':u    get.
    define static public property CURLY_OPEN    as character no-undo initial '~{':u    get.
    define static public property CURLY_CLOSE   as character no-undo initial '~}':u    get.
    // Escape for entering unicode characters
    define static public property UNICODE_ESC   as character no-undo get. private set.
    // An empty string (space)
    define static public property SPACE as character no-undo initial ' ':u get.
    
    /* Static constructor */
    constructor static StringConstant():
        // this MUST be lower-case "u" (ASC dec 117 / hex 75)
        assign StringConstant:UNICODE_ESC = StringConstant:TILDE + 'u':u.
    end constructor.
    
end class.
/************************************************
Copyright (c)  2013, 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : TimeStamp
    Purpose     : Primitive class for date, TimeStamp and TimeStamp-tz values
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Mon Nov 22 14:29:32 EST 2010
    Notes       : * Named 'TimeStamp' because of keyword/namespace conflicts with
                    ABL Primitive DATETIME. There's no built-in class for this.
                  * This version baed on the AutoEdge|TheFactory version
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using Ccs.Common.Support.IDateTimeTzHolder.
using OpenEdge.Core.TimeStamp.
using Progress.Lang.Object.

class OpenEdge.Core.TimeStamp serializable : 
    define public property Format as character no-undo get. private set.
    
    define private variable mtDate as date no-undo.
    define private variable miTime as integer no-undo.
    define private variable miTZOffset as integer no-undo.
    
    constructor public TimeStamp(ptTimeStamp as date):
        super().
        
        assign mtDate = ptTimeStamp
               this-object:Format = 'Date'.
    end constructor.
    
    constructor public TimeStamp(ptTimeStamp as datetime):
        super().
        
        assign mtDate = date(ptTimeStamp)
               miTime = mtime(ptTimeStamp)
               this-object:Format = 'DateTime'.
    end constructor.

    constructor public TimeStamp(ptTimeStamp as datetime-tz):
        super().
        
        assign mtDate = date(ptTimeStamp)
               miTime = mtime(ptTimeStamp)
               miTZOffset = timezone(ptTimeStamp)
               this-object:Format = 'DateTime-TZ'.
    end constructor.

    constructor public TimeStamp(input pcTimeStamp as character):
        define variable tTimeStamp as datetime-tz no-undo.
        
        super().
        
        tTimeStamp = TimeStamp:ToABLDateTimeFromISO(pcTimeStamp).
        
        assign mtDate = date(tTimeStamp)
               miTime = mtime(tTimeStamp)
               miTZOffset = timezone(tTimeStamp)
               this-object:Format = 'DateTime-TZ'.
    end constructor.
    
    constructor public TimeStamp():
        this-object(now).
    end constructor.
    
    method override public logical Equals(input p0 as Object):
        if type-of(p0, TimeStamp) then
        case this-object:Format:
            when 'Integer' then return (ToTime() eq cast(p0, TimeStamp):ToTime()).
            when 'Date' then return (ToDate() eq cast(p0, TimeStamp):ToDate()).
            when 'DateTime' then return (ToDateTime() eq cast(p0, TimeStamp):ToDateTime()).
            when 'DateTime-TZ' then return (ToDateTimeTz() eq cast(p0, TimeStamp):ToDateTimeTz()).
        end case.
        else
            return super:Equals(p0).
    end method.

    /** Converts an ABL datetime into a correct ISO date. The ISO-DATE()
        function requires the session's date format to be YMD before
        performing the conversion; this method wraps that.
        
        @return character An ISO date.      */
    method public character ToISODate():
        define variable cDateFormat as character no-undo.
        
        cDateFormat = session:date-format.
        session:date-format = 'ymd'.
        
        return iso-date(ToDateTimeTz()).
        finally:
            session:date-format = cDateFormat.        
        end finally.
    end method.

    /** Converts an ABL datetime into a correct ISO date. The ISO-DATE()
        function requires the session's date format to be YMD before
        performing the conversion; this method wraps that.
        
        @param date The date value to convert
        @return character An ISO date.      */
    method static public character ToISODateFromABL(input ptValue as date):
        return TimeStamp:ToISODateFromABL(datetime-tz(ptValue)).
    end method.
    
    /** Converts an ABL datetime into a correct ISO date. The ISO-DATE()
        function requires the session's date format to be YMD before
        performing the conversion; this method wraps that.
        
        @param datetime The date value to convert
        @return character An ISO date.      */
    method static public character ToISODateFromABL(input ptValue as datetime):
        return TimeStamp:ToISODateFromABL(datetime-tz(ptValue)).
    end method.
            
    /** Converts an ABL datetime into a correct ISO date. The ISO-DATE()
        function requires the session's date format to be YMD before
        performing the conversion; this method wraps that.
        
        @param datetime-tz The date value to convert
        @return character An ISO date.      */
    method static public character ToISODateFromABL(input ptValue as datetime-tz):
        define variable cDateFormat as character no-undo.
        
        cDateFormat = session:date-format.
        session:date-format = 'ymd'.
        
        return iso-date(ptValue).
        finally:
            session:date-format = cDateFormat.        
        end finally.
    end method.

    /** Converts an ISO date into an ABL DATE. The ISO-DATE()
        requires the session's date format to be YMD before
        performing the conversion; this method wraps that.
        
        @param character An ISO date
        @return datetime-tz The date value to convert.      */
    method static public date ToABLDateFromISO(input pcValue as character):
        return date(TimeStamp:ToABLDateTimeTzFromISO(pcValue)).
    end method.

    /** Converts an ISO date into an ABL DATETIME. The ISO-DATE()
        requires the session's date format to be YMD before
        performing the conversion; this method wraps that.
        
        @param character An ISO date
        @return datetime The date value to convert.      */
    method static public datetime ToABLDateTimeFromISO(input pcValue as character):
        define variable tDateTimeTz as datetime-tz no-undo.
        
        tDateTimeTz = TimeStamp:ToABLDateTimeTzFromISO(pcValue).
        
        return datetime(date(tDateTimeTz), mtime(tDateTimeTz)).
    end method.
            
    /** Converts an ISO date into an ABL DATETIME-TZ. The ISO-DATE()
        requires the session's date format to be YMD before
        performing the conversion; this method wraps that.
        
        @param character An ISO date
        @return datetime-tz The date value to convert.      */
    method static public datetime-tz ToABLDateTimeTzFromISO(input pcValue as character):
        define variable cDateFormat as character no-undo.
        
        cDateFormat = session:date-format.
        session:date-format = 'ymd'.
        
        return datetime-tz(pcValue).
        finally:
            session:date-format = cDateFormat.        
        end finally.
    end method.
    
    /** Converts an HTTP 'sane date' into an ABL DATETIME-TZ. The HTTP date is
        defined at http://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3
        
        One of the following formats will be used:
            Sun, 06 Nov 1994 08:49:37 GMT  ; RFC 822, updated by RFC 1123
            Sunday, 06-Nov-94 08:49:37 GMT ; RFC 850, obsoleted by RFC 1036
            Sun Nov  6 08:49:37 1994       ; ANSI C's asctime() format
        
        @param character An ISO date
        @return datetime-tz The date value to convert.      */
    method static public datetime-tz ToABLDateTimeTzFromHttp(input pcValue as character):
        define variable cTime as character no-undo.
        define variable iYear as integer no-undo.
        define variable iMonth as integer no-undo.
        define variable iDay as integer no-undo.        
        /* Always English month names. Use the CSV to convert from name to number */
        define variable cMonthList as character no-undo
            initial 'Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec'.
        
        /* ANSI C date:
           Sun Nov  6 08:49:37 1994       ; ANSI C's asctime() format */
        if index(pcValue, ',') eq 0 then
            assign iMonth = lookup(entry(2, pcValue, ' '), cMonthList)
                   /* note the double space between Month and Day, so entry 3 is missing */
                   iDay   = integer(entry(4, pcValue, ' '))
                   cTime = entry(5, pcValue, ' ')
                   iYear  = integer(entry(6, pcValue, ' ')).
        else
        /* Sunday, 06-Nov-94 08:49:37 GMT ; RFC 850, obsoleted by RFC 1036 */
        if num-entries(pcValue, ' ') eq 4 then
            assign cTime  = entry(2, pcValue, ' ')  /* lazy/reuse variable */
                   iDay   = integer(entry(1, cTime, '-'))
                   iMonth = lookup(entry(2, cTime, '-'), cMonthList)
                   iYear  = integer(entry(3, cTime, '-'))
                   cTime  = entry(3, pcValue, ' ').
        else
        /* Sun, 06 Nov 1994 08:49:37 GMT  ; RFC 822, updated by RFC 1123 */
            assign iDay   = integer(entry(2, pcValue, ' '))
                   iMonth = lookup(entry(3, pcValue, ' '), cMonthList)
                   iYear  = integer(entry(4, pcValue, ' '))
                   cTime  = entry(5, pcValue, ' ').
        
        return datetime-tz(iMonth, iDay, iYear,
            integer(entry(1, cTime, ':')),       /* hour */
            integer(entry(2, cTime, ':')),       /* minute */
            integer(entry(3, cTime, ':')),       /* second */
            0,                          /* millisecond */
            0).                         /* timezone (always GMT per spec) */
    end method.
    
    /** Converts an ABL date into an HTTP 'sane date', according to RFC 822, as 
        defined at http://www.w3.org/Protocols/rfc2616/rfc2616-sec3.html#sec3.3
        
        One of the following formats will be used:
            Sun, 06 Nov 1994 08:49:37 GMT  ; RFC 822, updated by RFC 1123
        
        @param character An ISO date
        @return datetime-tz The date value to convert.      */
    method static public character ToHttpDateFromABL(input ptValue as datetime-tz):
        /* Always English month names. Use the CSV to convert from name to number */
        define variable cMonthList as character extent 12 no-undo
            initial ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'].
            
        define variable cDayOfWeekList as character extent 7 no-undo
            initial ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'].
        
        define variable tUTCValue as datetime-tz no-undo.
        define variable iSecondTime as integer no-undo.
        
        if timezone(ptValue) eq 0 then
            assign tUTCValue = ptValue.
        else
            assign tUTCValue = datetime-tz(ptValue, 0).
        
        /* Sun, 06 Nov 1994 08:49:37 GMT  */
        return substitute('&1, &2 &3 &4 &5 GMT',
                cDayOfWeekList[weekday(tUTCValue)],
                string(day(tUTCValue), '99'),
                cMonthList[month(tUTCValue)],                
                year(tUTCValue),
                string(integer(mtime(tUTCValue) / 1000), 'HH:MM:SS') ).
    end method.
    
    method public character ToHttpDate():
        return TimeStamp:ToHttpDateFromABL(ToDateTimeTz()).
    end method.
    
    method public datetime-tz ToDateTimeTz():
        return datetime-tz(mtDate, miTime, miTZOffset).
    end method.
        
    method public datetime ToDateTime():
        return datetime(mtDate, miTime).
    end method.

    method public date ToDate():
        return mtDate.
    end method.
    
    method public integer ToTime():
        return miTime.
    end method.
    
end class.
/************************************************
Copyright (c) 2013, 2016-2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : WidgetHandle
    Purpose     : Primitive class for widget-handle variables    
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Apr 19 09:47:07 EDT 2011
    Notes       : * This class based on the AutoEdge|TheFactory version
                  * By default the handle will not be destroyed/deleted. Set 
                    the AutoDestroy property to TRUE to cleanup automatically.
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using Ccs.Common.Support.IHandleHolder.
using OpenEdge.Core.Assert.
using OpenEdge.Core.WidgetHandle.
using Progress.Lang.Object.
 
class OpenEdge.Core.WidgetHandle serializable
        implements IHandleHolder:
             
    define public property Value as handle no-undo get. private set.
    
    /** Indicates whether the handle will be destroyed/cleared when this object
        is destroyed. Default is FALSE. */
    define public property AutoDestroy as logical initial false no-undo get. set.
    
    constructor public WidgetHandle():
        this-object(?).
    end constructor.

    destructor public WidgetHandle():
        if     AutoDestroy 
           and valid-object(this-object:Value ) then
            delete object this-object:Value no-error.
    end destructor.
    
    constructor public WidgetHandle(input phValue as handle):
        this-object(phValue, false).
    end constructor.

    constructor public WidgetHandle(input phValue as handle,
                                    input plAutoDestroy as logical):
        super().
        
        Assert:NotUnknown(plAutoDestroy, 'Auto destroy').
        assign this-object:AutoDestroy = plAutoDestroy
               this-object:Value       = phValue.
    end constructor.

    method override public logical Equals(input p0 as Object):
        if type-of(p0, WidgetHandle) then
            return (this-object:Value eq cast(p0, WidgetHandle):Value).
        else
            return super:Equals(p0).
    end method.
    
    method override public character ToString():
        define variable cValue as character no-undo.
        cValue = string(this-object:Value).
        
        return cValue.
    end method.

end class.
/************************************************
Copyright (c) 2014-2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : AssertArray
    Purpose     : Assertions of truth for various arrays
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2017-02-01
    Notes       : 
  ----------------------------------------------------------------------*/

using Progress.Lang.*.
using OpenEdge.Core.AssertionFailedError.
using OpenEdge.Core.Assertion.AssertObject.
using OpenEdge.Core.Assert.

block-level on error undo, throw.

class OpenEdge.Core.Assertion.AssertArray: 
    
    method public static void Equals(input pSource as character extent, 
                                     input pTarget as character extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if    (srcSize eq ? and tgtSize ne ?) 
           or srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize), 0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.
    
    method public static void Equals(input pSource as longchar extent, 
                                     input pTarget as longchar extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize), 0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.
    
    method public static void Equals(input pSource as integer extent, 
                                     input pTarget as integer extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0).
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.
    
    method public static void Equals(input pSource as int64 extent, 
                                     input pTarget as int64 extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.

    method public static void Equals(input pSource as decimal extent, 
                                     input pTarget as decimal extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.
    
    method public static void Equals(input pSource as date extent, 
                                     input pTarget as date extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.
    
    method public static void Equals(input pSource as datetime extent, 
                                     input pTarget as datetime extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.

    method public static void Equals(input pSource as datetime-tz extent, 
                                     input pTarget as datetime-tz extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.
    
    method public static void Equals(input pSource as logical extent, 
                                     input pTarget as logical extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.
    
    method public static void Equals(input pSource as handle extent, 
                                     input pTarget as handle extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.

    method public static void Equals(input pSource as Progress.Lang.Object extent, 
                                     input pTarget as Progress.Lang.Object extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
    end method.

    method public static void Equals(input pSource as recid extent, 
                                     input pTarget as recid extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.

    method public static void Equals(input pSource as rowid extent, 
                                     input pTarget as rowid extent):
        define variable srcSize as integer no-undo.
        define variable tgtSize as integer no-undo.
        define variable loop as integer no-undo.
        
        assign srcSize = extent(pSource)
               tgtSize = extent(pTarget).
        if (srcSize eq ? and tgtSize ne ?) or
           srcSize ne tgtSize then
            undo, throw new AssertionFailedError(substitute('Arrays are different sizes (source=&1; target=&2)', srcSize, tgtSize),  0). 
        
        do loop = 1 to srcSize:
            Assert:Equals(pSource[loop], pTarget[loop]). 
        end.
        catch e as Progress.Lang.Error:
            undo, throw new AssertionFailedError(substitute('Array value differ for index &1', loop), 0).
        end catch.
    end method.
    
    method public static void HasDeterminateExtent(input pcArgument as character extent,
                                                           input pcName as character):
        if extent(pcArgument) eq ? then
            undo, throw new AssertionFailedError(substitute('&1 array cannot be indeterminate', pcName), 0).
    end method.
    
    method public static void HasDeterminateExtent(input pcArgument as character extent):
        HasDeterminateExtent(pcArgument, "argument").
    end method.
    
    method public static void IsIndeterminateArray(input pcArgument as character extent,
                                                           input pcName as character):
        if extent(pcArgument) ne ? then
            undo, throw new AssertionFailedError(substitute('&1 array must be indeterminate', pcName), 0).
    end method.
    
    method public static void IsIndeterminateArray(input pcArgument as character extent):
        IsIndeterminateArray(pcArgument, "argument").
    end method.

    method public static void IsIndeterminateArray(input poArgument as Object extent,
                                                   input pcName as character):
        AssertObject:IsIndeterminateArray(poArgument, pcName).
    end method.
    
    method public static void HasDeterminateExtent(input poArgument as Object extent,
                                                           input pcName as character):
        AssertObject:HasDeterminateExtent(poArgument, pcName).
    end method.
    
    method public static void HasDeterminateExtent(input piArgument as integer extent,
                                                           input pcName as character):
        if extent(piArgument) eq ? then
            undo, throw new AssertionFailedError(substitute('&1 array cannot be indeterminate', pcName), 0).
    end method.

    method public static void HasDeterminateExtent(input piArgument as integer extent):
        HasDeterminateExtent(piArgument, "argument").
    end method.
    
    method public static void IsIndeterminateArray(input piArgument as integer extent,
                                                           input pcName as character):
        if extent(piArgument) ne ? then
            undo, throw new AssertionFailedError(substitute('&1 array must be indeterminate', pcName), 0).
    end method.

    method public static void IsIndeterminateArray(input piArgument as integer extent):
        IsIndeterminateArray(piArgument, "argument").
    end method.
    
    method public static void HasDeterminateExtent(input piArgument as int64 extent,
                                                           input pcName as character):
        if extent(piArgument) eq ? then
            undo, throw new AssertionFailedError(substitute('&1 array cannot be indeterminate', pcName), 0).
    end method.

    method public static void HasDeterminateExtent(input piArgument as int64 extent):
        HasDeterminateExtent(piArgument, "argument").
    end method.
    
    method public static void IsIndeterminateArray(input piArgument as int64 extent,
                                                           input pcName as character):
        if extent(piArgument) ne ? then 
            undo, throw new AssertionFailedError(substitute('&1 array must be indeterminate', pcName), 0).
    end method.

    method public static void IsIndeterminateArray(input piArgument as int64 extent):
        IsIndeterminateArray(piArgument, "argument").
    end method.
        

end class. /************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : AssertError
    Purpose     : Assertions specific to error messages
    Syntax      : 
    Description : 
    Author(s)   : psajja
    Created     : Tue Dec 16 12:30:23 IST 2014
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using OpenEdge.Core.AssertionFailedError.

class OpenEdge.Core.Assertion.AssertError: 

    /** Asserts that last executed statement raised an error message.
        
        @throws AssertionFailedError Error thrown if no error message exists */
    method public static void HasErrorMessage():
        if error-status:num-messages eq 0 then
             undo, throw new AssertionFailedError('Error message must exist.', 0).
    end method.
    
    /** Asserts that last executed statement raised no error message.
        
        @throws AssertionFailedError Error thrown if error message exists */
    method public static void NoErrorMessage():
        if error-status:num-messages > 0 then
             undo, throw new AssertionFailedError('Error message must not exist.', 0).
    end method.
    
    /** Asserts that last executed statement raised an error.
        
        @throws AssertionFailedError Error thrown if no error exists */
    method public static void HasErrorStatus():
        if not error-status:error then
             undo, throw new AssertionFailedError('Error must exist.', 0).
    end method.
    
    /** Asserts that last executed statement raised no error.
        
        @throws AssertionFailedError Error thrown if error exists */
    method public static void NoErrorStatus():
        if error-status:error then
             undo, throw new AssertionFailedError('Error must not exist.', 0).
    end method.
end class./************************************************
Copyright (c)  2014, 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : AssertFile
    Purpose     : Assertions specific to files 
    Syntax      : 
    Description : 
    Author(s)   : psajja
    Created     : Tue Dec 16 11:25:36 IST 2014
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using OpenEdge.Core.AssertionFailedError.
using OpenEdge.Core.Assert.

class OpenEdge.Core.Assertion.AssertFile: 

    /** Asserts that a file has exists.
        
        @param character The name of the directory being checked
        @throws AssertionFailedError Error thrown if the file does not exist */
    method public static void DirectoryExists(input pcName as character):
        Assert:NotNullOrEmpty(pcName).
        assign file-info:file-name = pcName.
        if file-info:file-type eq ? or (not file-info:file-type begins 'D':u) then
            undo, throw new AssertionFailedError(substitute('Directory &1 must exist', pcName), 0).
    end method.

    /** Asserts that a file has exists.
        
        @param character The name of the file being checked
        @throws AssertionFailedError Error thrown if the file does not exist */
    method public static void FileExists(fileName as character):
        Assert:NotNullOrEmpty(fileName).
        file-info:file-name = fileName.
        if file-info:file-type = ? or (not file-info:file-type begins "F") then
            undo, throw new AssertionFailedError(substitute('File &1 must exist.', fileName), 0).
    end method.
    
    /** Asserts that a file has exists in propath.
        
        @param character The name of the file being checked
        @throws AssertionFailedError Error thrown if the file does not exist */
    method public static void FileInPropath(fileName as character):
        Assert:NotNullOrEmpty(fileName).
        if search(fileName) eq ? then
            undo, throw new AssertionFailedError(substitute('File &1 must exist in propath.', fileName), 0).
    end method.
end class./************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : AssertJson
    Purpose     : Assertions specific to JSON constructs
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 05 16:37:30 EST 2014
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.AssertionFailedError.
using Progress.Json.ObjectModel.JsonObject.
using OpenEdge.Core.Assert.
using OpenEdge.Core.Assertion.AssertJson.
using OpenEdge.Core.JsonDataTypeEnum.

class OpenEdge.Core.Assertion.AssertJson:
    
    /** Asserts that a Json object has a particularly-named property (of any type).
        
        @param JsonObject The JSON object being checked
        @param character The name of the property being checked
        @throws AssertionFailedError Error thrown if the property does not exist */
    method public static void HasProperty(input poObject as JsonObject, input pcName as character):
        Assert:NotNull(poObject, 'JSON Object').
        Assert:NotNullOrEmpty(pcName, 'Property name').
        
        if not poObject:Has(pcName) then
            return error new AssertionFailedError(
                            substitute('JSON Object does not have a property named ~'&1~'', pcName) , 0).
    end method.

    /** Asserts that a the value of a property is null
        
        @param JsonObject The JSON object being checked
        @param character The name of the property being checked
        @throws AssertionFailedError Error thrown if the property does not exist */
    method public static void PropertyIsNull(input poObject as JsonObject, input pcName as character):
        AssertJson:HasProperty(poObject, pcName).
        
        if not poObject:IsNull(pcName) then
            return error new AssertionFailedError(
                            substitute('Property ~'&1~' must be null', pcName) , 0).
    end method.
    
    /** Asserts that a the value of a property is not null
        
        @param JsonObject The JSON object being checked
        @param character The name of the property being checked
        @throws AssertionFailedError Error thrown if the property does not exist */
    method public static void PropertyNotNull(input poObject as JsonObject, input pcName as character):
        AssertJson:HasProperty(poObject, pcName).
        
        if poObject:IsNull(pcName) then
            return error new AssertionFailedError(
                            substitute('Property ~'&1~' must not be null', pcName) , 0).
    end method.

    /** Asserts that a JSON Object has a particularly-named property of a 
        particular type.
        
        @param JsonObject The JSON object being checked
        @param character The name of the property being checked
        @param JsonDataTypeEnum The data type being checked
        @throws AssertionFailedError Error thrown if the property does not exist */
    method public static void PropertyIsType(input poObject as JsonObject,
                                             input pcName as character,
                                             input poPropertyType as JsonDataTypeEnum):
        AssertJson:HasProperty(poObject, pcName).
        Assert:NotNull(poPropertyType, 'Property type').
        
        if not poObject:GetType(pcName) eq integer(poPropertyType) then
            return error new AssertionFailedError(
                            substitute('Property ~'&1~' must be of type &2',
                                            pcName,
                                            string(poPropertyType)) , 0).
    end method.
    
end class./************************************************
Copyright (c)  2014, 2016 by Progress Software Corporation. All rights reserved.
*************************************************/ 
 /*------------------------------------------------------------------------
    File        : AssertObject
    Purpose     : Assertions specific to Object(s) 
    Syntax      : 
    Description : 
    Author(s)   : psajja
    Created     : Tue Dec 16 12:28:50 IST 2014
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.

using OpenEdge.Core.AssertionFailedError.
using Progress.Lang.Object.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Assert.
using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.DataTypeEnum.
using OpenEdge.Core.DataTypeHelper.
using OpenEdge.Core.Assertion.AssertObject.

class OpenEdge.Core.Assertion.AssertObject: 

    /** Asserts that two objects are equal.
        
        @param a expected value Object
        @param b the value of Object being expected
        @throws AssertionFailedError Error thrown if they are not equal*/
    method public static void Equals(input a as Object, input b as Object):
        define variable failMessage as character no-undo.
        if not a:Equals(b) then
        do:
            failMessage = "Expected: " + string(a) + " but was: " + string(b).
            return error new AssertionFailedError(failMessage, 0).
        end.        
    end method.
    
    /** Asserts that two objects are not equal.
        
        @param a expected value Object
        @param b the value of Object being expected
        @throws AssertionFailedError Error thrown if they are equal*/
    method public static void NotEqual(input a as Object, input b as Object):
        if a:Equals(b) then
            return error new AssertionFailedError(substitute('&1 and &2 are equal', a:ToString(), b:ToString()), 0).
    end method.
    
    /** Asserts that the object is not null.
        
        @param poArgument the Object to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if Object is null*/
    method public static void NotNull(input poArgument as Object , pcName as char):
        if not valid-object(poArgument) then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.

    /** Asserts that the object is not null.
        
        @param poArgument the Object to check
        @throws AssertionFailedError Error thrown if Object is null*/
    method public static void NotNull(input poArgument as Object):
        NotNull(poArgument, "argument").
    end method.
    
    /** Asserts that the object is null.
        
        @param poArgument the Object to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if Object is not null*/
    method public static void IsNull(input poArgument as Object , input pcName as character):
        if valid-object(poArgument) then
            undo, throw new AssertionFailedError(substitute('&1 must be null', pcName), 0).
    end method.

    /** Asserts that the object is null.
        
        @param poArgument the Object to check
        @throws AssertionFailedError Error thrown if Object is not null*/
    method public static void IsNull(input poArgument as Object):
        IsNull(poArgument, "argument").
    end method.
    
    /** Asserts that the object array is not null.
        
        @param poArgument the Object array to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if Object is null*/
    method public static void NotNull(input poArgument as Object extent, pcName as char):
        if extent(poArgument) eq ? then
            undo, throw new AssertionFailedError(substitute('&1 cannot be null', pcName), 0).
    end method.

    /** Asserts that the object array is not null.
        
        @param poArgument the Object array to check
        @throws AssertionFailedError Error thrown if Object is null*/
    method public static void NotNull(input poArgument as Object extent):
        NotNull(poArgument, "argument").
    end method.
    
    /** Asserts that the object array is null.
        
        @param poArgument the Object array to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if Object is not null*/
    method public static void IsNull(input poArgument as Object extent, pcName as char):
        if extent(poArgument) ne ? then
            undo, throw new AssertionFailedError(substitute('&1 must be null', pcName), 0).
    end method.
    
    /** Asserts that the object array is null.
        
        @param poArgument the Object array to check
        @throws AssertionFailedError Error thrown if Object is not null*/
    method public static void IsNull(input poArgument as Object extent):
        IsNull(poArgument, "argument").
    end method.
    
    /** Asserts that the given collection is not null or empty.
        
        @param poArgument the ICollection object to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if the collection object is null or empty*/
    method public static void NotNullOrEmpty(input poArgument as ICollection, pcName as char):
        Assert:NotNull(input poArgument, input pcName).

        if poArgument:Size eq 0 then
            undo, throw new AssertionFailedError(substitute('&1 cannot be empty: collection must have at least one entry', pcName), 0).
    end method.

    /** Asserts that the given collection is not null or empty.
        
        @param poArgument the ICollection object to check
        @throws AssertionFailedError Error thrown if the collection object is null or empty*/
    method public static void NotNullOrEmpty(input poArgument as ICollection):
        NotNullOrEmpty(poArgument, "argument").
    end method.
    
    /** Asserts that the given map is not null or empty.
        
        @param poArgument the IMap object to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if the map object is null or empty*/
    method public static void NotNullOrEmpty(input poArgument as IMap, pcName as char):
        Assert:NotNull(input poArgument, input pcName).

        if poArgument:Size eq 0 then
            undo, throw new AssertionFailedError(substitute('&1 cannot be empty: map must have at least one entry', pcName), 0).
    end method.

    /** Asserts that the given map is not null or empty.
        
        @param poArgument the IMap object to check
        @throws AssertionFailedError Error thrown if the map object is null or empty*/
    method public static void NotNullOrEmpty(input poArgument as IMap):
        NotNullOrEmpty(poArgument, "argument").
    end method.
    
    /** Asserts that the given object array is not null or empty.
        
        @param poArgument the Object array to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if the object array is null or empty*/
    method public static void NotNullOrEmpty(input poArgument as Object extent, pcName as char):
        Assert:NotNull(input poArgument, pcName).

        if not valid-object(poArgument[1]) then
            undo, throw new AssertionFailedError(substitute('&1 cannot be empty: array must have at least one valid extent', pcName), 0).
    end method.

    /** Asserts that the given object array is not null or empty.
        
        @param poArgument the Object array to check
        @throws AssertionFailedError Error thrown if the object array is null or empty*/
    method public static void NotNullOrEmpty(input poArgument as Object extent):
        NotNullOrEmpty(poArgument, "argument").
    end method.
    
    /** Asserts that the given type is an interface.
        
        @param poArgument the type to check
        @throws AssertionFailedError Error thrown if the type is not an interface*/
    method public static void IsInterface(input poArgument as Progress.Lang.Class):
        Assert:NotNull(input poArgument, 'Type').
        if not poArgument:IsInterface() then
            undo, throw new AssertionFailedError(substitute('&1 is not an interface', poArgument:TypeName), 0).
    end method.
    
    /** Asserts that the given type is not an interface.
        
        @param poArgument the type to check
        @throws AssertionFailedError Error thrown if the type is an interface*/
    method public static void NotInterface(input poArgument as Progress.Lang.Class):
        Assert:NotNull(input poArgument, 'Type').
        if poArgument:IsInterface() then
            undo, throw new AssertionFailedError(substitute('&1 is an interface', poArgument:TypeName), 0).
    end method.

    /** Asserts that the given type is an abstract.
        
        @param poArgument the type to check
        @throws AssertionFailedError Error thrown if the type is not abstract*/
    method public static void IsAbstract(input poArgument as Progress.Lang.Class):
        Assert:NotNull(input poArgument, 'Type').
        if not poArgument:IsAbstract() then
            undo, throw new AssertionFailedError(substitute('&1 is not an abstract type', poArgument:TypeName), 0).        
    end method.

    /** Asserts that the given type is not an abstract.
        
        @param poArgument the type to check
        @throws AssertionFailedError Error thrown if the type is abstract*/
    method public static void NotAbstract(input poArgument as Progress.Lang.Class):
        Assert:NotNull(input poArgument, 'Type').
        if poArgument:IsAbstract() then
            undo, throw new AssertionFailedError(substitute('&1 is an abstract type', poArgument:TypeName), 0).        
    end method.

    /** Asserts that the given type is final.
        
        @param poArgument the type to check
        @throws AssertionFailedError Error thrown if the type is final*/
    method public static void IsFinal(input poArgument as Progress.Lang.Class):
        Assert:NotNull(input poArgument, 'Type').
        if not poArgument:IsFinal() then
            undo, throw new AssertionFailedError(substitute('&1 is not a final type', poArgument:TypeName), 0).
    end method.

    /** Asserts that the given type is not final.
        
        @param poArgument the type to check
        @throws AssertionFailedError Error thrown if the type is final*/
    method public static void NotFinal(input poArgument as Progress.Lang.Class):
        Assert:NotNull(input poArgument, 'Type').
        if poArgument:IsFinal() then
            undo, throw new AssertionFailedError(substitute('&1 is a final type', poArgument:TypeName), 0).                        
    end method.
    
    /** Asserts that a object extent is valid and of a particular type for each array item
        
        @param poArgument The Object being checked.
        @param poType The type the being checked.
        @throws AssertionFailedError Error thrown if the object array is not valid any of the array 
            item is not of particular type.*/
    method public static void IsType(input poArgument as Object extent, poType as Progress.Lang.Class):
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        if extent(poArgument) eq ? then
            undo, throw new AssertionFailedError('argument cannot be an indeterminate array', 0).
        
        iMax = extent(poArgument).
        do iLoop = 1 to iMax:
            Assert:IsType(poArgument[iLoop], poType).
        end.
    end method.

    /** Asserts that a object is valid and of a particular type
        
        @param poArgument The Object being checked.
        @param poType The type the being checked.
        @throws AssertionFailedError Error thrown if the object is not valid and not of particular type.*/
    method public static void IsType(input poArgument as Object, poType as Progress.Lang.Class):
        define variable oDerivedClass as Progress.Lang.Class no-undo.
        
        Assert:NotNull(poArgument, 'argument').
        Assert:NotNull(poType, 'type').
        
        if type-of(poArgument, Progress.Lang.Class) then 
            oDerivedClass = cast(poArgument, Progress.Lang.Class).
        else
            oDerivedClass = poArgument:GetClass().
        
        if not oDerivedClass:IsA(poType) then
            undo, throw new AssertionFailedError(
                    substitute('Object &1 (of type &2) is not of type &3',
                        poArgument:ToString(),
                        oDerivedClass:TypeName,
                        poType:TypeName), 0).
    end method.
    
    /** Asserts that a object is valid and not of a particular type
        
        @param poArgument The Object being checked.
        @param poType The type the being checked.
        @throws AssertionFailedError Error thrown if the object is not valid and of particular type.*/
    method public static void NotType(input poArgument as Object, poType as Progress.Lang.Class):
        define variable oDerivedClass as Progress.Lang.Class no-undo.
        
        Assert:NotNull(poArgument, 'argument').
        Assert:NotNull(poType, 'type').
        
        if type-of(poArgument, Progress.Lang.Class) then 
            oDerivedClass = cast(poArgument, Progress.Lang.Class).
        else
            oDerivedClass = poArgument:GetClass().
        
        if oDerivedClass:IsA(poType) then
            undo, throw new AssertionFailedError(
                    substitute('Object &1 (of type &2) is of type &3',
                        poArgument:ToString(),
                        oDerivedClass:TypeName,
                        poType:TypeName), 0).
    end method.
    
    /** Asserts that a handle is valid and of a particular datatype
        
        @param phArgument The handle being checked.
        @param poCheckType The type the handle/variable being checked should be.
        @param pcName The name of the variable/handle.   
        @throws AssertionFailedError Error thrown if the handle is not valid or not of a particular datatype.*/
    method public static void IsType(input phArgument as handle,
                                     input poCheckType as DataTypeEnum,
                                     input pcName as character):
        define variable cCheckType as character no-undo.
        
        Assert:NotNull(phArgument, pcName).
        Assert:NotNull(poCheckType, 'Check DataType').
        
        assign cCheckType = DataTypeHelper:GetMask(poCheckType).
        if phArgument:type ne cCheckType then
            undo, throw new AssertionFailedError(substitute('&1 is not of type &2', pcName, cCheckType), 0).        
    end method.

    /** Asserts that a handle is valid and of a particular datatype
        
        @param phArgument The handle being checked.
        @param poCheckType The type the handle/variable being checked should be.
        @throws AssertionFailedError Error thrown if the handle is not valid or not of a particular datatype*/
    method public static void IsType(input phArgument as handle,
                                     input poCheckType as DataTypeEnum):
        IsType(phArgument, poCheckType, "argument").
    end method.
    
    /** Asserts that a handle is valid and not of a particular datatype
        
        @param phArgument The handle being checked.
        @param poCheckType The type the handle/variable being checked should be.
        @param pcName the identifying name for the AssertionFailedError.
        @throws AssertionFailedError Error thrown if the handle is not valid or of a particular datatype*/
    method public static void NotType(input phArgument as handle,
                                      input poCheckType as DataTypeEnum,
                                      input pcName as character):
        define variable cCheckType as character no-undo.
        
        Assert:NotNull(phArgument, pcName).
        Assert:NotNull(poCheckType, 'Check DataType').
        
        assign cCheckType = DataTypeHelper:GetMask(poCheckType).
        if phArgument:type eq cCheckType then
            undo, throw new AssertionFailedError(substitute('&1 cannot be of type &2', pcName, cCheckType), 0).
    end method.

    /** Asserts that a handle is valid and not of a particular datatype
        
        @param phArgument The handle being checked.
        @param poCheckType The type the handle/variable being checked should be.
        @throws AssertionFailedError Error thrown if the handle is not valid or of a particular datatype*/
    method public static void NotType(input phArgument as handle,
                                             input poCheckType as DataTypeEnum):
        NotType(phArgument, poCheckType, "argument").
    end method.

    /** Asserts that the given object array has indeterninate extent.
        
        @param poArgument the Object array to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if the object array extent is determinate*/
    method public static void IsIndeterminateArray(input poArgument as Object extent,
                                                           input pcName as character):
        if extent(poArgument) ne ? then
            undo, throw new AssertionFailedError(substitute('&1 array must be indeterminate', pcName), 0).
    end method.

    /** Asserts that the given object array has indeterninate extent.
        
        @param poArgument the Object array to check
        @throws AssertionFailedError Error thrown if the object array extent is determinate*/
    method public static void IsIndeterminateArray(input poArgument as Object extent):
        IsIndeterminateArray(poArgument, "argument").
    end method.
    
    /** Asserts that the given object array has deterninate extent.
        
        @param poArgument the Object array to check
        @param pcName the identifying name for the AssertionFailedError
        @throws AssertionFailedError Error thrown if the object array extent is not determinate*/
    method public static void HasDeterminateExtent(input poArgument as Object extent,
                                                           input pcName as character):
        if extent(poArgument) eq ? then
            undo, throw new AssertionFailedError(substitute('&1 array cannot be indeterminate', pcName), 0).
    end method.
    
    /** Asserts that the given object array has deterninate extent.
        
        @param poArgument the Object array to check
        @throws AssertionFailedError Error thrown if the object array extent is not determinate*/
    method public static void HasDeterminateExtent(input poArgument as Object extent):
        HasDeterminateExtent(poArgument, "argument").
    end method.
    
    /* Asserts that the given object can be serialized.
       
       @param Obejct The object to check. */
    method public static void IsSerializable(input poArgument as Object):
        define variable oDerivedClass as Progress.Lang.Class no-undo.
        
        Assert:NotNull(poArgument, 'argument').
        
        if type-of(poArgument, Progress.Lang.Class) then 
            oDerivedClass = cast(poArgument, Progress.Lang.Class).
        else
            oDerivedClass = poArgument:GetClass().
        
        if not oDerivedClass:IsSerializable() then
            undo, throw new AssertionFailedError(
                    substitute('Object &1 (of type &2) is not serializable',
                        poArgument:ToString(),
                        oDerivedClass:TypeName), 0).
    end method.
    
    /* Asserts that the given object cannot be serialized.
       
       @param Obejct The object to check. */
    method public static void NotSerializable(input poArgument as Object):
        define variable oDerivedClass as Progress.Lang.Class no-undo.
        
        Assert:NotNull(poArgument, 'argument').
        
        if type-of(poArgument, Progress.Lang.Class) then 
            oDerivedClass = cast(poArgument, Progress.Lang.Class).
        else
            oDerivedClass = poArgument:GetClass().
        
        if oDerivedClass:IsSerializable() then
            undo, throw new AssertionFailedError(
                    substitute('Object &1 (of type &2) is serializable',
                        poArgument:ToString(),
                        oDerivedClass:TypeName), 0).
    end method.    
end class./************************************************
Copyright (c) 2013-2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------------
    File        : AbstractTTCollection
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Sun Dec 16 22:41:40 EST 2007
    Notes       : This is an ABL specific abstraction that uses only dynamic 
                  constructs to access temp-tables and buffers in order to 
                  allow it to be reused by subclasses that have different 
                  temp-tables.  
                - The most important behavioral encapsulation/reuse provided by 
                  this is the management of the size().               
------------------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.Iterator.
using Progress.Lang.Object.
 
class OpenEdge.Core.Collections.AbstractTTCollection abstract serializable 
        implements ICollection: 
    
   /*---------------------------------------------------------------------------
    Purpose: Abstract collection class                                                                
    Notes:   All temp-table operations are dynamic
             Subclasses should define internal temp-table and pass the 
             handle to super the constructor. They must override 
             findBufferUseObject (see below) and could also override other 
             methods with static code for performance.                   
    --------------------------------------------------------------------------*/
    define private variable mhTempTable     as handle no-undo. 
    define private variable mhDefaultBuffer as handle no-undo.      
    define private variable mhField         as handle no-undo. 
    define private variable mhDefaultQry    as handle no-undo.

    define public property Size as integer no-undo get. private set.
    
    constructor public AbstractTTCollection():
        /* default public ctor for Serialization only */
    end constructor.
        
    /* pass Collection  */ 
    constructor protected AbstractTTCollection (poCol as ICollection,phtt as handle,pcField as char):
        this-object(phtt,pcField).
        poCol:ToTable(output table-handle phtt).
        Size = poCol:Size.  
    end constructor.
    
    /* pass temp-table handle and name of object field */ 
    constructor protected AbstractTTCollection ( phtt as handle, pcField as char ):
        this-object(phtt,phtt:default-buffer-handle:buffer-field(pcField)).
    end constructor.

    /* pass temp-table handle and object field */ 
    constructor protected AbstractTTCollection (phtt as handle, hField as handle ):
        super ().
        assign
            mhTempTable     = phtt
            mhDefaultBuffer = phtt:default-buffer-handle
            mhField         = hField.
    end constructor.
    
    destructor AbstractTTCollection():
        if valid-handle(mhDefaultQry) then
            delete object mhDefaultQry no-error.
    end destructor.
    
    method public logical Add( newObject as Object):
        if valid-object(newObject) then
        do:
            mhDefaultBuffer:buffer-create().
            assign
                mhField:buffer-value = newObject  
                Size = Size + 1.    
            mhDefaultBuffer:buffer-release().
            return true.
        end.
        return false.
    end method.
    
    method public logical AddArray(objectArray as Object extent):
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        iMax = extent(objectArray).
        do iLoop = 1 to iMax:
            this-object:Add(objectArray[iLoop]).
        end.
        
        return true.
    end method.
    
    method public logical AddAll(newCollection as ICollection):
        define variable iterator as IIterator no-undo.
        if newCollection:getClass():Equals(getClass()) then
        do:
            newCollection:ToTable(output table-handle mhTempTable append).
            Size = Size + newCollection:Size.
        end.
        else do:
            iterator = newCollection:iterator(). 
            do while iterator:hasNext():
                this-object:Add(iterator:Next()).
            end.                                       
        end.    
        return true. 
    end method.
    
    method public void Clear(  ):
        mhTempTable:default-buffer-handle:empty-temp-table.
        assign this-object:Size = 0.        
    end method.
    
    method public logical Contains( checkObject as Object ):
        FindBufferUseObject(checkObject).
        return (mhDefaultBuffer:available).
    end method.
    
    method public logical ContainsAll(input poCollection as ICollection):
        define variable oIterator as IIterator.
        
        Assert:NotNull(poCollection, 'Collection to check').
        
        /* if the 'check' collection is empty, then true */  
        if poCollection:IsEmpty() then
            return true.
        
        /* if the passed in collection is larger than this collection,
           this cannot be true. */
        if poCollection:Size gt this-object:Size then
            return false.
        
        /* one or both collections has data */
        oIterator = poCollection:Iterator().
        do while oIterator:HasNext():
            if not this-object:Contains(oIterator:Next()) then
                return false.
        end.
        
        return true.
    end method.
    
    /* Returns a new IIterator over the collection. */
    method public IIterator Iterator( ):    
        return new Iterator(this-object,mhTempTable,mhField:name).
    end method.
    
    method public logical IsEmpty(  ):
        return not (mhTempTable:has-records).
    end method.

    method public void ToTable( output table-handle tt ):
        tt = mhTempTable.
    end method.
    
    method public logical Remove( oldObject as Object ):
        FindBufferUseObject(oldObject).
        if mhDefaultBuffer:avail then
        do:
            mhDefaultBuffer:buffer-delete(). 
            Size = Size - 1.
            return true.
        end.    
        return false.
    end method.
    
    method public logical RemoveAll(collection as ICollection):
        define variable iterator as IIterator. 
        define variable oRemove  as Object. 
        define variable lAny as logical no-undo.        
        iterator = collection:iterator().
        do while iterator:HasNext():
            oRemove = iterator:Next().
            do while Remove(oRemove):
                lAny = true.
            end.
        end.
        return lAny.
    end method.
    
    method public logical RetainAll(oCol as ICollection):
        define variable iterator as IIterator no-undo.
        define variable oChild as Object no-undo.  
        define variable lAny as logical no-undo.        
        iterator = Iterator().
        do while iterator:HasNext():
            oChild = iterator:Next().
            if not oCol:Contains(oChild) then 
            do:
                do while Remove(oChild):
                    lAny = true.
                end.
            end.     
        end.                                     
        return lAny.     
    end method.
    
    /* ToArray should not be used with large collections
       If there is too much data the ABL will throw:  
       Attempt to update data exceeding 32000. (12371) */
    method public Object extent ToArray():
        define variable i as integer no-undo.
        define variable oObjArray as Object extent no-undo.
        define variable iterator as IIterator no-undo.   
        
        if Size eq 0 then
            return oObjArray.
        
        assign extent(oObjarray) = Size
               iterator          = Iterator()
               . 
        do while iterator:hasNext():
           assign i = i + 1
                  oObjArray[i] = iterator:Next().
        end.
        
        return oObjArray.
    end method.
    
    /* override this in subclass - used by remove(obj) and others   */
    method abstract protected void FindBufferUseObject (obj as Object).
    
    /* Deep clone. or rather deep enough since we don't know what the elements' Clone()
       operations do, so this may end up being a memberwise clone */
    method override public Object Clone():
        define variable oClone as ICollection no-undo.
        
        oClone = cast(this-object:GetClass():New(), ICollection).
        CloneElements(oClone).
        
        return oClone.        
    end method.
    
    method protected void CloneElements(input poClone as ICollection):
        define variable oIterator as IIterator no-undo. 

        oIterator = this-object:Iterator().
        do while oIterator:HasNext():
           poClone:Add(oIterator:Next():Clone()).
        end.
    end method.
    
    /** Recalculates the Size of this collections.
        
        Used particularly by Lists since there are operations
        like Remove() that are index-based and not item-based. */
    method protected void Resize():
        if not valid-handle(mhDefaultQry) then
        do:
            create query mhDefaultQry.
            mhDefaultQry:set-buffers(mhDefaultBuffer).
            mhDefaultQry:query-prepare(substitute('preselect each &1 no-lock', mhDefaultBuffer:name)).
        end.
        
        mhDefaultQry:query-open().
        assign this-object:Size = mhDefaultQry:num-results. 
        
        finally:
            mhDefaultQry:query-close().
            // the mhDefaultQry handle is deleted in the destructor
        end finally.
    end method.
    
end class.
/************************************************
Copyright (c) 2013-2014, 2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : Array
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Jun 14 11:35:49 EDT 2012
    Notes       : * Based on the AutoEdge|TheFactory version 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.Collections.Array.
using OpenEdge.Core.Collections.ArrayIterator.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.ResizeError.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.Array serializable 
        implements ICollection:
    
    /* only ever used for ToTable() */
    define static private temp-table ttArray no-undo
        field ObjIndex as integer
        field ObjRef as Object
        index idx1 as primary unique ObjIndex.
    
    define public static variable DefaultArraySize as integer no-undo.
    
    /* Keep incrementally growing array Size as new elements are added. AutoExpanded
       ararys will grow by 50% of the current size each time. 
       
       This will negatively impact performance. */
    define public property AutoExpand as logical no-undo get. set.
    
    /* If true, we'll discard stuff off the bottom of the stack if
       we resize the stack smaller than its contents. */
    define public property DiscardOnShrink as logical no-undo get. set.
    
    define protected property Value as Object extent no-undo get. private set.
    
    define public property Size as integer no-undo
        get():
            return extent(this-object:Value).
        end.
        set(input piSize as integer):
            SetArraySize(piSize).
        end.
    
    constructor static Array():
        Array:DefaultArraySize = 10.
    end constructor.
    
    constructor public Array(input piSize as integer):
        assign Size = piSize
               AutoExpand = false
               DiscardOnShrink = false.
    end constructor.

    constructor public Array(input poArray as Object extent):
        this-object(extent(poArray)).
        this-object:AddArray(poArray).
    end constructor.
    
    constructor public Array():
        this-object(Array:DefaultArraySize).
    end constructor.
    
    method private void SetArraySize(input piNewSize as integer):
        define variable oTempObject as Object extent no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        /* do nothing if there's nothing to do */
        if piNewSize eq ? then
        do:
            if not DiscardOnShrink then
                undo, throw new ResizeError('Array', 'smaller'). 
            extent(this-object:Value) = piNewSize.            
        end.
        else
        if piNewSize ne this-object:Size then
        do:
            if piNewSize lt this-object:Size and not DiscardOnShrink then
                undo, throw new ResizeError('Array', 'smaller'). 
            
            /* if this is an indeterminate array, then do nothing */
            if this-object:Size eq ? then
                assign iMax = 0.
            else
                assign extent(oTempObject) = this-object:Size
                       oTempObject = this-object:Value
                       iMax = this-object:Size
                       extent(this-object:Value) = ?.
            extent(this-object:Value) = piNewSize.
            
            /* On init this loop won't execute */
            do iLoop = 1 to iMax:
                SetValue(oTempObject[iLoop], iLoop).
            end.
        end.
    end method.
    
    method public void SetValue(input poValue as Object):
        SetValue(poValue, (this-object:Size + 1)).
    end method.

    method public Object GetValue(input piExtent as integer):
        Assert:NotNullOrZero(piExtent, 'Extent').
        return this-object:Value[piExtent].
    end method.
    
    method public void SetValue(input poValue as Object,
                                input piExtent as integer):
        /* Expand array, if allowed and needed */
        if piExtent gt this-object:Size then
        do:
            if AutoExpand then            
                SetArraySize(integer(piExtent + round(0.5 * this-object:Size, 0))).
            else
                undo, throw new ResizeError('Array','larger').
        end.
        
        assign this-object:Value[piExtent] = poValue.
    end method.
    
    /* ICollection */
    method public logical Add(input o as Object):
        SetValue(o).
        return true.
    end method.

    method public logical AddAll(input c as ICollection):
        return AddArray(c:ToArray()).
    end method.

    method public logical AddArray(input c as Object extent):
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable iStartSize as integer no-undo.
        
        iMax = extent(c).
        /* manually resize the array, don't auto-increment */
        iStartSize = this-object:Size.
        SetArraySize(iStartSize + iMax).
        do iLoop = 1 to iMax:
            SetValue(c[iLoop], iStartSize + iLoop).
        end.
        
        return true.
    end method.

    method public void Clear():
        SetArraySize(?).
    end method.
    
    method public logical Contains( input o as Object):
        define variable lContainsArgument as logical no-undo.
        define variable iMax as integer no-undo.
        define variable iLoop as integer no-undo.
        
        iMax = this-object:Size.
        do iLoop = 1 to iMax while not lContainsArgument:
            lContainsArgument = this-object:Value[iLoop]:Equals(o).
        end.
        
        return lContainsArgument.
    end method.
    
    /** Returns true if this list contains all of the elements of the
        specified collection.
        
        @param ICollection The collection of objects to check
        @return logical True if all the elements match */
    method public logical ContainsAll(input poCollection as ICollection).
        define variable oIterator as IIterator.
        
        Assert:NotNull(poCollection, 'Check collection').
        
        /* if the 'check' collection is empty, then true */  
        if poCollection:IsEmpty() then
            return true.
        
        /* if the passed in collection is larger than this collection,
           this cannot be true. */
        if poCollection:Size gt this-object:Size then
            return false.
        
        assign oIterator = poCollection:Iterator().
        do while oIterator:HasNext():
            if not this-object:Contains(oIterator:Next()) then
                return false.
        end.
        
        return true.
    end method.   

    method public IIterator Iterator( ):
        define variable oArrayIterator as IIterator no-undo.
        return new ArrayIterator(this-object).
    end method.

    method public logical IsEmpty(  ):
        return (this-object:Size eq ?).
    end method.

    method public logical Remove( input o as Object ):
        define variable lRemoved as logical no-undo.
        define variable iMax as integer no-undo.
        define variable iLoop as integer no-undo.
        
        iMax = this-object:Size.
        do iLoop = 1 to iMax while not lRemoved:
            if this-object:Value[iLoop]:Equals(o) then
                assign this-object:Value[iLoop] = ?
                       lRemoved                 = true
                       .
        end.
        
        return lRemoved.
    end method.
    
    method public logical RemoveAll( input c as ICollection):
        define variable oIterator as IIterator.
        define variable oRemove  as Object. 
        define variable lAny as logical no-undo.
        
        oIterator = c:Iterator().
        do while oIterator:HasNext():
            oRemove = oIterator:Next().
            do while this-object:Remove(oRemove):
                lAny = true.
            end.
        end.
        
        return lAny.
    end method.

    method public logical RetainAll( input oCollection as ICollection ):
        define variable oIterator as IIterator no-undo.
        define variable oChild as Object no-undo.  
        define variable lAny as logical no-undo.
        
        oIterator = Iterator().
        do while oIterator:HasNext():
            oChild = oIterator:Next().
            if not oCollection:Contains(oChild) then 
            do:
                do while Remove(oChild):
                    lAny = true.
                end.
            end.     
        end.                                     
        return lAny.     
    end method.

    method public void ToTable( output table-handle tt):
        define variable iMax as integer no-undo.
        define variable iLoop as integer no-undo.
        
        empty temp-table ttArray.
        iMax = this-object:Size.
        do iLoop = 1 to iMax:
            create ttArray.
            assign ttArray.ObjIndex = iLoop
                   ttArray.ObjRef = this-object:Value[iLoop]. 
        end.
        
        tt = temp-table ttArray:handle.
    end method.
    
    method public Object extent ToArray():
        return this-object:Value.
    end method.
    
    /* Deep clone. or rather deep enough since we don't know what the elements' Clone()
       operations do, so this may end up being a memberwise clone */
    method override public Object Clone():
        define variable oClone as ICollection no-undo.
        
        oClone = cast(this-object:GetClass():New(), ICollection).
        CloneElements(oClone).
        
        return oClone.        
    end method.
    
    method protected void CloneElements(input poClone as ICollection):
        define variable oIterator as IIterator no-undo. 

        oIterator = this-object:Iterator().
        do while oIterator:HasNext():
           poClone:Add(oIterator:Next():Clone()).
        end.
    end method.
    
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : ArrayIterator
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Jun 14 12:13:12 EDT 2012
    Notes       : * Based on the AutoEdge|TheFactory version
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.Array.
using OpenEdge.Core.Assert.

using Progress.Lang.Object.

class OpenEdge.Core.Collections.ArrayIterator implements IIterator:
    define protected property CurrentExtent as integer no-undo get. set.
    define protected property IteratedArray as Array no-undo  get. set .
    
    constructor public ArrayIterator(input poIteratedArray as Array):
        Assert:NotNull(poIteratedArray, 'Iterated Array').
        
        CurrentExtent = 0.
        IteratedArray = poIteratedArray.
    end method.
    
	method public logical HasNext():
		define variable lHasNext as logical no-undo.
		
		lHasNext = (CurrentExtent + 1) le IteratedArray:Size.
		
		return lHasNext.
	end method.

	method public Object Next():
	    define variable iGetExtent as integer no-undo.
	    
	    assign iGetExtent = CurrentExtent
	           CurrentExtent = CurrentExtent + 1.        
		return IteratedArray:GetValue(iGetExtent).
	end method.
	
	method public logical Remove():
        return IteratedArray:Remove(IteratedArray:GetValue(CurrentExtent)).
	end method.

end class./*------------------------------------------------------------------------
    File        : ClassClassMap
    Purpose     : Mapping of types
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Jan 29 09:51:35 EST 2015
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

{OpenEdge/Core/Collections/typedmapclass.i
    &Package        = OpenEdge.Core.Collections
    
    &MapType   = ClassClassMap
    &KeyType   = Progress.Lang.Class
    &ValueType = Progress.Lang.Class 
    }
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------------
    File        : Collection
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Sun Dec 16 22:41:40 EST 2007
    Notes       : 
------------------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.Collection.
using OpenEdge.Core.Collections.AbstractTTCollection.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.Collection serializable inherits AbstractTTCollection: 
   /*---------------------------------------------------------------------------
    Purpose: General collection class                                                                
    Notes:   
    --------------------------------------------------------------------------*/
     
    /* default temp-table  */ 
    define private temp-table ttCollection no-undo
      field objectref as Object
      index objidx objectref.
      
    constructor public Collection():
        super (temp-table ttCollection:handle,"objectref").
    end constructor.
    
    constructor public Collection (c as ICollection):
        super (c,temp-table ttCollection:handle, "objectref").
    end constructor.

    method public override logical Contains( checkObject as Object):
        define variable lContains as logical no-undo.
        define buffer lbCollection for ttCollection.
        
        if not valid-object(checkObject) then
            return false.
        
        /* try by-reference first */
        lContains = can-find(lbCollection where lbCollection.ObjectRef = checkObject). 
        for each lbCollection while lContains = false:
            lContains = lbCollection.ObjectRef:Equals(checkObject).
        end.
        
        return lContains.
    end method.

    method protected override void FindBufferUseObject ( o as Object ):
        find ttCollection where ttCollection.objectref eq o no-error.
        if available ttCollection then 
            return.
        
        for each ttCollection:
            if ttCollection.objectref:Equals(o) then
                return.
        end.
    end.
     
end class.
/************************************************
Copyright (c) 2013, 2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : EntrySet
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : apr 2010
    Notes       : no empty constructor, specialized for KeySet of IMap 
                 - Changes to the map are reflected here, and vice-versa. 
                 - Supports removal and removes the corresponding map entry from the map
                   (Iterator.remove, Collection.remove, removeAll, retainAll and clear) .
                 - Do not support add and addAll.   
                 - no empty constructor, specialised for IMap 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.MapBackedCollection.
using OpenEdge.Core.Collections.EntrySetIterator. 
using OpenEdge.Core.Collections.IIterator. 
using OpenEdge.Core.Collections.ISet.  
using OpenEdge.Core.Collections.IMapEntry.
using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Assert.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.EntrySet serializable inherits MapBackedCollection
            implements ISet:
    constructor public EntrySet (poMap as IMap,phTT as handle,pcKeyField as char):
        super (poMap,phTT,pcKeyField ).
    end constructor.
    
     /* Returns a new IIterator over the entryset. */
    method public override IIterator Iterator():    
        return new EntrySetIterator(
                    OwningMap,
                    this-object,
                    this-object:OwningBuffer,
                    this-object:KeyField:name).
    end method.
    
    /* abstract because this could be a key or value */
    method override public logical Contains( checkObject as Object):
        Assert:IsType(checkObject, get-class(IMapEntry)).
        
        return OwningMap:KeySet:Contains(cast(checkObject, IMapEntry):Key).
    end method.
    
    method override public logical ContainsAll(input poCollection as ICollection):
        define variable oIterator as IIterator no-undo.               
        define variable oEntry as Object    no-undo.
        
        Assert:NotNull(poCollection, 'Check collection').
        
        /* if the 'check' collection is empty, then true */  
        if poCollection:IsEmpty() then
            return true.
        
        /* if the passed in collection is larger than this collection,
           this cannot be true. */
        if poCollection:Size gt this-object:Size then
            return false.
        
        assign oIterator = poCollection:Iterator().
        do while oIterator:HasNext():
            oEntry = oIterator:Next().
            Assert:IsType(oEntry, get-class(IMapEntry)).
            
            if not OwningMap:ContainsKey(cast(oEntry, IMapEntry):Key) then
                return false.
        end.
        
        return true.
    end method.
    
    /* abstract because this could be a collection of keys or values */
    method override public logical Remove(poOld as Object):
        Assert:IsType(poOld, get-class(IMapEntry)).
        
        return OwningMap:KeySet:Remove(cast(poOld, IMapEntry):Key).
    end method.
    
    /* abstract because this could be a collection of keys or values */
    method override public logical RemoveAll(poRemoveCol as ICollection):
        define variable oIterator as IIterator no-undo.
        define variable oEntry as Object    no-undo.
        define variable oKey as Object    no-undo.
        define variable lRemoved as logical no-undo.
        
        oIterator = poRemoveCol:Iterator().
        do while oIterator:HasNext():
            oEntry = oIterator:Next().
            Assert:IsType(oEntry, get-class(IMapEntry)).
            
            oKey = OwningMap:Get(cast(oEntry, IMapEntry):Key).
            
            if cast(oEntry, IMapEntry):Key:Equals(oKey) then
                OwningMap:Remove(oKey).
        end.            

        return lRemoved.        
    end method.
    
    /* abstract because this could be a collection of keys or values */
    method override public logical RetainAll(input poRetainCollection as ICollection).
        define variable oIterator as IIterator no-undo.
        define variable oMapEntry as IMapEntry no-undo.
        define variable lAny as logical no-undo.   
        
        oIterator = this-object:Iterator().
        do while oIterator:HasNext():
            oMapEntry = cast(oIterator:Next(), IMapEntry).
            
            if not poRetainCollection:Contains(oMapEntry) then 
            do:
                do while Remove(oMapEntry):
                    lAny = true.
                end.
            end.
        end.
        return lAny.
    end method.
    
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : EntrySetIterator
    Purpose     : Iterator for entrysets
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Mon Apr 12 00:18:04 EDT 2010
    Notes       : The IMappedEntry Key Value are created in next().      
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.Collections.Iterator.
using OpenEdge.Core.Collections.MapEntry.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.EntrySetIterator inherits Iterator: 
    define protected property OwningMap as IMap no-undo get. set. 
    
    constructor public EntrySetIterator (poMap as IMap, poCol as ICollection, tt as handle,ofield as char):
        super(poCol,tt,ofield).  
        OwningMap = poMap.          
    end constructor. 
    
    method public override Object Next():
        define variable oKey as Object no-undo.
        oKey = super:Next().
        return new MapEntry(OwningMap,oKey). 
    end method.    
     
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ICollection
    Purpose     : A collection represents a group of objects, known as its 
                  elements.
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Sun Dec 16 20:04:13 EST 2007
    Notes       : All methods (and comments) except ToTable and AddArray 
                  are an exact match to Java Collection interface. 
                  Size is implemented as property
                  * Based on the AutOEdge|TheFactory version                                                                     
  ----------------------------------------------------------------------*/

using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterable.
using Progress.Lang.Object.

interface OpenEdge.Core.Collections.ICollection inherits IIterable:
    /** Returns the number of elements in this list. */
    define public property Size as integer no-undo get.
  
    /** Appends the specified element to list if not already present
    
        @param Object The element to add to the collection
        @return logical True if the operation succeeded. */
    method public logical Add(input poElement as Object).
     
    /** Appends all of the elements in the specified collection
       
        @param ICollection A collection of elements to add to the collection
        @return logical True if the operation succeeded. */
    method public logical AddAll(input poCollection as ICollection).
    
    /** Adds an array of elements to the collection 
       
        @param Object[] An array of elements to add to the collection
        @return logical True if the operation succeeded. */    
    method public logical AddArray(input poElements as Object extent).
    
    /** Removes all of the elements from this list */
    method public void Clear().
    
    /** Check whether the colleciton contains at least one object
        that matches the passed in object. 
        
        @param Object The object
        @return logical Returns true if the object is in the collection */
    method public logical Contains (input poElement as Object).
    
    /** Returns true if this list contains all of the elements of the
        specified collection.
        
        @param ICollection The collection of obejcts to check
        @return logical True if all the elements match */
   method public logical ContainsAll(input poCollection as ICollection). 
   
   /** Indicates whether this collection has any elements.
       
       @return logical True if the collection is empty. */ 
   method public logical IsEmpty().
   
   /** Removes the first occurrence in this list of the specified element
   
        @param Object The 
        @return logical True if the operation succeded. */
    method public logical Remove (input poElement as Object).
    
    /** Removes from this list all the elements that are contained in the
        specified collection (optional operation).
        
        @param ICollection The collection to remove.
        @return logical True if the operation succeeded. */
    method public logical RemoveAll (input poCollection as ICollection).
    
    /** Retains only the elements in this list that are contained in the
        specified collection (optional operation).
        
        @param ICollection The collection to retain
        @return Logical True if the object changed  */
    method public logical RetainAll (input poCollection as ICollection).
    
    /** Returns the contents of the collection as temp-table. This is a shallow
        copy of the collection - basically a new set of references is created.
    
        @param output table-handle The collection as a temp-table */
    method public void ToTable (output table-handle tt).
    
    /** Returns the contents of the collection as an array of objects.
    
        @return Object[] The collection returnes as an object array */
    method public Object extent ToArray ().
    
end interface.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IIterable
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Mon Dec 16 14:50:55 EST 2013
    Notes       : 
  ----------------------------------------------------------------------*/
using OpenEdge.Core.Collections.IIterator.
 
interface OpenEdge.Core.Collections.IIterable:
    /** Returns an iterator object.
     
        @param IIterator */
    method public IIterator Iterator().
end interface./************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IIterator
    Purpose     : traverses a collection forward 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     :  
    Notes       : * Based on the AutoEdge|TheFactory version
  ----------------------------------------------------------------------*/
using Progress.Lang.Object.

interface OpenEdge.Core.Collections.IIterator:
    /** Indicates whether there's another element
    
        @return Logical Trues if the iterator has anotehanother element */
    method public logical HasNext().
    
    /** Returns the next object in the iterator. Next being the next object
        at the iterator's current position. 
        
        @return Object The object at the 'next' position. */
    method public Object Next().
    
    /** Removes an entry from the iterator.
        
        @return logical True if the operation succeeeded. */
    method public logical Remove().
end interface.

 
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IList
    Purpose     : An ordered collection that gives control over where in the 
                  list each element is inserted. 
                  Allows elements to be accessed by their integer index in 
                  addition to by the element. 
    Description : 
    @author hdaniels
    Created     : Wed Jan 09 09:57:42 EST 2008
    Notes       : * All methods (and comments) except ToTable are an exact match to Java  
                    List interface. Size is implemented as property
                  * Based on the AutoEdge|TheFactory version                                 
  ----------------------------------------------------------------------*/
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator. 
using OpenEdge.Core.Collections.IListIterator. 
using OpenEdge.Core.Collections.IList. 
using Progress.Lang.Object.

interface OpenEdge.Core.Collections.IList inherits ICollection:  
   /** Inserts the specified element at the specified position in this list. 
       
       @param integer  The position at which to insert the object
       @param Object   The object to add
       @return Logical Returns true if the operation succeeded */
   method public logical Add(input piIndex as integer, input poElement as Object).   
   
   /* Inserts all of the elements in the specified collection into this list 
      at the specified position (optional operation).
      
      @param integer The iposition at which to add the collection
      @param ICollection the collection of objects to add
      @return logical True if the operation succeeded. */
   method public logical AddAll(input piIndex as integer,input poCollection as ICollection).
   
   /** Appends all the elements in the array this list, optionally
       at the specified position. */
   method public logical AddArray(input piIndex as integer, c as Object extent).
   
   /** Returns the element at the specified position in this list.
       
       @param integer The index of the object to return
       @return Object  The object returned. */
   method public Object Get(input piIndex as integer). 
 
   /** Returns the index in this list of the first occurrence of the specified 
       element, or 0 if this list does not contain this element.
       
       @param Object   The object to check.
       @return integer The index of the passed-in object */       
   method public integer IndexOf(input poElement as Object). 
   
   /* Returns a list iterator over the elements in this list in proper sequence. 
    
       @return IListIterator The ordered iterator */        
   method public IListIterator ListIterator().
   
   /** Returns a list iterator of the elements in this list (in proper sequence),
       starting at the specified position in this list.
       
       @param integer The starting position for the new iterator
       @return IListIterator The ordered iterator */
   method public IListIterator ListIterator(input piIndex as integer).
   
   /** Returns the index in this list of the last occurrence of the 
       specified element, or 0 if this list does not contain this element.
       
       @param Object The object to check
       @return integer The index of the last occurrence of the object */
   method public integer LastIndexOf(input poElement as Object).
  
   /** Removes the element at the specified position in this list
        
        @param integer The index to remove
        @return Object The object that was removed. */
   method public Object Remove (input piIndex as integer). 
   
   /** Replaces the element at the specified position in this list with the 
       specified element
       
       @param integer The position to add
       @param Object The object to add to the List
       @return Object The object that was replaced/removed from the List */
   method public Object    Set (input piIndex as integer, input poElement as Object).
   
   /** Returns a view of the portion of this list between the specified 
       fromIndex, inclusive, and toIndex, exclusive.
       
       @param integer The starting position for the new List (included)
       @param integer The end position for the new List (excluded)
       @return IList  The new List */
   method public IList SubList(input poFromPosition as integer, input poToPosition as integer).
   
end interface.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IListIterator
    Purpose     : An iterator for lists that can traverse the list in 
                  both directions
    Syntax      : 
    Description : 
    @author hdaniels
    Created     :  
    Notes       : 
  ----------------------------------------------------------------------*/
using OpenEdge.Core.Collections.IIterator.
using Progress.Lang.Object.

interface OpenEdge.Core.Collections.IListIterator inherits IIterator:
    
    /** Returns the next elements' index.
         
        Return integer The index of the next element */
    method public integer NextIndex().
    
    /** Indicates whether there's a previous element.  
        
        @return logical True if there is a previous element */
    method public logical HasPrevious().
    
    /** Returns the previous element
    
        @return Object */
    method public Object Previous().
    
    /** Returns the index of the previous item.
        
        Return integer The index of the previous element */
    method public integer PreviousIndex().
end interface.

 
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : IMap
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Sun Apr 11 01:17:48 EDT 2010
    Notes       : All methods (and comments) except ToTable matches 
                  Java Map interface.
                  Collection views are properties 
                  Size is property
                  * Based on the AutoEdge|TheFactory version
  ---------------------------------------------------------------------- */
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.Collections.ISet.
using Progress.Lang.Object.

interface OpenEdge.Core.Collections.IMap:  
 
    /* Returns the number of key-value mappings in this map.*/
    define public property Size as integer no-undo get.
    
    /* Returns a collection view of the values contained in this map.
       reflects changes to the map and vice-versa. 
       Supports removal and removes the corresponding map entry from the map
       (Iterator.remove, Collection.remove, removeAll, retainAll and clear) .
       
       -- Backed by map-- */
    define public property Values as ICollection no-undo get.
    
    /* Returns a set view of the keys contained in this map.
       -- Backed by map-- */
    define public property KeySet as ISet no-undo get.
    
    /* Returns a set view of the mappings contained in this map.
       -- Backed by map-- */
    define public property EntrySet as ISet no-undo get.
     
    /* Removes all mappings from this map (optional operation). */
    method public void Clear().
    
    /* Returns true if this map contains a mapping for the specified key. */
    method public logical ContainsKey(poKey as Object).
    
    /* Returns true if this map maps one or more keys to the specified value.*/
    method public logical ContainsAllKeys(input poKeys as ICollection).
    
    /* Returns true if this map maps one or more keys to the specified value.*/
    method public logical ContainsValue(poValue as Object).
   
    /* Returns true if this map maps one or more keys to the specified value.*/
    method public logical ContainsAllValues(input poValues as ICollection).

    /* Returns the value to which this map maps the specified key.*/
    method public Object Get(poKey as Object).
    
    /* Returns the hash code value for this map.*/
    /*    int    hashCode()*/
    /* Returns true if this map contains no key-value mappings.*/
    method public logical IsEmpty().
     
    /* Associates the specified value with the specified key in this map (optional operation).*/
    method public Object Put(poKey as Object,poValue as Object).
    
    /* Copies all of the mappings from the specified map to this map (optional operation).*/
    method public void PutAll(poMap as IMap).
    
    /* Removes the mapping for this key from this map if it is present (optional operation).*/
    method public Object Remove(poKey as Object).

    /** Removes the mappings for all key from this map if it is present (optional operation).
        
        @param ICollection A collection of keys to remove */
    method public void RemoveAll(input poKeys as ICollection).
    
end interface.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IMapEntry
    Purpose     : A map entry (key-value pair). 
                  The IMap:EntrySet returns a set-view of the map, 
                  whose elements are of this class. 
                   
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Sun Apr 11 23:46:14 EDT 2010
    Notes       : The only way to obtain a reference to a map entry is 
                  from the iterator of the IEntrySet.
                  The IMapEntry objects are valid only for the duration 
                  of the iteration.                      
  ----------------------------------------------------------------------*/
using Progress.Lang.Object.

interface OpenEdge.Core.Collections.IMapEntry:  
    define property Key   as Object no-undo get.
    define property Value as Object no-undo get. set.
end interface.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ISet
    Purpose     : A collection that contains no duplicate elements.
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Wed Jan 09 09:57:42 EST 2008
    Notes       : * Based on the AutoEdge|TheFactory version
  ----------------------------------------------------------------------*/
using OpenEdge.Core.Collections.ICollection.

interface OpenEdge.Core.Collections.ISet inherits ICollection:
    /* no extra members beyond ICollection */      
end interface.
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IStringCollection
    Purpose     : Interface defining a typed String Collection 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Dec 18 13:58:44 EST 2013
    Notes       : * Also contains ICollection methods using ABL primitives instead 
                    of OpenEdge.Core.String  
  ----------------------------------------------------------------------*/

using OpenEdge.Core.Collections.IStringCollection.
using OpenEdge.Core.String.

{OpenEdge/Core/Collections/typedcollectioninterface.i 
    &Package        = OpenEdge.Core.Collections
    &CollectionType = IStringCollection
    &ValueType      = String 
    
    &NoEndInterface = true
}

    /** Appends the specified element to list if not already present
    
        @param longchar The element to add to the collection
        @return logical True if the operation succeeded. */
    method public logical Add(input pcElement as longchar).

    /** Adds an array of elements to the collection 
       
        @param longchar[] An array of elements to add to the collection
        @return logical True if the operation succeeded. */
    method public logical AddArray(input pcElements as longchar extent).
    
    /** Check whether the colleciton contains at least one object
        that matches the passed in object. 
        
        @param Object The object
        @return logical Returns true if the object is in the collection */
    method public logical Contains (input pcElement as longchar).    
    
   /** Removes the first occurrence in this list of the specified element
   
        @param Object The 
        @return logical True if the operation succeded. */
    method public logical Remove (input pcElement as longchar).    

end interface.            
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IStringStringMap
    Purpose     : A typed String/String Map 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Dec 18 13:58:44 EST 2013
    Notes       : * Also contains IMap methods using ABL primitives instead 
                    of OpenEdge.Core.String  
  ----------------------------------------------------------------------*/

using OpenEdge.Core.String.

{OpenEdge/Core/Collections/typedmapinterface.i
    &Package = OpenEdge.Core.Collections
    &MapType = IStringKeyedMap
    &KeyType = String
    &ValueType = Progress.Lang.Object 
    &NoEndInterface = true
}

    /** Adds an entry to the map
        
        @param character The key value
        @param longchar The value
        @return longchar The value added (may be previous value) */
    method public Progress.Lang.Object Put(input pcKey as character, input poValue as Progress.Lang.Object).
    
    /** Retrieves the value for a particular key
    
        @param character The key value
        @return longchar The associated value */
    method public Progress.Lang.Object Get(input pcKey as character).
    
    /** Removes the value for a particular key
    
        @param character The key value
        @return longchar The associated value */
    method public Progress.Lang.Object Remove(input pcKey as character).
    
    /** Indicates whether a map exists for this key

        @param character the key value
        @return logical True if this key exists */
    method public logical ContainsKey(input pcKey as character).

end interface.
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IStringStringMap
    Purpose     : A typed String/String Map 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Dec 18 13:58:44 EST 2013
    Notes       : * Also contains IMap methods using ABL primitives instead 
                    of OpenEdge.Core.String  
  ----------------------------------------------------------------------*/

using OpenEdge.Core.String.

{OpenEdge/Core/Collections/typedmapinterface.i
    &Package = OpenEdge.Core.Collections
    &MapType = IStringStringMap
    &KeyType = String
    &ValueType = String 
    &NoEndInterface = true
}

    /** Adds an entry to the mape
        
        @param character The key value
        @param longchar The value
        @return longchar The value added (may be previous value) */
    method public longchar Put(input pcKey as character, input pcValue as longchar).
    
    /** Retrieves the value for a particular key
    
        @param character The key value
        @return longchar The associated value */
    method public longchar Get(input pcKey as character).
    
    /** Removes the value for a particular key
    
        @param character The key value
        @return longchar The associated value */
    method public longchar Remove(input pcKey as character).
    
    /** Indicates whether a map exists for this key

        @param character the key value
        @return logical True if this key exists */
    method public logical ContainsKey(input pcKey as character).

    /** Indicates whether there is at least one value represented
        by the parameter in the map.
        
        @param longchar The value
        @return logical True if there is at least one entry with this value */    
    method public logical ContainsValue(input pcValue as character).

end interface.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : Iterator
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Sun Dec 16 21:26:22 EST 2007
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.Iterator.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.Iterator use-widget-pool implements IIterator :
    /*------------------------------------------------------------------------------
            Purpose:                                                                        
            Notes:                                                                        
    ------------------------------------------------------------------------------*/
    define protected property OwnerCollection   as ICollection no-undo  get. set .     
    define protected property QueryHandle       as handle no-undo  get. set .     
    define protected property BufferHandle      as handle no-undo  get. set .    
    define protected property ObjectFieldHandle as handle no-undo  get. set  .    
    
    constructor public Iterator (poCol as ICollection, tt as handle,ofield as char):
        this-object(poCol,tt,ofield,'','').            
    end constructor.
    
    constructor public Iterator (poCol as ICollection,tt as handle,ofield as char, sortfield as char):
        this-object(poCol,tt,ofield,sortfield,'').            
    end.
    
    constructor public Iterator (poCol as ICollection,tt as handle,ofield as char, sortfield as char, querystring as char):
        super ().    
        OwnerCollection = poCol.
        
        create buffer BufferHandle for table tt.
        create query QueryHandle.
        
        QueryHandle:add-buffer(BufferHandle).
        ObjectFieldHandle = BufferHandle:buffer-field(ofield).
        PrepareQuery(querystring,sortfield,sortfield = '').
        /* it is generally bad practice to open the query in the constructor 
           - excuse 1: iterators are only newed when you really want to iterate
                      (i.e. you don't new an Iterator at start up or in a constrcutor) 
           - excuse 2: if not done here it would be needed in most methods here and 
                       in ListIterator  */  
        QueryHandle:query-open().
    end constructor.
    
    method private void PrepareQuery (queryExp as char,sortExp as char,forwardOnly as logical):
        QueryHandle:query-prepare('preselect each ' + bufferHandle:name         
                                  + (if queryExp > '' 
                                     then ' where ' + queryExp 
                                     else '') 
                                  + if sortExp > '' 
                                    then ' by ' + sortExp
                                    else ''). 
        QueryHandle:forward-only = forwardOnly.
    end. 
       
    method public logical HasNext(  ):
        define variable offend as logical no-undo.
        
        if QueryHandle:query-off-end then 
        do:
            QueryHandle:reposition-forward(1).
            offend = QueryHandle:query-off-end.
            if not QueryHandle:forward-only then
                QueryHandle:reposition-backward(1).
            return not offend. 
        end. 
        else 
        if  QueryHandle:num-results = 1 
        and QueryHandle:current-result-row = 1 then 
            return not QueryHandle:get-buffer-handle(1):avail.
        else
            return QueryHandle:current-result-row lt QueryHandle:num-results.   
    end method.

    method public Object Next(  ):
        define variable nextobject as Object no-undo.
            
        QueryHandle:get-next().
        if bufferHandle:avail then 
        do:
            nextobject = ObjectFieldHandle:buffer-value().
            return nextobject.
        end.    
        else 
            return ?.
/*          return if bufferHandle:avail then objectFieldHandle:buffer-value() else ?.*/
    end method.
    
    /* removes the current item from the underlying collection  */
    method public logical Remove(  ):    
        define variable lOk as logical no-undo.
        if BufferHandle:avail then
        do:
            lOk = OwnerCollection:Remove(ObjectFieldHandle:buffer-value).
            if lok then 
                QueryHandle:delete-result-list-entry().
        end.   
        return lok.          
    end method.

    destructor public Iterator ( ):
        if valid-handle(BufferHandle) then
            delete object bufferHandle.
        if valid-handle(QueryHandle) then
            delete object QueryHandle.
    end destructor.

 end class.
/** ****************************************************************************
  Copyright 2012 Progress Software Corporation
  
  Licensed under the Apache License, Version 2.0 (the "License");
  you may not use this file except in compliance with the License.
  You may obtain a copy of the License at
  
    http://www.apache.org/licenses/LICENSE-2.0
  
  Unless required by applicable law or agreed to in writing, software
  distributed under the License is distributed on an "AS IS" BASIS,
  WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
  See the License for the specific language governing permissions and
  limitations under the License.
**************************************************************************** **/
 /*------------------------------------------------------------------------
    File        : KeySet
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : apr 2010
    Notes       : no empty constructor, specialized for KeySet of IMap 
                 - Changes to the map are reflected here, and vice-versa. 
                 - Supports removal and removes the corresponding map entry from the map
                   (Iterator.remove, Collection.remove, removeAll, retainAll and clear) .
                 - Do not support add and addAll.   
                 - no empty constructor, specialised for IMap 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IMap. 
using OpenEdge.Core.Collections.IIterator. 
using OpenEdge.Core.Collections.ISet. 
using OpenEdge.Core.Collections.KeySet. 
using OpenEdge.Core.Collections.MapBackedCollection. 
using Progress.Lang.Object.
 
class OpenEdge.Core.Collections.KeySet serializable inherits MapBackedCollection
        implements ISet: 
  
    constructor public KeySet (poMap as IMap,phTT as handle,pcKeyField as char):
        super (poMap,phTT,pcKeyField).        
    end constructor.
    
    method public override logical Contains(poObj as Object):        
         return OwningMap:ContainsKey(poObj).
    end method.
   
    method override public logical ContainsAll(collection as ICollection):
        return OwningMap:ContainsAllKeys(collection).
    end method.
    
    /* Equals if Set and every member of the specified set is contained in this set */
    method public override logical Equals(o as Object):
        define variable oSet as ISet no-undo.
        define variable oIter as IIterator no-undo.
        if super:Equals(o) then 
            return true.
        if type-of(o,ISet) then
        do:
            oSet = cast(o,ISet).
            if oSet:Size = Size then
            do:
                oIter = Iterator().
                do while oIter:HasNext():
                    if oSet:Contains(oIter:Next()) = false then
                        return false. 
                end.    
                return true.
            end.    
        end.
        return false.    
    end method.   
     
    method public override logical Remove(poOld as Object ):
        define variable i as integer no-undo.
         /* OwningMap:Remove() returns oldvalue, but it could be unknown, so use size to check if deleted */
         i = Size.
         OwningMap:Remove(poOld).
         if i > Size then 
             return true.
         return false.    
    end method.
    
    method public override logical RemoveAll(collection as ICollection):
        define variable iterator   as IIterator no-undo.         
        define variable anyRemoved as logical no-undo.
        iterator = collection:Iterator().
        do while iterator:HasNext():
            if Remove(iterator:Next()) then 
                anyRemoved = true. 
        end.
        return anyRemoved.
    end method.
    
    method public override logical RetainAll(collection as ICollection):
        define variable iterator   as IIterator no-undo.    
        define variable oObj      as Object no-undo.     
        define variable anyRemoved as logical no-undo.
        iterator = collection:Iterator().
        do while iterator:HasNext():
            oObj = iterator:Next().
            if not Contains(oObj) then
            do:
                Remove(oObj). 
                anyRemoved = true. 
            end.
        end.
        return anyRemoved.
    end method.
     
end class.
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : LinkedList
    Purpose     : A single linked list containing Object nodes.
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Feb 13 13:23:49 EST 2014
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ListNode.

{OpenEdge/Core/Collections/typedlinkedlist.i
    &Package    = OpenEdge.Core.Collections
    &ListType   = LinkedList
    &NodeType   = ListNode
    &IsSerializable = true
}
/************************************************
Copyright (c) 2013, 2016-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : List
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Wed Jan 09 10:45:45 EST 2008
    Notes       : 
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.AssertionFailedError.
using OpenEdge.Core.Collections.AbstractTTCollection.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.IList.
using OpenEdge.Core.Collections.IListIterator.
using OpenEdge.Core.Collections.Iterator.
using OpenEdge.Core.Collections.List.
using OpenEdge.Core.Collections.ListIterator.
using Progress.Lang.AppError.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.List serializable inherits AbstractTTCollection
        implements IList:
    /* default temp-table  */ 
    define protected temp-table ttList no-undo
      field sequence as int
      field objectref as Object 
      index objidx objectref
      index seq as unique primary sequence
      .
    /* Default constructor */
    constructor public List():
        super (temp-table ttList:handle,'objectref').        
    end constructor.
       
    constructor public List (list as IList):
        super (cast (list,ICollection),temp-table ttList:handle,'objectref').        
    end constructor.
    
    constructor protected List ( input poCol as ICollection, input phtt as handle, input pcField as character ):
        super (input poCol, input phtt, input pcField).
    end constructor.
        
    constructor protected List ( input phtt as handle, input pcField as character ):
        super (input phtt, input pcField).
    end constructor.
    
    constructor protected List ( input phtt as handle, input hField as handle ):
        super (input phtt, input hField).
    end constructor.
    
    /* Find the FIRST reference of the search object; the search order 
       is by the List's Sequence. This means that if there are 2 instances
       of this object, a dev will need to iterate over the collection to 
       determine which ones match. 
       
       @param Progress.Lang.Object The search object */
    method protected override void FindBufferUseObject(findObject as Object):
        define variable listItem as rowid no-undo.
        
        assign listItem = ?. 
        for each ttList where 
                 ttList.objectref eq findObject 
                 by ttList.sequence
                 while listItem eq ?:
            // we won't get in here unless there's the identical reference 
            assign listItem = rowid(ttList).
        end.
        
        for each ttList 
                 by ttList.sequence
                 while listItem eq ?:
            if ttList.objectref:Equals(findObject) then
                assign listItem = rowid(ttList).
        end.
        
        if not listItem eq ? then
            find ttList where rowid(ttList) eq listItem.
    end method.
    
    method public logical Add(seq as integer, obj as Object ):    
        define buffer btList for ttList.
        
        Assert:IsPositive(seq, 'List index').
        
        if super:Add(obj) then
        do:
            for each btList where btList.sequence >= seq by btList.sequence desc:
                btList.sequence = btList.sequence + 1. 
            end.
            
            // Don't use, in case we have the same item more than once: FindBufferUseObject(obj)
            // The just-added item, with the default Sequence
            find ttList where ttList.sequence eq 0.
            assign ttList.Sequence = seq.
            return true.
        end.
        return false.
    end method.
    
    method public override logical Add(obj as Object ):    
        if super:Add(obj) then
        do:
            // Don't use, in case we have the same item more than once: FindBufferUseObject(obj)
            // The just-added item, with the default Sequence
            find ttList where ttList.sequence eq 0.
            assign ttList.Sequence = this-object:Size.
            return true.
        end.
        
        return false.
    end method.
    
    /** Adds all of the input collection to the current list.
        Items from the input collection as added to the END of 
        the current list.
        To prepend items, call AddAll(1, ICollection)
        
        @param ICollection The collection to add.
        @return logical TRUE if items were added (ie the input collection has at least one item) */
    method override public logical AddAll(c as ICollection):
        return this-object:AddAll(this-object:Size + 1, c).
    end method.
    
    /** Adds all of the input collection to the current list, starting at the
        index given (ie the index passed is the first item) 
        
        @param integer The index from which to add. Must be non-zero and positive 
        @param ICollection The collection to add
        @return logical TRUE if items were added (ie the input collection has at least one item) */
    method public logical AddAll(seq as int,c as ICollection):
        define buffer btList for ttList.
        define variable iterator as IIterator no-undo.
        
        Assert:NotNull(c, 'Collection').
        Assert:IsPositive(seq, 'List index').
        
        if c:Size eq 0 then
            return false.
        
        // Don't allow us to add stuff at a point beyond the size of this collection
        assign seq = min(seq, this-object:Size + 1).
        
        for each btList where btList.sequence >= seq by btList.sequence desc:
            assign btList.sequence = btList.sequence + c:Size.
        end.
        assign iterator = c:Iterator(). 
        do while iterator:HasNext():
            super:Add(iterator:Next()).
            
            // Don't use, in case we have the same item more than once: FindBufferUseObject(oItem)
            // The just-added item, with the default Sequence
            find ttList where ttList.sequence eq 0.
            assign ttList.sequence = seq
                   seq             = seq + 1
                   .
        end.
        return true.
    end method.
    
    method public logical AddArray(seq as int, obj as Object extent):
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define buffer btList for ttList.
        
        Assert:IsPositive(seq, 'List index').
        
        iMax = extent(obj).
        
        for each btList where btList.sequence >= seq by btList.sequence desc:
            btList.sequence = btList.sequence + iMax + 1. 
        end.
        
        do iLoop = 1 to iMax:
            super:Add(obj[iLoop]).
            
            // Don't use, in case we have the same item more than once: FindBufferUseObject(obj[iLoop])
            // The just-added item, with the default Sequence
            find ttList where ttList.sequence eq 0.
            ttList.Sequence = Seq.
            seq = seq + 1.
        end.
        
        return true.         
    end method.
     
    /* two lists are defined to be equal if they contain the same elements in the same order */
    method public override logical Equals(o as Object):
        define buffer btList for ttList.
        define variable oList as List no-undo.
        
        if super:Equals(o) then 
            return true.
        
        if type-of(o,List) then
        do:
            assign oList = cast(o,List).
            if not oList:Size eq Size then
                return false.
            for each btList:
                // This method uses the ttList buffer
                FindBufferUseObject(oList:Get(btList.Sequence)).
                if not available ttList then
                    return false.
            end.
            return true.
        end.
        return false.    
    end method.    
    
    method public Object Get(i as integer):
        Assert:IsPositive(i, 'List index').
        if i gt this-object:Size then
            undo, throw new AssertionFailedError(substitute('Index &1 is larger than List size &2', i, this-object:Size)).
        
        if can-find(ttList where ttList.sequence eq i) then
            find ttList where ttList.sequence = i no-error.
        if avail ttList then 
            return ttList.objectref.
        else
            return ?.
    end method.
    
    method public integer IndexOf(obj as Object ):
        define variable iIndex as integer no-undo.
        
        assign iIndex = 0.
        // this loop picks up invalid object references too
        for each ttList where
                 ttList.objectref = obj 
                 by ttList.sequence
                 while iIndex eq 0:
            assign iIndex = ttList.sequence. 
        end.
        
        for each ttList 
                 by ttList.Sequence
                 while iIndex eq 0: 
            if ttList.objectref:Equals(obj) then
                assign iIndex = ttList.sequence. 
        end.
        
        return iIndex.    
    end method.
     
    /* Returns a new IIterator over the collection.  */
    method public override IIterator Iterator(  ):        
        return new Iterator(this-object,temp-table ttList:handle,"objectref","sequence").
    end method.
    
    /* Returns a new IListIterator over the collection.  */
    method public IListIterator ListIterator(  ):        
        return new ListIterator(this-object,temp-table ttList:handle,"objectref","sequence").
    end method.
    
    /* Returns a new IListIterator over the collection.*/
    method public IListIterator ListIterator(i as integer):
        Assert:IsPositive(i, 'List index').
        
        return new ListIterator(this-object,temp-table ttList:handle,"objectref","sequence","sequence >= " + string(i)).
    end method.
    
    method public integer LastIndexOf(obj as Object ):
        define variable iIndex as integer no-undo.
        
        assign iIndex = 0.
        // this loop picks up invalid object references too
        for each ttList where ttList.objectref = obj 
                 by ttList.sequence descending
                 while iIndex eq 0:
            assign iIndex = ttList.sequence. 
        end.
        
        for each ttList 
                 by ttList.Sequence descending
                 while iIndex eq 0: 
            if ttList.objectref:Equals(obj) then
                assign iIndex = ttList.sequence. 
        end.
        
        return iIndex.    
    end method.
    
    method override public logical Remove(oldObject as Object ):
        define variable iStart as integer no-undo.
        define buffer btList for ttList.
        findBufferUseObject(oldObject). 
        if avail ttList then
        do:
            iStart = ttList.sequence.
            if super:remove(oldobject) then
            do:
                for each btList where btList.Sequence > iStart:
                    btList.sequence = btList.Sequence - 1.     
                end.
                return true.
            end. 
        end.    
        return false.
    end method.
    
    /** Removes an item at the given index
    
        @param integer The index to remove. Must be between 1 and the size of the List
        @return Progress.Lang.Object The item that was removed. */
    method public Object Remove(i as integer):
        define variable oldObject as Object.
        define buffer btList for ttList.
        
        Assert:IsPositive(i, 'List index').
        if i gt this-object:Size then
            undo, throw new AppError(substitute('Index &1 is larger than the collection size of &2', i, this-object:Size), 0).
        
        // Get() finds the ttList record
        assign oldObject = this-object:Get(i).
        delete ttList.
        
        //Only the parent can set the Size
        Resize().
        
        for each btList where 
                 btList.sequence gt i 
                 by btList.sequence:
            assign btList.sequence = btList.sequence - 1. 
        end.
        
        return oldObject.
    end method.
    
    method public Object Set(input i as integer, input poReplacement as Object ):
        define variable oldObject as Object.
        
        Assert:IsPositive(i, 'List index').
        if i gt this-object:Size then
            undo, throw new AppError(substitute('Index &1 is larger than the collection size of &2', i, this-object:Size), 0).
         
        if can-find(ttList where ttList.sequence eq i) then
        do: 
            find ttList where ttList.sequence = i no-error.
            assign 
                oldObject        = ttList.objectref  
                ttList.objectref = poReplacement.
        end.
        return oldObject.
    end method.
    
    method public IList SubList(fromIndex as integer, toIndex as integer):
        define variable list as IList no-undo.
        define variable oObject as Object no-undo.
        
        Assert:IsPositive(fromIndex, 'List start index').
        Assert:IsPositive(toIndex, 'List end index').
        
        if fromIndex gt this-object:Size then
            undo, throw new AppError(substitute('From-Index &1 is larger than the collection size of &2', fromIndex, this-object:Size), 0).
        
        if (fromIndex + toIndex) gt this-object:Size then
            undo, throw new AppError(substitute('To-Index range &1 is larger than the collection size of &2', fromIndex + toIndex, this-object:Size), 0).
        
        if fromIndex ge toIndex then
            undo, throw new AppError(substitute('From-Index &1 is larger To-Index &2', fromIndex, toIndex), 0).
        
        list = new List().
        do fromIndex = fromIndex to toIndex - 1:
           oObject = get(fromIndex).
           if valid-object(oObject) then
              list:add(oObject).  
           else do: 
              delete object list. 
              return ?. 
           end.     
        end.
        return list.
    end method.
     
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ListIterator
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Wed Jan 02 23:38:28 EST 2008
    Notes       : 
  ----------------------------------------------------------------------*/

block-level on error undo, throw.
using Progress.Lang.Object.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IListIterator.
using OpenEdge.Core.Collections.Iterator.

class OpenEdge.Core.Collections.ListIterator inherits Iterator implements IListIterator:

    constructor public ListIterator (poCol as ICollection,tt as handle, objField as char, seqField as char):
        super (poCol,tt,objfield, seqField).               
    end constructor. 
    
    constructor public ListIterator (poCol as ICollection,tt as handle, objField as char, seqField as char,querystring as char):
        super (poCol,tt,objfield, seqField, querystring).               
    end constructor. 
      
    method public logical HasPrevious(  ):
        define variable offend as logical no-undo.
        if QueryHandle:query-off-end then 
        do:
            QueryHandle:reposition-backward(1).
            offend = QueryHandle:query-off-end.
            QueryHandle:reposition-forward(1).
            return not offend. 
        end. 
        else 
            return QueryHandle:current-result-row > 1.       
    end method.        
    
    method public Object Previous(  ):
        QueryHandle:get-prev().
          return if BufferHandle:avail then ObjectFieldHandle:buffer-value() else ?. 
    end method.
    
    method public integer PreviousIndex(  ):
        if QueryHandle:query-off-end = false then 
            return QueryHandle:current-result-row - 1.
    end method.
    
    method public integer NextIndex(  ):
        if QueryHandle:query-off-end = false then 
            return max(QueryHandle:current-result-row + 1,
                        QueryHandle:num-results).
        else if HasNext() then
            return 1.
    end method.
    
end class.
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : ListNode
    Purpose     : Singly-linked list node/element containing general Object data
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Feb 13 13:26:08 EST 2014
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ListNode.
using Progress.Lang.Object.

{OpenEdge/Core/Collections/typedlistnode.i
    &Package    = OpenEdge.Core.Collections
    &NodeType   = ListNode
    &ValueType  = Object
    &IsSerializable = true
}
/************************************************
Copyright (c) 2013, 2015, 2017-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : Map
    Purpose     : Unique Key-Value mapping collection 
    Syntax      :  
    Description : 
    @author hdaniels
    Created     : Sun Apr 11 01:35:13 EDT 2010
    Notes       : 
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.Collections.EntrySet.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.Collections.ISet.
using OpenEdge.Core.Collections.KeySet.
using OpenEdge.Core.Collections.Map.
using OpenEdge.Core.Collections.ValueCollection.
using Progress.Lang.AppError.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.Map serializable
        implements IMap:
    
    define protected temp-table ttMap no-undo 
      field KeyRef      as Object 
      field ValueRef    as Object
      index validx ValueRef
      index keyidx as unique primary KeyRef.
    
    /* The size of the Map, being the number of keys */
    define public property Size as integer no-undo 
        get.
        private set. 
    
    /* A collection of only the values in the Map */
    define public property Values as ICollection no-undo 
    get():
        /* Return a new ValueCollection on each request. This is somewhat
           inefficient, but doing so prevents a circular reference from being created.
           
           This property is typically used in a transient fashion (ie for iteration
           over the contents of the Map) and is expected to be scoped to a small block
           like a single method. */
        return new ValueCollection(this-object,temp-table ttMap:handle,"ValueRef").
    end.   
   
    /* An  ordered set of only the keys in the Map */
    define public property KeySet as ISet no-undo 
    get():
        /* Return a new KeySet on each request. This is somewhat
           inefficient, but doing so prevents a circular reference from being created.
           
           This property is typically used in a transient fashion (ie for iteration
           over the contents of the Map) and is expected to be scoped to a small block
           like a single method. */
        return new KeySet(this-object,temp-table ttMap:handle,"KeyRef").
    end.   
         
    /* An ordered set of key-value objects in the Map */
    define public property EntrySet as ISet no-undo 
    get():
        /* Return a new EntrySet on each request. This is somewhat
           inefficient, but doing so prevents a circular reference from being created.
           
           This property is typically used in a transient fashion (ie for iteration
           over the contents of the Map) and is expected to be scoped to a small block
           like a single method. */
        return new EntrySet(this-object,temp-table ttMap:handle,"KeyRef").
    end.   
            
    /* Empties the map's contents */
    method public void Clear():
        empty temp-table ttMap.
    end method.

    /* Returns true if the given object is also a map and the two Maps represent the same mappings.  */
    method public override logical Equals(o as Object):
        define buffer btMap for ttMap.
        define variable oMap as IMap no-undo.
        define variable oValue as Object no-undo.
        
        if super:Equals(o) then 
            return true.
        if type-of(o,IMap) then
        do:
            oMap = cast(o,IMap).
            if oMap:Size = Size then
            do:
                for each btMap:
                    oValue = oMap:Get(btMap.KeyRef).
                    if oValue <> ? and oValue <> btMap.ValueRef then
                        return false.
                    
                    if oValue = ? then
                    do:
                       if not oMap:ContainsKey(btMap.KeyRef) then
                           return false. 
                       if btMap.ValueRef <> ? then
                           return false.
                    end.       
                end.
                return true.
            end.    
        end.
        return false.    
    end method.    
    
    /* Indicates whether the map has any entries.
       
       @return logical TRUE if the map is empty (no entries) and false otherwise */
    method public logical IsEmpty(  ):
        return not can-find(first ttMap).
    end method.

    /* Indicates whether the map contains a particular key
       
       @param Object A key value to search
       @return Logical TRUE if the map contains the key value */
    method public logical ContainsKey(input poKey as Object):
        define variable lContainsKey as logical no-undo.
        define buffer lbMap for ttMap.
        
        if not valid-object(poKey) then
            return false.
        
        /* try by-reference first */
        lContainsKey = can-find(lbMap where lbMap.KeyRef = poKey). 
        for each lbMap while lContainsKey = false:
            lContainsKey = lbMap.KeyRef:Equals(poKey).
        end.
               
        return lContainsKey.
    end method.
    
    /* Returns true if this map contains all of the keys passed in. 
       
       @param ICollection The collection of keys
       @return logical TRUE if all of the keys in the input collection are in the map */
    method public logical ContainsAllKeys(input poKeys as ICollection):
        define variable oIterator as IIterator.
        
        Assert:NotNull(poKeys, 'Check keys').
        
        /* if the 'check' collection is empty, then true */  
        if poKeys:IsEmpty() then
            return true.
        
        /* if the passed in collection is larger than this collection,
           this cannot be true. */
        if poKeys:Size gt this-object:Size then
            return false.
        
        /* one or both collections has data */
        oIterator = poKeys:Iterator().
        do while oIterator:HasNext():
            if not this-object:ContainsKey(oIterator:Next()) then
                return false.
        end.
        
        return true.
    end method.
    
    /* Returns true if this map contains all of the values passed in. 
       
       @param ICollection The collection of values 
       @return logical TRUE if all of the values in the input collection are in the map */
    method public logical ContainsAllValues(input poValues as ICollection):
        define variable oIterator as IIterator.
        
        Assert:NotNull(poValues, 'Check values').
        
        /* if the 'check' collection is empty, then true */  
        if poValues:IsEmpty() then
            return true.
        
        /* if the passed in collection is larger than this collection,
           this cannot be true. */
        if poValues:Size gt this-object:Size then
            return false.
        
        /* one or both collections has data */
        oIterator = poValues:Iterator().
        do while oIterator:HasNext():
            if not this-object:ContainsValue(oIterator:Next()) then
                return false.
        end.
        
        return true.
    end method.
    
    /* Returns true if this map contains the value passed in. 
       
       @param ICollection The value to check
       @return logical TRUE if the value is in the map */
    method public logical ContainsValue(poValue as class Object):
        define variable lContainsValue as logical no-undo.
        define buffer lbMap for ttMap.
        
        if not valid-object(poValue) then
            return false.
        
        /* try by-reference first */
        lContainsValue = can-find(lbMap where lbMap.ValueRef = poValue). 
        for each lbMap while lContainsValue = false:
            lContainsValue = lbMap.ValueRef:Equals(poValue).
        end.
                       
        return lContainsValue.
    end method.
    
    /* Returns a value for a given key in the Map 
       
       @param  Object The key fopr which to return a value. NULL/unknown if the key is not in the map
       @return Object The value represented by the key */ 
    method public Object Get(poKey as Object):
        define variable oValue as Object no-undo.
        define buffer lbMap for ttMap.
       
        if not valid-object(poKey) then
            return oValue.
        
        if can-find(lbMap where lbMap.KeyRef eq poKey) then
            find lbMap where lbMap.KeyRef = poKey.
        if avail lbMap then
            assign oValue = lbMap.ValueRef.
        
        for each lbMap while not valid-object(oValue):
            if lbMap.KeyRef:Equals(poKey) then
                assign oValue = lbMap.ValueRef.
        end.
        
        return oValue.
    end method.
    
    /* Add entry to the map, return old value of any. Note that return of unknown could 
       also mean that the old mapped value was unknown... (check Size before and after)
       
       @param Object The key for this mapping
       @param Object The value for the mapping 
       @return Object If a value is replaced, the previous value is returned, otherwise null */   
    method public Object Put(poKey as Object, poValue as class Object):
        define variable oOld as Object no-undo.
        define buffer lbMap for ttMap.
        define buffer putMap for ttMap.
        
        if poKey:Equals(this-object) then 
             undo, throw new AppError("A Map cannot have itself as key.").
        /* not a real transaction, but scoping of updates 
          (not tested without, so not sure if it is really needed... )  */
        do transaction:
            /* try by-reference first */
            if can-find(lbMap where lbMap.KeyRef eq poKey) then
                find putMap where putMap.KeyRef eq poKey.
            if not available putMap then        
            for each lbMap while not available putMap:
                if lbMap.KeyRef:Equals(poKey) then 
                    find putMap where rowid(putMap) eq rowid(lbMap).
            end.
            // Add an entry
            if not avail putMap then
            do:
                create putMap.
                assign putMap.KeyRef = poKey
                       Size = Size + 1.
            end.
            else
                // Update an entry
                assign oOld = putMap.ValueRef.
            
            assign putMap.ValueRef = poValue.
        end.
        
        return oOld.
    end method.
    
    /* Adds all entries from another map to this one.
       
       @param IMap The input map */
    method public void PutAll(poMap as IMap):
        define variable oKey as Object no-undo.
        define variable oIter as IIterator no-undo.    
 
        oIter = poMap:KeySet:Iterator(). 
        do while oIter:hasNext():
            oKey = oIter:Next().
            this-object:Put(oKey,poMap:Get(oKey)).
        end.
    end method.
    
    /* Removes an entry
     
       @param Object The key for the entry to remove
       @param Object the value associated with that key. May be null.  Note that return of unknown could 
       also mean that the old mapped value was unknown. */ 
    method public Object Remove(input poKey as Object):
        define variable oOld as Object no-undo.
        define buffer lbMap for ttMap.
        define buffer removeMap for ttMap.
        
        if not valid-object(poKey) then
            return ?.
        
        /* try by-reference first */
        if can-find(removeMap  where removeMap.KeyRef eq poKey) then
            find removeMap where removeMap.KeyRef eq poKey.
        
        if not available removeMap then
        for each lbMap while not available removeMap:
            if lbMap.KeyRef:Equals(poKey) then
                find removeMap where rowid(removeMap) eq rowid(lbMap).
        end.
        
        if avail removeMap then
        do:
            assign oOld = removeMap.ValueRef
                   Size = Size - 1.
            delete removeMap.
        end.
        
        return oOld.
    end method.

    /** Removes the mappings for all key from this map if it is present (optional operation).
        
        @param ICollection A collection of keys to remove */
    method public void RemoveAll(input poKeys as ICollection).
        define variable oIterator as IIterator no-undo.
        define variable oRemove  as Object.
        define buffer removeMap for ttMap. 
        
        oIterator = poKeys:iterator().
        do while oIterator:HasNext():
            oRemove = oIterator:Next().
            for each removeMap where removeMap.KeyRef eq oRemove:
                delete removeMap.
                Size = Size - 1.
            end.
            
            for each removeMap:
                if removeMap.KeyRef:Equals(oRemove) then
                do:
                    delete removeMap.
                    Size = Size - 1.
                end.
            end.
        end.
    end method.
    
    /* Constructor. Creates a new map an populates with with a set of values.
    
       @param IMap Contains values to add to this map */
    constructor public Map (input poMap as IMap):
        super ().    
        if type-of(poMap, Map) then
        do:
            poMap:Values:ToTable(output table ttMap).
            Size = poMap:Size.
        end. 
        else
            PutAll(poMap).  
    end constructor.
    
    /* Default constructor */
    constructor public Map (  ):
        super ().   
    end constructor.

    destructor public Map ( ):
        this-object:Clear().
    end destructor.

end class.
/************************************************
Copyright (c) 2013, 2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : BackedTTAbstractCollection
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Mon Dec 16 16:24:45 EST 2013
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.Collections.Iterator.
using OpenEdge.Core.System.UnsupportedOperationError.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.MapBackedCollection abstract serializable 
        implements ICollection:
    
    define protected property OwningMap  as IMap no-undo get. private set.
    define protected property OwningBuffer as handle no-undo get. private set.
    define protected property KeyField as handle no-undo get. private set.
    
    define public property Size as integer no-undo 
    get():
        return OwningMap:Size.
    end. 
    
    constructor public MapBackedCollection(poMap as IMap,phTT as handle, pcValuefield as char):
        super ().
        assign
            this-object:OwningBuffer = phTT
            this-object:KeyField = this-object:OwningBuffer:default-buffer-handle:buffer-field (pcValuefield)
            OwningMap = poMap.
    end constructor.
    
    method public logical Add(newObject as Object):
       return error new UnsupportedOperationError('Add', this-object:GetClass():TypeName).
    end method.

    method public logical AddAll( newCollection as ICollection ):
        return error new UnsupportedOperationError('AddAll', this-object:GetClass():TypeName).
    end method.
    
    method public logical AddArray(o as Object extent ):
        return error new UnsupportedOperationError('AddArray', this-object:GetClass():TypeName).    
    end method.

    method public void Clear():
        OwningMap:Clear().
    end method.
   
    method public logical IsEmpty():
        return OwningMap:IsEmpty().
    end method.
    
    /* abstract because this could be a key or value */
    method abstract public logical Contains( checkObject as Object).
    
    /* abstract because this could be a collection of keys or values */
    method abstract public logical ContainsAll(input poCollection as ICollection).
    
    /* abstract because this could be a collection of keys or values */
    method abstract public logical Remove( poOld as Object).
    
    /* abstract because this could be a collection of keys or values */
    method abstract public logical RemoveAll(poRemoveCol as ICollection).
    
    /* abstract because this could be a collection of keys or values */
    method abstract public logical RetainAll(input poRetainCollection as ICollection).
    
    /* Returns a new IIterator over the collection. */
    method public IIterator Iterator( ):    
        return new Iterator(this-object,this-object:OwningBuffer,this-object:KeyField:name).
    end method.
    
    /* ToArray should not be used with large collections
       If there is too much data the ABL will throw:  
       Attempt to update data exceeding 32000. (12371) */
    method public Object extent ToArray():
        define variable i as integer no-undo.
        define variable oObjArray as Object extent no-undo.
        define variable iterator as IIterator no-undo.
        
        if Size eq 0 then
            return oObjArray.
            
        extent(oObjarray) = Size.
        iterator = Iterator(). 
        do while iterator:hasNext():
           i = i + 1.
           oObjArray[i] = iterator:Next().  
        end.                                     
        return oObjArray.
    end method.
    
    method public void ToTable( output table-handle tt):
        tt = this-object:OwningBuffer.
    end method.
     
end class. /************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : MapEntry
    Purpose     : 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Mon Apr 12 00:24:25 EDT 2010
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.Collections.IMapEntry.
using OpenEdge.Core.Assert.
using Progress.Lang.Object.
 
class OpenEdge.Core.Collections.MapEntry serializable 
        implements IMapEntry: 
    
    define protected property OwningMap as IMap no-undo get. set.
    
    define public property Key as  Object no-undo 
    get.
    private set. 
    
    define public property Value as  Object no-undo
    get():
        return OwningMap:Get(this-object:Key).
    end get.            
    set(input poValue as Object):
        OwningMap:Put(this-object:Key, poValue).
    end.
    
    constructor public MapEntry (poMap as IMap, poKey as Object):
        super ().
        
        Assert:NotNull(poMap, 'Map').
        Assert:NotNull(poKey, 'Key').
        
        assign this-object:Key = poKey
               this-object:OwningMap = poMap.
    end constructor.
    
    method public override logical Equals(o as Object):
         define variable oMapEntry as IMapEntry no-undo.
         if o:Equals(this-object) then
             return true.
         if type-of(o,IMapEntry) then
         do: 
             oMapEntry = cast(o,IMapEntry).
             return this-object:Key:Equals(oMapEntry:Key) 
                    and 
                    this-object:Value:Equals(oMapEntry:Value).
         end.
         return false.
    end method.
    

end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ObjectStack
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Jan 05 13:50:43 EST 2010
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ObjectStack.
using OpenEdge.Core.Collections.Stack.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.ObjectStack serializable inherits Stack:
        
    constructor public ObjectStack (poArray as Object extent):
        super(poArray).
    end constructor.
    
    constructor public ObjectStack (piDepth as integer):
        super(piDepth).
    end constructor.

    constructor public ObjectStack():
    end constructor.
    
    method public void Push(poValue as Object):
        super:ObjectPush(poValue).
    end method.
    
    method public Object Peek():
        return super:ObjectPeek().
    end method.
    
    method public Object Pop():
        return super:ObjectPop().
    end method.
    
    method public Object extent ToArray():
        return super:ObjectToArray().
    end method.
    
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : ResizeError
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Jun 14 11:49:06 EDT 2012
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.System.ApplicationError.
using OpenEdge.Core.Collections.ResizeError.
using Progress.Lang.Error.

class OpenEdge.Core.Collections.ResizeError serializable inherits ApplicationError:
    constructor static ResizeError ():
        ApplicationError:AddError(
            get-class(ResizeError),
            /* short message */
            'Collection Resize Error',
            /* message */
            'Cannot resize &1 &2 than its contents').       
    end constructor.
    
    constructor public ResizeError ():
    end constructor.
    
    constructor public ResizeError (input poErr as Error, input pcArgs1 as character, input pcArgs2 as character):
        super(poErr).
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.
    
    constructor public ResizeError (input pcArgs1 as character, input pcArgs2 as character):
        define variable oUnknown as Error no-undo.
        this-object(oUnknown,pcArgs1,pcArgs2).
    end constructor.

end class./************************************************
Copyright (c) 2013,2014,2017-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : Set
    Purpose     : A collection that contains no duplicate elements.
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : Wed Jan 09 10:45:45 EST 2008
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.Collections.AbstractTTCollection.
using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.ISet.
using Progress.Lang.Object.
 
class OpenEdge.Core.Collections.Set inherits AbstractTTCollection implements ISet : 
    /* temp-table  */ 
    define private temp-table ttSet no-undo
      field objectref as Object 
      index objidx as unique primary objectref.
        
    /* Default constructor */
    constructor public Set (  ):
        super (temp-table ttSet:handle,"objectref").        
    end constructor.
    
    /* Constructor 
    
       @param ISet Initial set */
    constructor public Set (copyset as ISet):
        super (cast(copyset,ICollection),temp-table ttSet:handle,"objectref").        
    end constructor.    
    
     method public override logical Contains( checkObject as Object):
        if not valid-object(checkObject) then
            return false.
        
        FindBufferUseObject(checkObject).
        return (available ttSet).
    end method.
       
    method protected override void FindBufferUseObject (obj as Object):
        define variable itemRowid as rowid no-undo.
        
        assign itemRowid = ?. 
        
        if can-find(ttSet where ttSet.objectref eq obj) then
            find ttSet where ttSet.objectref eq obj.
        if available ttSet then 
            return.
        
        for each ttSet 
                 while itemRowid eq ?:
            if ttSet.objectref:Equals(obj) then
                assign itemRowid = rowid(ttSet).
        end.
        
        if not itemRowid eq ? then
            find ttSet where rowid(ttSet) eq itemRowid.
    end.
   
    method public override logical Add(obj as Object):
        Assert:NotNull(obj, 'Object to add').
        
        FindBufferUseObject(obj).
        if not avail ttSet then
            return super:Add(obj).
        else
            return false.
    end method.
    
    method public override logical AddAll(collection as ICollection):
        define variable iterator as IIterator no-undo.
        define variable anyAdded as logical   no-undo.
        
        assign iterator = collection:Iterator()
               anyAdded = false
               .
        do while iterator:HasNext():
            if this-object:Add(Iterator:Next()) then
               anyAdded = true.
        end.
        
        return anyAdded.
    end method.
    
    /* Equals if Set and every member of the specified set is contained in this set */
    method public override logical Equals(o as Object):
        define buffer btSet for ttSet.
        define variable oSet as ISet no-undo.
        
        if super:Equals(o) then 
            return true.
        if type-of(o,ISet) then
        do:
            oSet = cast(o,ISet).
            if oSet:Size = Size then
            do:
                for each btSet:
                    if not oSet:Contains(btSet.objectref) then
                        return false. 
                end.    
                return true.
            end.    
        end.
        return false.    
    end method.    
    
    method public override logical RemoveAll(collection as ICollection):
        define variable iterator   as IIterator no-undo.         
        define variable anyRemoved as logical no-undo.
        iterator = collection:Iterator().
        do while iterator:HasNext():
            if remove(iterator:Next()) then 
                anyRemoved = true. 
        end.
        return anyRemoved.
    end method.
     
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : Stack
    Purpose     : A stack is a last-in-first-out collection. 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Jan 05 15:09:51 EST 2010
    Notes       : * Non-char primitive values will have their own IntegerStack() say,that calls PrimitivePush and
                    converts to/from character to their native datatype. 
                  * The Stack temp-table could probably be dynamic, and have a single value field that
                    is dynamically constructed, but stacks need to be lightweight at runtime (IMO anyway). 
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.Collections.Stack.
using OpenEdge.Core.Collections.StackOverflowError.
using OpenEdge.Core.Collections.StackUnderflowError.
using OpenEdge.Core.Collections.ResizeError.
using OpenEdge.Core.DataTypeEnum.
using OpenEdge.Core.IOModeEnum.
using OpenEdge.Core.Assert.
using Progress.Lang.ParameterList.
using Progress.Lang.Object.
using OpenEdge.Core.DataTypeHelper.

class OpenEdge.Core.Collections.Stack abstract serializable:
    define public static variable DefaultStackDepth as integer no-undo.
    
    /** NOTE/ the expand/shrink behaviour could be handled with an enumeration,
        but as of 10.2B performance is better when using logical variables.
     **/
    /* Keep incrementally growing stack Depth as new elements are added.
       This will negatively impact performance. */
    define public property AutoExpand as logical no-undo get. set.
    
    /* If true, we'll discard stuff off the bottom of the stack if
       we resize the stack smaller than its contents. */
    define public property DiscardOnShrink as logical no-undo get. set.
    
    define public property Depth as integer no-undo 
        get.
        set (piDepth as int):
            SetStackDepth(piDepth).
            Depth = piDepth.
        end set.
    
    define public property Size as integer no-undo get. protected set.
    
    define private variable mcPrimitiveStack as character extent no-undo.
    define private variable moObjectStack as Object extent no-undo.
    define private variable mlObjectStack as logical no-undo.
    
    constructor protected Stack(poArray as Object extent):
        define variable iLoop as integer no-undo.
        
        this-object(extent(poArray)).
        
        /* The Size may not equal Depth for the input array, especially
           if this is a Stack being cloned. */        
        do iLoop = 1 to Depth while valid-object(poArray[iLoop]):
            this-object:ObjectPush(poArray[iLoop]).
        end.
    end constructor.
    
    constructor protected Stack(pcArray as character extent):
        this-object(extent(pcArray)).
        
        define variable iLoop as integer no-undo.
        do iLoop = 1 to Depth:
            this-object:PrimitivePush(pcArray[iLoop]).
        end.
    end constructor.
    
    constructor static Stack():
        Stack:DefaultStackDepth = 10.
    end constructor.
    
    constructor public Stack(piDepth as int):
        assign Depth = piDepth
               mlObjectStack = ?
               AutoExpand = false
               DiscardOnShrink = false.
    end constructor.
    
    constructor public Stack():
        this-object(Stack:DefaultStackDepth).
    end constructor.
    
    method private void SetStackDepth(piDepth as int):
        define variable cTempPrimitive as character extent no-undo.
        define variable oTempObject as Object extent no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        /* do nothing if there's nothing to do */
        if piDepth ne Depth then
        do:
            if piDepth lt Size and not DiscardOnShrink then
                undo, throw new ResizeError('array', 'smaller').
            
            /* On init there's no need for any of this. */
            if Depth eq 0 then
                assign iMax = 0.
            else
                assign extent(oTempObject) = Depth
                       extent(cTempPrimitive) = Depth
                       oTempObject = moObjectStack
                       cTempPrimitive = mcPrimitiveStack
                       extent(moObjectStack) = ?
                       extent(mcPrimitiveStack) = ?
                       iMax = Size.
            
            assign extent(moObjectStack) = piDepth
                   extent(mcPrimitiveStack) = piDepth
                   Size = 0.
            
            /* On init this loop won't execute */
            do iLoop = 1 to iMax:
                /* A stack can only be one or the other ... */
                if mlObjectStack then
                    ObjectPush(oTempObject[iLoop]).
                else
                    PrimitivePush(cTempPrimitive[iLoop]).
            end.
        end.
    end method.
    
    method protected void ObjectPush(poValue as Object):
        Assert:NotNull(poValue, 'Value').
        
        if Size eq Depth then
        do:
            if AutoExpand then 
                Depth = Size + round(0.5 * Size, 0).
            else
                undo, throw new StackOverflowError().
        end.
        
        assign Size = Size + 1
               moObjectStack[Size] = poValue
               mlObjectStack = true when mlObjectStack eq ?.
    end method.
    
    method protected Object ObjectPeek():
        /* Size should never be <= 0 but hey! ... */
        if Size le 0 then
            undo, throw new StackUnderflowError().
        
        if Size gt Depth then
            undo, throw new StackOverflowError().
        
        return moObjectStack[Size].
    end method.
    
    method protected Object ObjectPop():
        define variable oValue as Object no-undo.
        
        assign oValue = ObjectPeek()
               /* clean out necessary even though Size defines what's on top, 
                  so that we don't leak by holding a reference */
               moObjectStack[Size] = ?
               Size = Size - 1
               .
        return oValue.
    end method.    

    method protected void PrimitivePush(pcValue as character):
        if Size eq Depth then
        do:
            if AutoExpand then 
                Depth = Size + round(0.5 * Size, 0).
            else
                undo, throw new StackOverflowError().
        end.
        
        assign Size = Size + 1
               mcPrimitiveStack[Size] = pcValue
               mlObjectStack = false when mlObjectStack eq ?.
    end method.
    
    method protected character PrimitivePeek():
        /* Size should never be < 0 but hey! ... */
        if Size eq 0 then
            undo, throw new StackUnderflowError().
                        
        if Size gt Depth then
            undo, throw new StackOverflowError().
        
        return mcPrimitiveStack[Size].        
    end method.
    
    method protected character PrimitivePop():
        define variable cValue as character no-undo.
        
        assign cValue = PrimitivePeek()
               /* clean out not totally necessary, since Size defines what's on top */
               mcPrimitiveStack[Size] = ?   
               Size = Size - 1.
        
        return cValue.
    end method.
    
    method public void Swap(piFromPos as integer, piToPos as integer):
        define variable cTempPrimitive as character no-undo.
        define variable oTempObject as Object no-undo.

        if piFromPos eq piToPos then
            return.
        
        /* keep the first item */        
        if mlObjectStack then
            assign oTempObject = moObjectStack[piFromPos]
                   moObjectStack[piFromPos] = moObjectStack[piToPos]
                   moObjectStack[piToPos] = oTempObject.
        else
            assign cTempPrimitive = mcPrimitiveStack[piFromPos]
                   mcPrimitiveStack[piFromPos] = mcPrimitiveStack[piToPos]
                   mcPrimitiveStack[piToPos] = cTempPrimitive.
    end method.
    
    method public void Rotate(piItems as integer):
        define variable cTempPrimitive as character no-undo.
        define variable oTempObject as Object no-undo.
        define variable iLoop as integer no-undo.
        
        if piItems le 1 then
            return.
        
        /* keep the first item */        
        if mlObjectStack then
            oTempObject = moObjectStack[1].
        else
            cTempPrimitive = mcPrimitiveStack[1]. 
        
        do iLoop = 1 to piItems - 1:
            if mlObjectStack then
                moObjectStack[iLoop] = moObjectStack[iLoop + 1].
            else
                mcPrimitiveStack[iLoop] = mcPrimitiveStack[iLoop + 1]. 
        end.
        
        /* put the first item at the bottom of the rotation */
        if mlObjectStack then
            moObjectStack[piItems] = oTempObject.
        else
            mcPrimitiveStack[piItems] = cTempPrimitive.
    end method.
    
    method protected Object extent ObjectToArray():
        return moObjectStack.
    end method.

    method protected character extent PrimitiveToArray():
        return mcPrimitiveStack.        
    end method.
    
    method public void Invert():
        define variable cTempPrimitive as character extent no-undo.
        define variable oTempObject as Object extent no-undo.
        define variable iLoop as integer no-undo.
        
        /* No point, really */
        if Size le 1 then
            return.
        
        /* keep the first item */
        if mlObjectStack then
            oTempObject = moObjectStack.
        else            
            cTempPrimitive = mcPrimitiveStack.
        
        do iLoop = 1 to Size:
            if mlObjectStack then
                moObjectStack[iLoop] = oTempObject[Size - iLoop + 1].
            else
                mcPrimitiveStack[iLoop] = cTempPrimitive[Size - iLoop + 1].
        end.
    end method.
    
    method public override Object Clone():
        define variable oParams as ParameterList no-undo.
        
        oParams = new ParameterList(1).
        if Size eq 0 then
            oParams:SetParameter(1,
                                 DataTypeHelper:GetMask(DataTypeEnum:Integer),
                                 IOModeEnum:Input:ToString(),
                                 this-object:Depth).
        else
        if mlObjectStack then
            oParams:SetParameter(1,
                                 substitute(DataTypeHelper:GetMask(DataTypeEnum:ClassArray),
                                            DataTypeHelper:GetMask(DataTypeEnum:ProgressLangObject)),
                                 IOModeEnum:Input:ToString(),
                                 this-object:ObjectToArray() ).
        else
            oParams:SetParameter(1,
                                 DataTypeHelper:GetMask(DataTypeEnum:CharacterArray),
                                 IOModeEnum:Input:ToString(),
                                 this-object:PrimitiveToArray() ).
        
        return this-object:GetClass():New(oParams).
    end method.
    
    method protected logical ObjectContains(poItem as Object):
        define variable lContains as logical no-undo.
        define variable iLoop as integer no-undo.
        
        lContains = false.
        do iLoop = Size to 1 by -1 while not lContains:
            lContains = moObjectStack[iLoop]:Equals(poItem).
        end.
        
        return lContains.
    end method.
    
    method protected logical PrimitiveContains(pcItem as character):
        define variable lContains as logical no-undo.
        define variable iLoop as integer no-undo.

        lContains = false.
        do iLoop = Size to 1 by -1 while not lContains:
            lContains = mcPrimitiveStack[iLoop] eq pcItem.
        end.
        
        return lContains.
    end method.
    
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : StackOverflowError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Jan 05 14:44:07 EST 2010
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.StackOverflowError.
using OpenEdge.Core.System.ApplicationError.

class OpenEdge.Core.Collections.StackOverflowError serializable inherits ApplicationError: 
    constructor static StackOverflowError ():
        ApplicationError:AddError(
            get-class(StackOverflowError),
            /* short message */
            'Stack Overflow Error',
            /* message */
            'Stack overflow error').       
    end constructor.

    constructor public StackOverflowError():
        super().
    end constructor.

end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : StackError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Jan 05 14:44:07 EST 2010
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.StackUnderflowError.
using OpenEdge.Core.System.ApplicationError.

class OpenEdge.Core.Collections.StackUnderflowError serializable inherits ApplicationError: 
    constructor static StackUnderflowError():
        ApplicationError:AddError(
            get-class(StackUnderflowError),
            /* short message */
            'Stack Underflow Error',
            /* message */
            'Stack underflow error').       
    end constructor.

    constructor public StackUnderflowError():
        super().
    end constructor.
    
end class.
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : StringCollection
    Purpose     : A collection of String and character/longchar objects
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Feb 20 12:55:57 EST 2014
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.IStringCollection.
using OpenEdge.Core.String.

{OpenEdge/Core/Collections/typedcollectionclass.i
    &CollectionType = StringCollection
    &ValueType      = String
    &Package        = OpenEdge.Core.Collections
    &ImplementsType = IStringCollection
    &NoEndClass     = true
}
    /** Appends the specified element to list if not already present
    
        @param longchar The element to add to the collection
        @return logical True if the operation succeeded. */
    method public logical Add(input pcElement as longchar):
        return super:Add(new String(pcElement)).
    end method.

    /** [SLOW: O(n)] Adds an array of elements to the collection.  
       
        @param longchar[] An array of elements to add to the collection
        @return logical True if the operation succeeded. */
    method public logical AddArray(input pcElements as longchar extent):
        define variable oStringArray as String extent no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        assign iMax = extent(pcElements)
               extent(oStringArray) = iMax.
        do iLoop = 1 to iMax:
            oStringArray[iLoop] = new String(pcElements[iLoop]).
        end.
        
        return super:AddArray(oStringArray).        
    end method.
    
    /** Check whether the colleciton contains at least one object
        that matches the passed in object. 
        
        @param Object The object
        @return logical Returns true if the object is in the collection */
    method public logical Contains (input pcElement as longchar):
        return super:Contains(new String(pcElement)). 
    end method.    
    
   /** Removes the first occurrence in this list of the specified element
   
        @param Object The 
        @return logical True if the operation succeded. */
    method public logical Remove (input pcElement as longchar):
        return super:Remove(new String(pcElement)).
    end method.    

end class.
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : StringStringMap
    Purpose     : A map containing String keys and String values.
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Dec 18 13:55:14 EST 2013
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.IStringKeyedMap.
using OpenEdge.Core.String.
using Progress.Lang.Object.

{OpenEdge/Core/Collections/typedmapclass.i
    &Package        = OpenEdge.Core.Collections
    &ImplementsType = IStringKeyedMap
    
    &MapType   = StringKeyedMap
    &KeyType   = String
    &ValueType = Progress.Lang.Object
     
    &NoEndClass = true  }

    /** Adds an entry to the map
        
        @param character The key value
        @param Object The value
        @return Object The value added (may be previous value) */
    method public Object Put(input pcKey as character, input poValue as Progress.Lang.Object):
        return this-object:Put(new String(pcKey), poValue).
    end method.
        
    /** Retrieves the value for a particular key
    
        @param character The key value
        @return longchar The associated value */
    method public Progress.Lang.Object Get(input pcKey as character):
        return this-object:Get(new String(pcKey)).
    end method.
    
    /** Removes the value for a particular key
    
        @param character The key value
        @return longchar The associated value */
    method public Progress.Lang.Object Remove(input pcKey as character):
        return this-object:Remove(new String(pcKey)).
    end method.
    
    /** Indicates whether a map exists for this key

        @param character the key value
        @return logical True if this key exists */
    method public logical ContainsKey(input pcKey as character):
        return this-object:ContainsKey(new String(pcKey)).
    end method.

end class./************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : StringStringMap
    Purpose     : A map containing String keys and String values.
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Dec 18 13:55:14 EST 2013
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.IStringStringMap.
using OpenEdge.Core.String.
using Progress.Lang.Object.

{OpenEdge/Core/Collections/typedmapclass.i
    &Package        = OpenEdge.Core.Collections
    &ImplementsType = IStringStringMap
    
    &MapType   = StringStringMap
    &KeyType   = String
    &ValueType = String
     
    &NoEndClass = true  }

    /** Adds an entry to the map
        
        @param character The key value
        @param longchar The value
        @return longchar The value added (may be previous value) */
    method public longchar Put(input pcKey as character, input pcValue as longchar):
        define variable oOldValue as String no-undo.
        define variable lcOldValue as longchar no-undo.
                        
        oOldValue = this-object:Put(new String(pcKey), new String(pcValue)).
        if valid-object(oOldValue) then
            lcOldValue = oOldValue:Value.
        else
            lcOldValue = ?. 
        
        return lcOldValue.
    end method.
    
    /** Retrieves the value for a particular key
    
        @param character The key value
        @return longchar The associated value */
    method public longchar Get(input pcKey as character):
        define variable oValue as Object no-undo.
        
        assign oValue = this-object:Get(new String(pcKey)).
        if valid-object(oValue) then
            return cast(oValue, String):Value.
        else
            return ?.
    end method.
    
    /** Removes the value for a particular key
    
        @param character The key value
        @return longchar The associated value */
    method public longchar Remove(input pcKey as character):
        define variable oValue as Object no-undo.
        
        assign oValue = this-object:Remove(new String(pcKey)).
        if valid-object(oValue) then
            return cast(oValue, String):Value.
        else
            return ?.
    end method.
    
    /** Indicates whether a map exists for this key

        @param character the key value
        @return logical True if this key exists */
    method public logical ContainsKey(input pcKey as character):
        return this-object:ContainsKey(new String(pcKey)).
    end method.

    /** Indicates whether there is at least one value represented
        by the parameter in the map.
        
        @param longchar The value
        @return logical True if there is at least one entry with this value */    
    method public logical ContainsValue(input pcValue as character):
        return this-object:ContainsValue(new String(pcValue)).
    end method.
    
end class.&if 1=0 &then
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedcollectionclass.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL
    Notes       : * Arguments:
                        (opt) Package  : The package name for this interface(excludes interface)
                        CollectionType : The interface name only for this type (excludes package).
                        ValueType      : The type (class or interface) to be used for the Array's value. Depending on
                                          containing class, can take advantage of USING.
                        (opt) NoEndClass: Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END CLASS
                        (opt) ParentCollectionType: The type of the parent collection. Defaults to the Collection class.                                            
                  * Usage example: the below creates a 
                        {OpenEdge/Core/Collections/typedcollectionclass.i
                            &Package        = OpenEdge.InjectABL.Binding.Modules
                            &CollectionType = ModuleArray
                            &ValueType      = OpenEdge.InjectABL.Binding.Modules.IInjectionModule}
  ----------------------------------------------------------------------*/
&endif  
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&CollectionType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&CollectionType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then 
            &scoped-define FullType {&Package}{&CollectionType} 
        &else 
            &scoped-define FullType {&Package}.{&CollectionType} 
        &endif
    &endif
&endif

&if defined(ParentCollectionType) eq 0 &then
    &scoped-define ParentCollectionType OpenEdge.Core.Collections.Collection
&endif    

&if defined(ImplementsType) gt 0 &then
    &scoped-define Interfaces implements {&ImplementsType}
&else
    &scoped-define ImplementsType OpenEdge.Core.Collections.ICollection
&endif    

&if defined(IsSerializable) &then
&if keyword-all('serializable') eq 'serializable' &then
    &scoped-define serializable serializable
&endif 
&endif

class {&FullType} {&serializable} inherits {&ParentCollectionType} {&Interfaces}:
    constructor public {&CollectionType}():
        super().
    end constructor.
    
    constructor public {&CollectionType}(input poCollection as {&ImplementsType}):
        super(input poCollection).
    end constructor.

    /** Add an object to the collection.
    
        @param {&ValueType} The object to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical Add(input newObject as {&ValueType}):
        return super:Add(newObject).
    end method.
    
    /** Add an array of objects to the collection.
    
        @param {&CollectionType}[] The array to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical AddArray(input poArray as {&ValueType} extent):
        return super:AddArray(poArray).
    end method.

    /** Remove an object from the collection.
    
        @param {&ValueType} The object to remove from the collection
        @return logical True if the operation succeeded.     */    
    method public logical Remove(input oldObject as {&ValueType}):
        return super:Remove(oldObject).
    end method.
    
    &if defined(Interfaces) gt 0 &then
    /** Add a collection of objects to the collection.
    
        @param {&CollectionType} The collection to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical AddAll(input poCollection as {&ImplementsType}):
        return super:AddAll(poCollection).
    end method.
    
    /* Removes from this collection all the elements that are contained in the
       specified collection (optional operation). 
       
       @param  {&CollectionType} The collection of objects to remove.
       @return logical True if the operation succeeded. */
    method public logical RemoveAll(input poCollection as {&ImplementsType}):
        return super:RemoveAll(poCollection).
    end method.
    
    /* Retains only the elements in this list that are contained in the 
       specified collection (optional operation). return true if the object changed 
       
       @param  {&CollectionType} The collection of objects to retain.
       @return logical True if the operation succeeded. */
    method public logical RetainAll(input poCollection as {&ImplementsType}):
        return super:RetainAll(poCollection).
    end method.
    &endif
    
    /** Determine whether an object is in the collection.
        
        @param {&ValueType} The object to check in the collection
        @return logical True if the operation succeeded.     */    
    method public logical Contains(input checkObject as {&ValueType}):
        return super:Contains(checkObject).
    end method.
    
    /* Returns the elements in this collection as an ABL array.
       
       @return {&ValueType}[]  An ABL array of the objects in this collection */
    method public {&ValueType} extent To{&ValueType}Array ():
        return cast(super:ToArray(), {&ValueType}). 
    end method.
&if defined(NoEndClass) eq 0 &then     
end class. 
&endif 
&if 1=0 &then
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedcollectioninterface.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Jun 20 10:35:42 EDT 2012
    Notes       : * Arguments:
                        (opt) Package  : The package name for this interface(excludes interface)
                        CollectionType : The interface name only for this type (excludes package).
                        ValueType      : The type (class or interface) to be used for the Array's value. Depending on
                                          containing class, can take advantage of USING.
                        (opt) NoEndInterface : Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END INTERFACE
                        (opt) ParentCollectionType: The type of the parent collection. Defaults to the ICollection interface.                                          
                  * Usage example: the below creates a 
                        {OpenEdge/Core/Collections/typedcollectioninterface.i
                            &Package        = OpenEdge.InjectABL.Binding.Modules
                            &CollectionType = IModuleArray
                            &ValueType      = OpenEdge.ICnjectABL.Binding.Modules.IInjectionModule}
  ----------------------------------------------------------------------*/
&endif  
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&CollectionType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&CollectionType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then
            &scoped-define FullType {&Package}{&CollectionType}
        &else
            &scoped-define FullType {&Package}.{&CollectionType}
        &endif
    &endif
&endif

&if defined(ParentCollectionType) eq 0 &then
    &scoped-define ParentCollectionType OpenEdge.Core.Collections.ICollection
&endif

interface {&FullType} inherits {&ParentCollectionType}:
    /** Add an object to the collection.
    
        @param {&ValueType} The object to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical Add(input newObject as class {&ValueType}).
    
    /** Add a collection of objects to the collection.
    
        @param {&CollectionType} The collection to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical AddAll(input poCollection as class {&FullType}).
    
    /** Add an array of objects to the collection.
    
        @param {&CollectionType}[] The array to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical AddArray(input poArray as class {&ValueType} extent).

    /** Remove an object from the collection.
    
        @param {&ValueType} The object to remove from the collection
        @return logical True if the operation succeeded.     */    
    method public logical Remove(input oldObject as class {&ValueType}).
    
    /* Removes from this collection all the elements that are contained in the
       specified collection (optional operation). 
       
       @param  {&CollectionType} The collection of objects to remove.
       @return logical True if the operation succeeded. */
    method public logical RemoveAll(input poCollection as class {&FullType}).
    
    /* Retains only the elements in this list that are contained in the 
       specified collection (optional operation). return true if the object changed 
       
       @param  {&CollectionType} The collection of objects to retain.
       @return logical True if the operation succeeded. */
    method public logical RetainAll(input poCollection as class {&FullType}).
    
    /** Determine whether an object is in the collection.
        
        @param {&ValueType} The object to check in the collection
        @return logical True if the operation succeeded.     */    
    method public logical Contains(input checkObject as class {&ValueType}).
    
    /* Returns the elements in this collection as an ABL array.
       
       @return {&ValueType}[]  An ABL array of the objects in this collection */
    /* Returns the elements in this collection as an ABL array.
       
       @return {&CollectionType}[]  An ABL array of the objects in this collection */
    method public class {&ValueType} extent To{&ValueType}Array ():
    
&if defined(NoEndInterface) eq 0 &then     
end interface. 
&endif 
&if 1=0 &then
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedlinkedlist.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL
                  Defines a single-linked-list (ie forward/one-way only)
    Notes       : * Arguments:
                        (opt) Package  : The package name for this interface(excludes interface)
                        ListType       : The type of this list
                        NodeType       : The type of the nodes that this list manages
                        (opt) NoEndClass: Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END CLASS
                  * Usage example: the below creates a geenric ListNode object 
                        {OpenEdge/Core/Collections/typedlinkedlist.i
                            &Package    = OpenEdge.Core.Collections
                            &ListType   = LinkedList
                            &NodeType   = ListNode }
  ----------------------------------------------------------------------*/
&endif  
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&ListType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&ListType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then 
            &scoped-define FullType {&Package}{&ListType} 
        &else 
            &scoped-define FullType {&Package}.{&ListType} 
        &endif
    &endif
&endif

&if defined(IsSerializable) &then
&if keyword-all('serializable') eq 'serializable' &then
    &scoped-define serializable serializable
&endif 
&endif

&if defined(ImplementsType) gt 0 &then
    &scoped-define Interfaces implements {&ImplementsType}
&endif

class {&FullType} {&serializable} {&Interfaces}:
    /** The first node in this list */
    define public property First as class {&NodeType} no-undo get. private set.
    
    constructor public {&ListType}():
    end constructor.

    /** Constructor
        @param  {&NodeType} The first node this list is managing */
    constructor public {&ListType}(input poNode as class {&NodeType}):
        OpenEdge.Core.Assert:NotNull(poNode, 'Node').
        
        InsertFirst(poNode).
    end constructor.
    
    /** Removes the first node, and replaces it with the next in the list.
        Equivalent to a stack pop. */
    method public void RemoveFirst():
        if valid-object(this-object:First) and
           valid-object(this-object:First:Next) then
            InsertFirst(this-object:First:Next).
        /* GC will clean up this-object:First if necessary */
    end method.
    
    /** Adds a Node in the first position. Will move the linked list along.
        The new node cannot have a valid Next property.
        
        @param {&NodeType} The node to insert. */            
    method public void InsertFirst(input poNode as class {&NodeType}):
        OpenEdge.Core.Assert:NotNull(poNode, 'Node').
        OpenEdge.Core.Assert:IsNull(poNode:Next, 'Node').
        
        if valid-object(this-object:First) then
            assign poNode:Next = this-object:First.
        
        this-object:First = poNode.
    end method.

    /** Adds a Node at the end of the list. 
        
        @param {&NodeType} The node to insert. */            
    method public void InsertLast(input poNode as class {&NodeType}):
        define variable oLastNode as class {&NodeType} no-undo.
        
        OpenEdge.Core.Assert:NotNull(poNode, 'Node').
        
        assign oLastNode = this-object:First.
        do while valid-object(oLastNode) and
                 valid-object(oLastNode:Next):
            assign oLastNode = oLastNode:Next. 
        end.
        
        /* if there are no nodes at all, set it to the first */
        if not valid-object(oLastNode) then
            assign this-object:First = poNode.
        else
            assign oLastNode:Next = poNode.
    end method.
    
    /** Adds a Node after another specified Node.
    
        @param {&NodeType} The node to insert the new node after.
        @param {&NodeType} The new node to insert. */            
    method static public void InsertAfter(input poNode as class {&NodeType}, 
                                          input poNewNode as class {&NodeType}):
        OpenEdge.Core.Assert:NotNull(poNode, 'Node').
        OpenEdge.Core.Assert:NotNull(poNewNode, 'New node').
        
        assign poNewNode:Next = poNode:Next
               poNode:Next = poNewNode.
    end method.
    
    /** Removes a Node after another specified Node. Ensures the list is still 
        linked. 
    
        @param {&NodeType} The node to insert the new node after. */
    method static public void RemoveAfter(input poNode as class {&NodeType}):
        OpenEdge.Core.Assert:NotNull(poNode, 'Node').
        
        if valid-object(poNode:Next) then
            assign poNode:Next = poNode:Next:Next.        
    end method.
    
&if defined(NoEndClass) eq 0 &then     
end class. 
&endif 

    &if 1=0 &then
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedlistclass.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Jun 20 10:35:42 EDT 2012
    Notes       : * Arguments:
                        (opt) Package  : The package name for this interface(excludes interface)
                        CollectionType : The interface name only for this type (excludes package).
                        ValueType      : The type (class or interface) to be used for the Array's value. Depending on
                                          containing class, can take advantage of USING.
                        (opt) NoEndInterface : Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END INTERFACE
                        (opt) ParentCollectionType: The type of the parent collection. Defaults to the List class.
                        (opt) ImplementsType : A typed interface this class implements.                                          
                  * Usage example: the below creates a 
                        {OpenEdge/Core/Collections/typedlistclass.i
                            &Package        = OpenEdge.InjectABL.Binding.Modules
                            &CollectionType = IModuleArray
                            &ValueType      = OpenEdge.InjectABL.Binding.Modules.IInjectionModule}
  ----------------------------------------------------------------------*/
&endif  
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&CollectionType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&CollectionType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then
            &scoped-define FullType {&Package}{&CollectionType}
        &else
            &scoped-define FullType {&Package}.{&CollectionType}
        &endif
    &endif                
&endif

&if defined(ParentCollectionType) eq 0 &then
    &scoped-define ParentCollectionType OpenEdge.Core.Collections.List
&endif    

&if defined(ImplementsType) gt 0 &then
    &scoped-define Interfaces implements {&ImplementsType}
&else
    &scoped-define ImplementsType OpenEdge.Core.Collections.IList
&endif    

&if defined(IsSerializable) &then
&if keyword-all('serializable') eq 'serializable' &then
    &scoped-define serializable serializable
&endif 
&endif

class {&FullType} {&serializable} inherits {&ParentCollectionType} {&Interfaces}:
    constructor public {&CollectionType}():
        super().        
    end constructor.
       
    constructor public {&CollectionType}(list as {&ImplementsType}):
        super(list).
    end constructor.
    
    /* Inserts the specified element at the specified position in this list 
       (optional operation).*/      
    method public logical Add(i as int, o as {&ValueType}):
        return super:Add(i, o).
    end method.
       
    /* Appends the specified element to the end of this list 
       (optional operation). */
    method public logical Add(o as {&ValueType}):
        return super:Add(o).
    end method.

    &if defined(Interfaces) gt 0 &then       
    /* Appends all of the elements in the specified collection to the end 
      of this list, in the order that they are returned by the specified 
      collection's iterator (optional operation). */
    method public logical AddAll(c as {&ImplementsType}):
        return super:AddAll(c).
    end method.
       
    /* Inserts all of the elements in the specified collection into this list 
      at the specified position (optional operation).  */
    method public logical AddAll(i as int,c as {&ImplementsType}):
        return super:AddAll(i,c).
    end method.

    /* Returns true if this list contains all of the elements of the 
      specified collection. */
    method public logical ContainsAll(c as {&ImplementsType}):
        return super:ContainsAll(c).
    end method. 

    /* Removes from this list all the elements that are contained in the 
      specified collection (optional operation). */
    method public logical RemoveAll (c as {&ImplementsType}):
        return super:RemoveAll(c).
    end method. 
      
    /* Retains only the elements in this list that are contained in the 
      specified collection (optional operation).*/
    method public logical RetainAll (c as {&ImplementsType}):
        return super:RetainAll(c).
    end method. 
    &endif
        
    /** Appends all the elements in the array this list, optionally
       at the specified position. */
    method public logical AddArray(c as {&ValueType} extent):
        return super:AddArray(c).
    end method.
        
    method public logical AddArray(i as int, c as {&ValueType} extent):
        return super:AddArray(i, c).
    end method.        
    
    /* Returns true if this list contains the specified element. */
    method public logical Contains (o as {&ValueType}):
        return super:Contains(o).
    end method. 
       
    
    /* Returns the element at the specified position in this list. */       
    method public {&ValueType} Get{&ValueType}(i as int):
        return cast(super:Get(i), {&ValueType}).
    end method. 
     
    /* Returns the index in this list of the first occurrence of the specified 
      element, or 0 if this list does not contain this element.  */       
    method public integer IndexOf(o as {&ValueType}):
        return super:IndexOf(o).
    end method. 
       
    /*  Returns the index in this list of the last occurrence of the 
       specified element, or 0 if this list does not contain this element. */
    method public integer LastIndexOf(o as {&ValueType}):
        return super:LastIndexOf(o).
    end method.
       
    /* Removes the element at the specified position in this list
     (optional operation). */
    method public {&ValueType} Remove{&ValueType}(i as integer):
        return cast(super:Remove(i), {&ValueType}).
    end method.
       
    /* Removes the first occurrence in this list of the specified element 
     (optional operation). */
    method public logical Remove (o as {&ValueType}):
        return super:Remove(o).
    end method. 
    
      
    /* Replaces the element at the specified position in this list with the 
      specified element (optional operation). */
    method public {&ValueType} Set (i as int, o as {&ValueType}):
        return cast(super:set(i, o), {&ValueType}).
    end method.
    
    /* Returns a view of the portion of this list between the specified 
      fromIndex, inclusive, and toIndex, exclusive. */
    method public {&ImplementsType} SubList{&ValueType}(fromIndex as int, toIndex as int):
        return cast(super:SubList(fromIndex, toIndex), {&ImplementsType}).
    end method.
    
    /* returns the contents of the list as an array */
    method public {&ValueType} extent To{&ValueType}Array ():
        return cast(super:ToArray(), {&ValueType}).
    end method.
    
&if defined(NoEndClass) eq 0 &then     
end class. 
&endif 
&if 1=0 &then
/************************************************
Copyright (c) 2014,2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedlistinterface.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Jun 20 10:35:42 EDT 2012
    Notes       : * Arguments:
                        (opt) Package  : The package name for this interface(excludes interface)
                        CollectionType : The interface name only for this type (excludes package).
                        ValueType      : The type (class or interface) to be used for the Array's value. Depending on
                                          containing class, can take advantage of USING.
                        (opt) NoEndInterface : Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END INTERFACE
                        (opt) ParentCollectionType: The type of the parent collection. Defaults to the IList interface.                                          
                  * Usage example: the below creates a 
                        {OpenEdge/Core/Collections/typedcollectioninterface.i
                            &Package        = OpenEdge.InjectABL.Binding.Modules
                            &CollectionType = IModuleArray
                            &ValueType      = OpenEdge.InjectABL.Binding.Modules.IInjectionModule}
  ----------------------------------------------------------------------*/
&endif  
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&CollectionType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&CollectionType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then
            &scoped-define FullType {&Package}{&CollectionType}
        &else
            &scoped-define FullType {&Package}.{&CollectionType}
        &endif
    &endif                
&endif

&if defined(ParentCollectionType) eq 0 &then
    &scoped-define ParentCollectionType OpenEdge.Core.Collections.IList
&endif    

interface {&FullType} inherits {&ParentCollectionType}:
    /* Inserts the specified element at the specified position in this list 
       (optional operation).*/      
    method public logical Add(i as int, o as {&ValueType}).
       
    /* Appends the specified element to the end of this list 
       (optional operation). */
    method public logical Add(o as {&ValueType}).
       
    /* Appends all of the elements in the specified collection to the end 
      of this list, in the order that they are returned by the specified 
      collection's iterator (optional operation). */
    method public logical AddAll(c as {&FullType}).
       
    /* Inserts all of the elements in the specified collection into this list 
      at the specified position (optional operation).  */
    method public logical AddAll(i as int,c as {&FullType}).
       
    /** Appends all the elements in the array this list, optionally
       at the specified position. */
    method public logical AddArray(c as {&ValueType} extent).
    method public logical AddArray(i as int, c as {&ValueType} extent).
       
    /* Returns true if this list contains the specified element. */
    method public logical Contains (o as {&ValueType}). 
       
    /* Returns true if this list contains all of the elements of the 
      specified collection. */
    method public logical ContainsAll(c as {&FullType}). 
       
    /* Returns the element at the specified position in this list. */       
    method public {&ValueType} Get{&ValueType}(i as int). 
     
    /* Returns the index in this list of the first occurrence of the specified 
      element, or 0 if this list does not contain this element.  */       
    method public integer IndexOf(o as {&ValueType}). 
       
    /*  Returns the index in this list of the last occurrence of the 
       specified element, or 0 if this list does not contain this element. */
    method public integer LastIndexOf(o as {&ValueType}).
       
    /* Removes the element at the specified position in this list
     (optional operation). */
    method public {&ValueType} Remove{&ValueType}(i as integer). 
       
    /* Removes the first occurrence in this list of the specified element 
     (optional operation). */
    method public logical Remove (o as {&ValueType}). 
    
    /* Removes from this list all the elements that are contained in the 
      specified collection (optional operation). */
    method public logical RemoveAll (c as {&FullType}). 
      
    /* Retains only the elements in this list that are contained in the 
      specified collection (optional operation).*/
    method public logical RetainAll (c as {&FullType}). 
      
    /* Replaces the element at the specified position in this list with the 
      specified element (optional operation). */
    method public {&ValueType} Set (i as int, o as {&ValueType}).
    
    /* Returns a view of the portion of this list between the specified 
      fromIndex, inclusive, and toIndex, exclusive. */
    method public {&FullType} SubList{&ValueType}(fromIndex as int, toIndex as int).
    
    /* returns the contents of the list as an array */
    method public {&ValueType} extent To{&ValueType}Array (): 
    
&if defined(NoEndInterface) eq 0 &then     
end interface. 
&endif    
&if 1=0 &then
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedlistnode.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL
    Notes       : * Arguments:
                        (opt) Package  : The package name for this type(excludes class name)
                        NodeType       : The name of this class.
                        ValueType      : The type (class or interface) to be used for the 'Data' value. Depending on
                                         containing class, can take advantage of USING.
                        (opt) NoEndClass: Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END CLASS
                        (opt) IsSerializable: Is this a serializable type? true or false                                            
                  * Usage example: the below creates a geenric ListNode object 
                        {OpenEdge/Core/Collections/typedlistnode.i
                            &Package    = OpenEdge.Core.Collections
                            &NodeType   = ListNode
                            &ValueType  = Object    }
  ----------------------------------------------------------------------*/
&endif  
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&NodeType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&NodeType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then 
            &scoped-define FullType {&Package}{&NodeType} 
        &else 
            &scoped-define FullType {&Package}.{&NodeType} 
        &endif
    &endif
&endif

&if defined(IsSerializable) &then
&if keyword-all('serializable') eq 'serializable' &then
    &scoped-define serializable serializable
&endif 
&endif

class {&FullType} {&serializable}: 
    define public property Next as class {&FullType} no-undo get. set.
    define public property Data as class {&ValueType} no-undo get. set.
    
    constructor public {&NodeType}(input poData as class {&ValueType}):
        this-object:Data = poData.
    end constructor.

&if defined(NoEndClass) eq 0 &then
end class. 
&endif 

&if 1=0 &then
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedmapclass.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL  
    Author(s)   : 
    Created     : Wed Dec 11 14:16:42 EST 2013
    Notes       : * Arguments:
                        Package     : The package name for this class (excludes class)
                        MapType     : The class name only for this type (excludes package).
                        KeyType     : The type (class or interface) to be used for the Map's key. Depending on
                                      containing class, can take advantage of USING.   
                        ValueType   : The type (class or interface) to be used for the Map's value. Depending on
                                      containing class, can take advantage of USING.
                        NoEndClass  : Passed if the containing class has additional methods to be added. 
                                      If specified, the containing class must
                        (opt) ParentCollectionType: The type of the parent collection. Defaults to the Map class.                                       
                  * Usage example: the below creates a collection 
                        {OpenEdge/Core/Collections/typedmapclass.i
                            &Package   = OpenEdge.InjectABL.Binding.Modules
                            &MapType   = IInjectionModuleCollection
                            &KeyType   = OpenEdge.Core.String
                            &ValueType = OpenEdge.InjectABL.Binding.Modules.IInjectionModule}
  ----------------------------------------------------------------------*/
&endif  
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&MapType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&MapType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then
            &scoped-define FullType {&Package}{&MapType}
        &else
            &scoped-define FullType {&Package}.{&MapType}
        &endif
    &endif                
&endif

&if defined(ParentCollectionType) eq 0 &then
    &scoped-define ParentCollectionType OpenEdge.Core.Collections.Map
&endif

&if defined(ImplementsType) gt 0 &then
    &scoped-define Interfaces implements {&ImplementsType}
&else
    &scoped-define ImplementsType OpenEdge.Core.Collections.IMap
&endif
    
&if defined(IsSerializable) &then
&if keyword-all('serializable') eq 'serializable' &then
    &scoped-define serializable serializable
&endif 
&endif

class {&FullType} {&serializable} inherits {&ParentCollectionType} {&Interfaces}:
    constructor public {&MapType}(input poMap as {&ImplementsType}):
        super(poMap).
    end constructor.
    
    constructor public {&MapType}():
        super().
    end constructor.
    
    /* Associates the specified value with the specified key in this map (optional operation).*/
    method public {&ValueType} Put(input poKey as {&KeyType}, input poValue as {&ValueType}):
        &if '{&ValueType}' ne 'Object' and '{&ValueType}' ne 'Progress.Lang.Object' &then
        OpenEdge.Core.Assert:IsType(poValue,  get-class({&ValueType})).
        return cast(super:Put(poKey, poValue), {&ValueType}).
        &else
        return super:Put(poKey, poValue).
        &endif
    end method.
    
    method override public Progress.Lang.Object Put(input poKey as Progress.Lang.Object, input poValue as Progress.Lang.Object):
        OpenEdge.Core.Assert:IsType(poKey,  get-class({&KeyType})).
        
        &if '{&ValueType}' ne 'Object' and '{&ValueType}' ne 'Progress.Lang.Object' &then
        OpenEdge.Core.Assert:IsType(poValue,  get-class({&ValueType})).
        return cast(super:Put(poKey, poValue), {&ValueType}).
        &else
        return super:Put(poKey, poValue).
        &endif
    end method.
    
    /* Removes the mapping for this key from this map if it is present (optional operation).*/
    method public {&ValueType} Remove(input poKey as {&KeyType}):
        &if '{&ValueType}' ne 'Object' and '{&ValueType}' ne 'Progress.Lang.Object' &then
        return cast(super:Remove(poKey), {&ValueType}).
        &else
        return super:Remove(poKey).
        &endif
    end method.

    /* Removes the mapping for this key from this map if it is present (optional operation).*/
    method override public Progress.Lang.Object Remove(input poKey as Progress.Lang.Object):
        OpenEdge.Core.Assert:IsType(poKey,  get-class({&KeyType})).
        &if '{&ValueType}' ne 'Object' and '{&ValueType}' ne 'Progress.Lang.Object' &then
        return cast(super:Remove(poKey), {&ValueType}).
        &else
        return super:Remove(poKey).
        &endif
    end method.
    
    &if '{&ParentCollectionType}' eq 'OpenEdge.Core.Collections.Map' and 
        '{&KeyType}' ne 'Object' and '{&KeyType}' ne 'Progress.Lang.Object' &then
    /* Returns true if this map contains a mapping for the specified key. */
    method override public logical ContainsKey(input poKey as Progress.Lang.Object):
        OpenEdge.Core.Assert:IsType(poKey,  get-class({&KeyType})).
        return super:ContainsKey(poKey).
    end method.
    
    /* Returns true if this map contains a mapping for the specified key. */
    method public logical ContainsKey(input poKey as {&KeyType}):
        return super:ContainsKey(poKey).
    end method.
    &endif
    
    &if '{&ParentCollectionType}' eq 'OpenEdge.Core.Collections.Map' and 
        '{&ValueType}' ne 'Object' and '{&ValueType}' ne 'Progress.Lang.Object' &then
    /* Returns true if this map maps one or more keys to the specified value.*/
    method override public logical ContainsValue(input poValue as Progress.Lang.Object):
        OpenEdge.Core.Assert:IsType(poValue,  get-class({&ValueType})).
        return super:ContainsValue(poValue).
    end method.
    
    /* Returns true if this map maps one or more keys to the specified value.*/
    method public logical ContainsValue(input poValue as {&ValueType}):
        return super:ContainsValue(poValue).
    end method.
    &endif
       
    &if '{&ParentCollectionType}' eq 'OpenEdge.Core.Collections.Map' and 
        '{&KeyType}' ne 'Object' and '{&KeyType}' ne 'Progress.Lang.Object' &then
    /* Returns the value to which this map maps the specified key.*/
    method override public Progress.Lang.Object Get(input poKey as Progress.Lang.Object):
        OpenEdge.Core.Assert:IsType(poKey,  get-class({&KeyType})).

        &if '{&ValueType}' ne 'Object' and '{&ValueType}' ne 'Progress.Lang.Object' &then
        return cast(super:Get(poKey), {&ValueType}).
        &else
        return super:Get(poKey).
        &endif
    end method.
    
    /* Returns the value to which this map maps the specified key.*/
    method public {&ValueType} Get(input poKey as {&KeyType}):
        &if '{&ValueType}' ne 'Object' and '{&ValueType}' ne 'Progress.Lang.Object' &then
        return cast(super:Get(poKey), {&ValueType}).
        &else
        return super:Get(poKey).
        &endif
    end method.
    &endif 

    &if defined(Interfaces) gt 0 &then
    method public void PutAll(input poMap as {&ImplementsType}):
        super:PutAll(poMap).
    end method.
    
    method override public void PutAll(input poMap as OpenEdge.Core.Collections.IMap):
        OpenEdge.Core.Assert:IsType(poMap, get-class({&ImplementsType})).
        super:PutAll(poMap).
    end method.
    &endif
&if defined(NoEndClass) eq 0 &then     
end class. 
&endif 
&if 1=0 &then
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedmapinterface.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL  
    Author(s)   : 
    Created     : Wed Dec 11 14:16:42 EST 2013
    Notes       : * Arguments:
                        Package        : The package name for this interface (excludes interface)
                        MapType        : The name for this interface (excludes package)
                        KeyType        : The type (class or interface) to be used for the Map's key   
                        ValueType      : The type (class or interface) to be used for the Map's value
                        NoEndInterface : Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END INTERFACE
                        (opt) ParentCollectionType: The type of the parent collection. Defaults to the IMap interface.                                          
                  * Usage example: the below creates a collection 
                        {OpenEdge/Core/Collections/typedmapinterface.i
                            &Package   = OpenEdge.InjectABL.Binding.Modules
                            &MapType   = IInjectionModuleCollection
                            &KeyType   = OpenEdge.Core.String
                            &ValueType = OpenEdge.InjectABL.Binding.Modules.IInjectionModule}
  ----------------------------------------------------------------------*/
&endif  
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&MapType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&MapType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then
            &scoped-define FullType {&Package}{&MapType}
        &else
            &scoped-define FullType {&Package}.{&MapType}
        &endif
    &endif                
&endif

&if defined(ParentCollectionType) eq 0 &then
    &scoped-define ParentCollectionType OpenEdge.Core.Collections.IMap
&endif

interface {&FullType} inherits {&ParentCollectionType}:
    /** Associates the specified value with the specified key in this map (optional operation).*/
    method public {&ValueType} Put(input poKey as {&KeyType}, input poValue as {&ValueType}).

    /** Removes the mapping for this key from this map if it is present (optional operation).*/
    method public {&ValueType} Remove(input poKey as {&KeyType}).
    
    /** Returns true if this map contains a mapping for the specified key. */    
    method public logical ContainsKey(input poKey as {&KeyType}).
    
    /** Returns true if this map maps one or more keys to the specified value.*/
    method public logical ContainsValue(input poValue as {&ValueType}).

    /** Returns the value to which this map maps the specified key.*/
    method public {&ValueType} Get(input poKey as {&KeyType}).
    
    /** Adds all data from the input map into this map */    
    method public void PutAll(input poMap as {&FullType}).
&if defined(NoEndInterface) eq 0 &then
end interface. 
&endif 
&if 1=0 &then
/************************************************
Copyright (c)  2014, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedsetclass.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL
    Notes       : * Arguments:
                        (opt) Package  : The package name for this interface(excludes interface)
                        CollectionType : The interface name only for this type (excludes package).
                        ValueType      : The type (class or interface) to be used for the Array's value. Depending on
                                          containing class, can take advantage of USING.
                        (opt) NoEndClass: Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END CLASS
                        (opt) ParentCollectionType: The type of the parent collection. Defaults to the Collection class.                                            
                  * Usage example: the below creates a 
                        {OpenEdge/Core/Collections/typedsetclass.i
                            &Package        = OpenEdge.InjectABL.Binding.Modules
                            &CollectionType = ModuleArray
                            &ValueType      = OpenEdge.InjectABL.Binding.Modules.IInjectionModule}
  ----------------------------------------------------------------------*/
&endif
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&MapType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&MapType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then
            &scoped-define FullType {&Package}{&CollectionType}
        &else
            &scoped-define FullType {&Package}.{&CollectionType}
        &endif
    &endif                
&endif

&if defined(ParentCollectionType) eq 0 &then
    &scoped-define ParentCollectionType OpenEdge.Core.Collections.Set
&endif    

&if defined(ImplementsType) gt 0 &then
    &scoped-define Interfaces implements {&ImplementsType}
&else
    &scoped-define ImplementsType OpenEdge.Core.Collections.ISet
&endif    

&if defined(IsSerializable) &then
&if keyword-all('serializable') eq 'serializable' &then
    &scoped-define serializable serializable
&endif 
&endif

class {&FullType} {&serializable} inherits {&ParentCollectionType} {&Interfaces}:
    constructor public {&CollectionType}():
        super().
    end constructor.
    
    constructor public {&CollectionType}(input poCollection as {&ImplementsType}):
        super(input poCollection).
    end constructor.

    /** Add an object to the collection.
    
        @param {&ValueType} The object to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical Add(input newObject as {&ValueType}):
        return super:Add(newObject).
    end method.
    
    /** Add a collection of objects to the collection.
    
        @param {&CollectionType} The collection to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical AddAll(input poCollection as {&ImplementsType}):
        return super:AddAll(poCollection).
    end method.
    
    /** Add an array of objects to the collection.
    
        @param {&CollectionType}[] The array to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical AddArray(input poArray as {&ValueType} extent):
        return super:AddArray(poArray).
    end method.

    /** Remove an object from the collection.
    
        @param {&ValueType} The object to remove from the collection
        @return logical True if the operation succeeded.     */    
    method public logical Remove(input oldObject as {&ValueType}):
        return super:Remove(oldObject).
    end method.
    
    /* Removes from this collection all the elements that are contained in the
       specified collection (optional operation). 
       
       @param  {&CollectionType} The collection of objects to remove.
       @return logical True if the operation succeeded. */
    method public logical RemoveAll(input poCollection as {&ImplementsType}):
        return super:RemoveAll(poCollection).
    end method.
    
    /* Retains only the elements in this list that are contained in the 
       specified collection (optional operation). return true if the object changed 
       
       @param  {&CollectionType} The collection of objects to retain.
       @return logical True if the operation succeeded. */
    method public logical RetainAll(input poCollection as {&ImplementsType}):
        return super:RetainAll(poCollection).
    end method.
    
    /** Determine whether an object is in the collection.
        
        @param {&ValueType} The object to check in the collection
        @return logical True if the operation succeeded.     */    
    method public logical Contains(input checkObject as {&ValueType}):
        return super:Contains(checkObject).
    end method.
    
    /* Returns the elements in this collection as an ABL array.
       
       @return {&ValueType}[]  An ABL array of the objects in this collection */
    method public {&ValueType} extent To{&ValueType}Array ():
        return cast(super:ToArray(), {&ValueType}). 
    end method.
&if defined(NoEndClass) eq 0 &then     
end class. 
&endif 
&if 1-0 &then
/************************************************
Copyright (c)  2014 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : OpenEdge/Core/Collections/typedsetinterface.i
    Purpose     : Include allowing us to workaround the lack of generics in ABL 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Jun 20 10:35:42 EDT 2012
    Notes       : * Arguments:
                        (opt) Package  : The package name for this interface(excludes interface)
                        CollectionType : The interface name only for this type (excludes package).
                        ValueType      : The type (class or interface) to be used for the Array's value. Depending on
                                          containing class, can take advantage of USING.
                        (opt) NoEndInterface : Passed if the containing interface has additional methods to be added. 
                                         If specified, the containing interface must add END INTERFACE
                        (opt) ParentCollectionType: The type of the parent set. Defaults to the Iset interface.                                          
                  * Usage example: the below creates a 
                        {OpenEdge/Core/Collections/typedsetinterface.i
                            &Package        = OpenEdge.InjectABL.Binding.Modules
                            &CollectionType = IModuleArray
                            &ValueType      = OpenEdge.InjectABL.Binding.Modules.IInjectionModule}
  ----------------------------------------------------------------------*/
&endif
&if defined(Package) eq 0 &then
    &scoped-define Package  
    &scoped-define FullType {&CollectionType} 
&elseif defined(Package) gt 0 &then
    &if length(trim("{&Package}")) eq  0 &then
        &scoped-define FullType {&CollectionType}
    &else
        &if substring("{&Package}", length("{&Package}"), 1) eq '.' &then
            &scoped-define FullType {&Package}{&CollectionType}
        &else
            &scoped-define FullType {&Package}.{&CollectionType}
        &endif
    &endif
&endif

&if defined(ParentCollectionType) eq 0 &then
    &scoped-define ParentCollectionType OpenEdge.Core.Collections.ISet
&endif    

interface {&FullType} inherits {&ParentCollectionType}:
    /** Add an object to the collection.
    
        @param {&ValueType} The object to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical Add(input newObject as {&ValueType}).
    
    /** Add a collection of objects to the collection.
    
        @param {&CollectionType} The collection to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical AddAll(input poCollection as {&FullType}).
    
    /** Add an array of objects to the collection.
    
        @param {&CollectionType}[] The array to add to the collection
        @return logical True if the operation succeeded.     */    
    method public logical AddArray(input poArray as {&ValueType} extent).

    /** Remove an object from the collection.
    
        @param {&ValueType} The object to remove from the collection
        @return logical True if the operation succeeded.     */    
    method public logical Remove(input oldObject as {&ValueType}).
    
    /* Removes from this collection all the elements that are contained in the
       specified collection (optional operation). 
       
       @param  {&CollectionType} The collection of objects to remove.
       @return logical True if the operation succeeded. */
    method public logical RemoveAll(input poCollection as {&FullType}).
    
    /* Retains only the elements in this list that are contained in the 
       specified collection (optional operation). return true if the object changed 
       
       @param  {&CollectionType} The collection of objects to retain.
       @return logical True if the operation succeeded. */
    method public logical RetainAll(input poCollection as {&FullType}).
    
    /** Determine whether an object is in the collection.
        
        @param {&ValueType} The object to check in the collection
        @return logical True if the operation succeeded.     */    
    method public logical Contains(input checkObject as {&ValueType}).
    
    /* Returns the elements in this collection as an ABL array.
       
       @return {&ValueType}[]  An ABL array of the objects in this collection */
    method public {&ValueType} extent {&ValueType}Array ().
    
&if defined(NoEndInterface) eq 0 &then     
end interface. 
&endif 
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------------
    File        : ValueCollection
    Purpose     : ICollection implementation over values in an IMap (also TT based) 
                  object that needs collection capabilities.. 
                  used to return Values IMap 
    Syntax      : 
    Description : 
    @author hdaniels
    Created     : 2010
    Notes       : no empty constructor, specialized for IMap 
                 - Changes to the map are reflected here, and vice-versa. 
                 - Supports removal and removes the corresponding map entry from the map
                   (Iterator.remove, Collection.remove, removeAll, retainAll and clear) .
                 - Do not support add and addAll.   
                 - no empty constructor, specialised for IMap 
----------------------------------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Collections.ICollection.
using OpenEdge.Core.Collections.IIterator.
using OpenEdge.Core.Collections.Iterator.
using OpenEdge.Core.Collections.IMap.
using OpenEdge.Core.System.UnsupportedOperationError.
using OpenEdge.Core.Collections.MapBackedCollection.
using Progress.Lang.Object.

class OpenEdge.Core.Collections.ValueCollection serializable inherits MapBackedCollection:
    
    constructor public ValueCollection(poMap as IMap,phTT as handle, pcValuefield as char):
        super (poMap, phTT, pcValuefield).
    end constructor.
    
    method override public logical Contains( checkObject as Object):
        return OwningMap:ContainsValue(checkObject).
    end method.
    
    method override public logical ContainsAll(input poCollection as ICollection):
        return OwningMap:ContainsAllValues(poCollection).
    end method.
    
    /* slow... use Remove on Map or Map:KeySet() instead  */
    method override public logical Remove(poOld as Object):
        define variable oIter as IIterator no-undo.
        define variable oKey as Object    no-undo.
        define variable oValue as Object    no-undo.
        
        oIter = OwningMap:KeySet:Iterator().
        do while oIter:HasNext():
            oKey = oIter:Next().
            oValue  = OwningMap:Get(oKey).
            if oValue:Equals(poOld) then
            do:
                OwningMap:Remove(oKey).
                return true.
            end.
        end.
        return false.
    end method.
    
    method override public logical RemoveAll(poRemoveCol as ICollection):
        define variable oIter as IIterator no-undo.
        define variable oKey  as Object    no-undo.
        define variable oVal  as Object    no-undo.
        define variable lany as logical no-undo.
        
        oIter = OwningMap:KeySet:Iterator().
        do while oIter:HasNext():
            oKey = oIter:Next().
            oVal  = OwningMap:Get(oKey).
            if poRemoveCol:Contains(oVal) then
            do:  
                OwningMap:Remove(oKey).
                lAny = true.
            end.    
        end.
        return lAny.
    end method.
    
    method override public logical RetainAll(poCol as ICollection):
        define variable oIter as IIterator no-undo.
        define variable oKey  as Object    no-undo.
        define variable oVal  as Object    no-undo.
        define variable lany as logical no-undo.
        oIter = OwningMap:KeySet:Iterator().
        do while oIter:HasNext():
            oKey = oIter:Next().
            oVal  = OwningMap:Get(oKey).
            if not poCol:Contains(oVal) then
            do:  
                OwningMap:Remove(oKey).
                lAny = true.
            end.    
        end.
        return lAny.
    end method.
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : ConnectionParameters
    Purpose     : Standard Connection Parameters  
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Feb 28 15:07:49 EST 2013
    Notes       : * The Options property contains JSON data.
                    This Json Data is structured as follows:
                        {"option1":"value1", "option2":"value2", ..., "optionN":"valueN"}
                  * The FormatMask property contains a mask to be used together with
                    the ABL SUBSTITUTE function. It can include up to 9 substitutions (&1-&9)
                    and should also include any key/value pair separators (space, usually).
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.ServerConnection.FormatMaskEnum.
using OpenEdge.Core.ServerConnection.FormatMaskHelper.
using OpenEdge.Core.ServerConnection.IConnectionParameters.
using OpenEdge.Core.ServerConnection.ConnectionParameters.
using Progress.Json.ObjectModel.JsonDataType.
using Progress.Json.ObjectModel.JsonObject.
using Progress.Json.ObjectModel.ObjectModelParser.
using Progress.Lang.AppError.

class OpenEdge.Core.ServerConnection.ConnectionParameters 
            implements IConnectionParameters: 
    
    /** A set of options for a Server Connection */
    define protected property Options as JsonObject no-undo get. set.
    
    /* Resolved connection parameters. For use where the Options only need to
       be resolved once. */
    define protected property ResolvedOptions as character no-undo get. set.
    
    /** The FormatMask property contains a mask to be used together with
        the ABL SUBSTITUTE function. It can include up to 9 substitutions (&1-&9)
        and should also include any key/value pair separators (space, usually). */    
    define public property FormatMask as FormatMaskEnum no-undo get. private set.
    
    constructor public ConnectionParameters(input pcOptions as character, input poFormatMask as FormatMaskEnum):
        define variable oOptions as JsonObject no-undo.
        define variable oParser as ObjectModelParser no-undo.
        
        if pcOptions eq '' or pcOptions eq ? then
            oOptions = new JsonObject().
        else
        do: 
            oParser = new ObjectModelParser().
            oOptions = cast(oParser:Parse(pcOptions), JsonObject).
        end.
        
        ShadowConstructor(oOptions, FormatMaskEnum:Default).
    end constructor.
    
    constructor public ConnectionParameters(input poOptions as JsonObject, input poFormatMask as FormatMaskEnum):
        ShadowConstructor(poOptions, poFormatMask).
    end constructor.
    
    /** Shadow constructor for this class. Used instead of a real constructor since some transformations
        have to happen before its called, and since a constructor must be invoked first via SUPER or THIS-OBJECT,
        there's no room for those transformations. 
        
        @param JsonObject     The options in JSON form
        @param FormatMaskEnum The Format mask to use for this connection. */
    method private void ShadowConstructor(input poOptions as JsonObject, poFormatMask as FormatMaskEnum):
        Assert:NotNull(poOptions, 'Options').        
        Assert:NotNull(poFormatMask, 'Format Mask').
        
        this-object:FormatMask = poFormatMask.
        this-object:Options = poOptions.
        
        this-object:Initialise().
    end method.
    
    /** Use this method for setting initial or default values, or other similar actions */
    method protected void Initialise():
    end method.
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @return character A useable string of connection parameters. */
    method public character GetConnectionString():
        return GetConnectionString(this-object:FormatMask).
    end method.
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @param character The format mask to use. Overrides the mask
                         specified by the property.
        @return character A useable string of connection parameters. */
    method public character GetConnectionString(input pcFormatMask as character):
        define variable oEnum as FormatMaskEnum no-undo.
        
        if this-object:FormatMask:Equals(FormatMaskEnum:Custom) then
            undo, throw new AppError(
                        substitute('&1 uses a Custom format mask, which cannot be overridden',
                            this-object:GetClass():TypeName)).
        
        /* The built-in enums don't allow jiggery-pokery with the name and :Name properties. The Helper
           makes sure that we get the actual mask and not the enumerator's name */
        assign oEnum = FormatMaskEnum:GetEnum(pcFormatMask) no-error.
        if valid-object(oEnum) then
            assign pcFormatMask = FormatMaskHelper:GetMask(oEnum).
        
        return ConnectionParameters:GetConnectionString(this-object:Options, pcFormatMask).
    end method.
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @param FormatMaskEnum The format mask to use. Overrides the mask
                              specified by the property.
        @return character A useable string of connection parameters. */
    method public character GetConnectionString(input poFormatMask as FormatMaskEnum):
        Assert:NotNull(poFormatMask, 'Format mask').
        
        if this-object:FormatMask:Equals(FormatMaskEnum:Custom) then
            undo, throw new AppError(
                        substitute('&1 uses a Custom format mask, which cannot be overridden',
                            this-object:GetClass():TypeName)
                        , 0).
        
        return GetConnectionString(FormatMaskHelper:GetMask(poFormatMask)).
    end method.
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @param JsonObject Options in JSON format.
        @param character The format mask to use.
        
        @return character A useable string of connection parameters. */
    method static public character GetConnectionString(input poOptions as JsonObject,
                                                       input pcFormatMask as character):
        define variable cConnectionString as character no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cNames as character extent no-undo.
        
        /* Loop through top-level properties and set as values on mask.
           If there are nested JSON values, ignore and pass in as arguments. */
        cNames = poOptions:GetNames().
        iMax = extent(cNames).
        do iLoop = 1 to iMax:
            case poOptions:GetType(cNames[iLoop]):
                when JsonDataType:String then
                    cConnectionString = cConnectionString
                              + substitute(pcFormatMask,
                                           cNames[iLoop],
                                           poOptions:GetCharacter(cNames[iLoop])).
                otherwise
                    cConnectionString = cConnectionString
                              + substitute(pcFormatMask,
                                           cNames[iLoop],
                                           poOptions:GetJsonText(cNames[iLoop])).
            end case.
        end.
        
        return cConnectionString.
    end method.
    
end class./************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : FormatMaskEnum
    Purpose     : Contains simple, substitutable masks, capable of being used with the basic
                  OpenEdge.Core.ServerConnection.ConnectionParameters class
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Feb 28 15:25:46 EST 2013
    Notes       : More specialised masks, that will require specialised IConnectionParameters 
                  implementations. And example of this is the OpenEdge.Core.ServerConnection.WebServiceConnectionParameters
                  class.
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

enum OpenEdge.Core.ServerConnection.FormatMaskEnum:
    define enum       None 
                      DashSpace
                      DoubleDashEquals
                      DoubleDashSpace
                      NameEquals
                      Custom
                      
                      ABLConnect = DashSpace
                      Default = ABLConnect. 
end enum.
/************************************************
Copyright (c)  2015 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : FormatMaskHelper
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Apr 09 14:57:20 EDT 2015
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.ServerConnection.FormatMaskHelper.
using OpenEdge.Core.ServerConnection.FormatMaskEnum.

class OpenEdge.Core.ServerConnection.FormatMaskHelper:
    
    /** Returns an actual format mask for an enumeration
        
        @param FormatMaskEnum The format mask type to return the mask for
        @return character The format mask */
    method static public character GetMask(input poFormatMask as FormatMaskEnum):
        Assert:NotNull(poFormatMask, 'Format mask').
        
        case poFormatMask:
            when FormatMaskEnum:None                then return ' &1 &2 ':u.
            when FormatMaskEnum:DashSpace           then return ' -&1 &2':u.
            when FormatMaskEnum:DoubleDashEquals    then return ' --&1=&2':u.
            when FormatMaskEnum:DoubleDashSpace     then return ' --&1 &2':u.
            when FormatMaskEnum:NameEquals          then return ' &1=&2':u.
            /* has no mask */
            when FormatMaskEnum:Custom then return ' ':u.
            /* NEVER ADD AN OTHERWISE so that we can make sure that this class always
               reflects all of the members of the FormatMaskEnum type */
        end case.
    end method.
    
end class./************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : IConnectionParameters
    Purpose     : General conneciton parameter object 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Feb 28 15:07:49 EST 2013
    Notes       : * This class based on the AutoEdge|TheFactory version
  ----------------------------------------------------------------------*/
using OpenEdge.Core.ServerConnection.FormatMaskEnum.

using Progress.Json.ObjectModel.JsonObject.

interface OpenEdge.Core.ServerConnection.IConnectionParameters:
    
    /** The FormatMask property contains a mask to be used together with
        the ABL SUBSTITUTE function. It can include up to 9 substitutions (&1-&9)
        and should also include any key/value pair separators (space, usually). */    
    define public property FormatMask as FormatMaskEnum no-undo get.
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @return character A useable string of connection parameters. */
    method public character GetConnectionString().
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @param character The format mask to use. Typically overrides the mask
                         specified by the property.
        @return character A useable string of connection parameters. */
    method public character GetConnectionString(input pcFormatMask as character).
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @param FormatMaskEnum The format mask to use. Overrides the mask
                              specified by the property.
        @return character A useable string of connection parameters. */
    method public character GetConnectionString(input poFormatMask as FormatMaskEnum).
            
end interface./************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : IServerConnection
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Feb 28 15:02:14 EST 2013
    Notes       : * This class based on the AutoEdge|TheFactory version
  ---------------------------------------------------------------------- */
using OpenEdge.Core.ServerConnection.IConnectionParameters.
using Progress.Lang.Object.

interface OpenEdge.Core.ServerConnection.IServerConnection:
    /** A reference to the actual server. The type of this property depends on the server type 
        (since AppServers have HANDLEs, BPMServers have IBizLogicAPI and databases none.The Object 
        acts as a wrapper for handle-based servers */
    define public property Server as Object no-undo get.

    /** Parameters for this connection */
    define public property ConnectionParameters as IConnectionParameters no-undo get.

    /**  Returns true if the server is valid and connected. False otherwise */
    define public property Connected as logical no-undo get.
    
    /** Creates a server object (ie this-object:Server). This is separated
        from the Connect/Disconnect pair of methods so that one server can 
        be connected and disconnected multiple time. */
    method public void CreateServer().

    /** Destroys the server object (ie this-object:Server). This is separated
        from the Connect/Disconnect pair of methods so that one server can 
        be connected and disconnected multiple time. */
    method public void DestroyServer().

    /** Connect to the server specified, based on the ConnectionParameters */
    method public void Connect().
    
    /** Disconnect from the server, if connected */    
    method public void Disconnect().
    
end interface./************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : UrlConnectionParameters
    Purpose     : Builds a URL from a set of (JSON) connection parameters
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Feb 28 15:07:49 EST 2013
    Notes       : * The Options property contains JSON data, which for a URL must have
                    the follopwing structure
                        {"protocol":"http|https|...",
                         "host":"localhost|192.168.0.1|...",
                         "port":80,
                         "user":"<username>",
                         "password":"<password>",
                         "path": "/app/path",
                         "query": [{"name":"query-param-name-1", "value":"query-param-value-1"}, ... , {"name":"query-param-name-N", "value":"query-param-value-N"} ] }
                    Alternatively, provide a complete URL
                        {"URL":"http://localhost/index.html"}
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.ServerConnection.ConnectionParameters.
using OpenEdge.Core.ServerConnection.FormatMaskEnum.
using Progress.Json.ObjectModel.JsonArray.
using Progress.Json.ObjectModel.JsonDataType.
using Progress.Json.ObjectModel.JsonObject.
using Progress.Lang.AppError.


class OpenEdge.Core.ServerConnection.UrlConnectionParameters inherits ConnectionParameters:
    constructor public UrlConnectionParameters(input poOptions as JsonObject):
        super(poOptions, FormatMaskEnum:Custom).
    end constructor.
    
    constructor public UrlConnectionParameters(input pcOptions as character):
        super(pcOptions, FormatMaskEnum:Custom).
    end constructor.
    
    method override protected void Initialise():
        this-object:ResolvedOptions = ?.
        super:Initialise().
    end method.
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @param character The format mask to use. This value is IGNORED for this class.
        @return character A useable string of connection parameters. */
    method override public character GetConnectionString():   
        /* Define variables for protocol and host, since we want to provide defaults for them.
           Just take what's provided for the other elements and use as-is. */
        define variable cProtocol as character no-undo initial 'http'.
        define variable cHost as character no-undo initial 'localhost'.
        define variable iPort as integer no-undo initial 80.
        define variable cUrl as character no-undo.
        define variable cPath as character no-undo initial 'index.html'.
        define variable cQuery as character no-undo.
        define variable cOptions as character no-undo.
        define variable oOptionsArray as JsonArray no-undo.
        define variable oSingleOption as JsonObject no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cNames as character extent no-undo.
        define variable cDelimiter as character no-undo.
        
        if this-object:ResolvedOptions eq ? then
        do:
            if this-object:Options:Has('URL') and
               this-object:Options:GetType('URL') eq JsonDataType:STRING then
            do:
                this-object:ResolvedOptions = this-object:Options:GetCharacter('URL').
                return this-object:ResolvedOptions.
            end.

            if this-object:Options:Has('protocol') then
                cProtocol = this-object:Options:GetCharacter('protocol').
            cURL = substitute('&1://', cProtocol).
            
            if this-object:Options:Has('user') then
            do: 
                cURL = cURL + this-object:Options:GetCharacter('user').            
                if this-object:Options:Has('password') then
                    cURL = cURL + substitute(':&1', this-object:Options:GetCharacter('password')). 
                cURL = cURL + '@'.
            end.

            if this-object:Options:Has('host') then
                cHost= this-object:Options:GetCharacter('host').
            cURL = cURL + cHost.
            
            if this-object:Options:Has('port') then
                iPort = this-object:Options:GetInteger('port').
            cURL = cURL + substitute(':&1', iPort).
    
            if this-object:Options:Has('path') then
                assign cPath = this-object:Options:GetCharacter('path')
                       /* we re-add the leading / when building the URL */
                       cPath = left-trim(cPath, '/').
            
            if this-object:Options:Has('query') then
            do:
                if this-object:Options:GetType('query') eq JsonDataType:STRING then
                    cQuery = this-object:Options:GetCharacter('query').
                else
                    oOptionsArray = this-object:Options:GetJsonArray('query').
                if valid-object(oOptionsArray) then
                do:
                    /* blank to remove defaults. Since there is an object here, assume that's the intent */
                    cDelimiter = '?'.
                    iMax = oOptionsArray:Length.
                    do iLoop = 1 to iMax:
                        oSingleOption = oOptionsArray:GetJsonObject(iLoop).
                        cQuery = cQuery + substitute('&1&2', cDelimiter, oSingleOption:GetCharacter('name')).
                        cDelimiter = '&'. 
                        if oSingleOption:Has('value') then
                            cQuery = cQuery + substitute('=&1',oSingleOption:GetCharacter('value')).
                    end.
                end.
            end.
            
            /* if there's no query string, then cQUery will be blank. */
            this-object:ResolvedOptions = substitute('&1/&2&3', cURL, cPath, cQuery). 
        end.
        
        return this-object:ResolvedOptions.
    end method.
    
end class./************************************************
Copyright (c) 2013, 2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : WebServiceConnection
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Feb 28 16:24:59 EST 2013
    Notes       : 
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.ServerConnection.IServerConnection.
using OpenEdge.Core.ServerConnection.IConnectionParameters.
using OpenEdge.Core.ServerConnection.WebServiceConnectionParameters.

using OpenEdge.Core.Assert.
using OpenEdge.Core.WidgetHandle.

using Progress.Lang.Object.

class OpenEdge.Core.ServerConnection.WebServiceConnection use-widget-pool 
        implements IServerConnection: 
    /** A reference to the actual server. The type of this property depends on the server type 
        (since AppServers have HANDLEs, BPMServers have IBizLogicAPI and databases none. The Object 
        acts as a wrapper for handle-based servers */
    define public property Server as Object no-undo get. private set.

    /** Parameters for this connection */
    define public property ConnectionParameters as IConnectionParameters no-undo get. private set.

    /**  Returns true if the server is valid and connected. False otherwise */
    define public property Connected as logical no-undo
        get():
            define variable lConnected as logical no-undo.
            define variable hServer as handle no-undo.
            
            lConnected = valid-object(this-object:Server).
            if lConnected then
                assign hServer = cast(Server, WidgetHandle):Value
                       lConnected = valid-handle(hServer).
            if lConnected then
                lConnected = hServer:connected().
            
            return lConnected.
        end get.
    
    define public property ServiceName as character no-undo 
        get():
            if this-object:ServiceName eq '' then
                this-object:ServiceName = cast(ConnectionParameters, WebServiceConnectionParameters):ServiceName.
            return this-object:ServiceName.                 
        end get. 
        private set.

    define public property PortName as character no-undo 
        get():
            if this-object:PortName eq '' then
                this-object:PortName = cast(ConnectionParameters, WebServiceConnectionParameters):PortName.
            return this-object:PortName.                 
        end get. 
        private set.
    
    define public property Operation as character no-undo
        get():
            if this-object:Operation eq '':u then
                this-object:Operation = cast(ConnectionParameters, WebServiceConnectionParameters):Operation.
            return this-object:Operation.                 
        end get. 
        private set.
        
    constructor public WebServiceConnection(input poConnectionParameters as WebServiceConnectionParameters):
        Assert:NotNull(poConnectionParameters, 'Connection Parameters').  
        ConnectionParameters = poConnectionParameters.
    end constructor.
    
    destructor WebServiceConnection():
        this-object:DestroyServer().
    end destructor.
    
    /** Connect to the server specified, based on the ConnectionParameters */
    method public void Connect():
        define variable hServer as handle no-undo.

        if not valid-object(this-object:Server) then
            CreateServer().
        
        hServer = cast(this-object:Server, WidgetHandle):Value.
        
        hServer:connect(this-object:ConnectionParameters:GetConnectionString()).
    end method.
    
    /** Disconnect from the server, if connected */    
    method public void Disconnect():
        if this-object:Connected then
            cast(Server, WidgetHandle):Value:disconnect().
    end method.

    /** Creates a server object (ie this-object:Server). This is separated
        from the Connect/Disconnect pair of methods so that one server can 
        be connected and disconnected multiple time. */
    method public void CreateServer():
        define variable hServer as handle no-undo.
        
        create server hServer.
        assign this-object:Server = new WidgetHandle(hServer, true /*autodestroy*/ ).
    end method.

    /** Destroys the server object (ie this-object:Server). This is separated
        from the Connect/Disconnect pair of methods so that one server can 
        be connected and disconnected multiple time. */
    method public void DestroyServer():
        define variable hServer as handle no-undo.
        
        if this-object:Connected then
            this-object:Disconnect().

        if not valid-object(this-object:Server) then
            return.
        assign this-object:Server = ?.
    end method.    
    
end class./************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : WebServiceConnectionParameters
    Purpose     : Specialised connection parameters for connecting to a WebService connection
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Thu Feb 28 15:07:49 EST 2013
    Notes       : * The Options property contains JSON data, which for a URL must have
                    the following structure
                    {"ServiceName": "",
                     "PortName":"",
                     "Operation":"",
                     "URL": Parameters as per OpenEdge.Core.ServerConnection.UrlConnectionParameters
                            OR a simple string like "http://localhost:8980/axis/services/Corticon?wsdl" 
                     "Options": [{"WSDLUserId": "user-id"},{"WSDLPassword":"password"}]}
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.ServerConnection.UrlConnectionParameters.
using OpenEdge.Core.ServerConnection.ConnectionParameters.
using OpenEdge.Core.ServerConnection.FormatMaskEnum.

using OpenEdge.Core.Assert.

using Progress.Json.ObjectModel.JsonObject.
using Progress.Json.ObjectModel.JsonDataType.
using Progress.Json.ObjectModel.JsonArray.
using Progress.Lang.AppError.

class OpenEdge.Core.ServerConnection.WebServiceConnectionParameters inherits ConnectionParameters:     
    /** The name of the WebService */
    define public property ServiceName as character no-undo get. protected set.
    /** The name of the (default) Port  */
    define public property PortName as character no-undo get. protected set.
    /** The name of the (default) Operation */
    define public property Operation as character no-undo get. protected set.
    
    constructor public WebServiceConnectionParameters(input poOptions as JsonObject):
        super(poOptions, FormatMaskEnum:Custom).
    end constructor.
    
    constructor public WebServiceConnectionParameters(input pcOptions as character):
        super(pcOptions, FormatMaskEnum:Custom).
    end constructor.
    
    method override protected void Initialise():
        this-object:ResolvedOptions = ?.
        
        super:Initialise().
        
        if this-object:Options:Has('ServiceName') then
             this-object:ServiceName = this-object:Options:GetCharacter('ServiceName').
             
        Assert:NotNullOrEmpty(this-object:ServiceName, 'Service Name').             

        if this-object:Options:Has('PortName') then
             this-object:PortName = this-object:Options:GetCharacter('PortName').

        if this-object:Options:Has('Operation') then
             this-object:Operation = this-object:Options:GetCharacter('Operation').
    end method.
    
    /** Returns the Options as a formatted string for use by the server to connect. 
        This may be the the ABL CONNECT statement or some other parameter.  
                        
        @return character A useable string of connection parameters. */
    method override public character GetConnectionString():
        define variable cConnectionString as character no-undo.
        define variable cUrl as character no-undo.
        define variable cOptions as character no-undo.
        define variable oOptionsArray as JsonArray no-undo.
        define variable oSingleOption as JsonObject no-undo.
        define variable oURLOptions as JsonObject no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable oUrlCP as UrlConnectionParameters no-undo.
        
        if this-object:ResolvedOptions eq ? then
        do:
            /* SERVICE */
            cConnectionString = substitute('-Service &1', this-object:ServiceName).
            
            /* WSDL */
            /* Build the URL */
            if not this-object:Options:Has('URL') then
                return error new AppError('No URL option specified', 0).
            
            if this-object:Options:GetType('URL') eq JsonDataType:STRING then
                cUrl = this-object:Options:GetCharacter('URL').
            else
            do:
                oURLOptions = this-object:Options:GetJsonObject('URL').
                assign oUrlCP = new UrlConnectionParameters(oURLOptions)
                       cUrl = oUrlCP:GetConnectionString().
            end.
            
            cOptions = ''.
            if this-object:Options:Has('Options') then
            do:
                oOptionsArray = this-object:Options:GetJsonArray('Options').
                /* blank to remove defaults. Since there is an object here, assume that's the intent */
                iMax = oOptionsArray:Length.
                do iLoop = 1 to iMax:
                    oSingleOption = oOptionsArray:GetJsonObject(iLoop).
                    cOptions  = cOptions 
                              + ConnectionParameters:GetConnectionString(
                                        oOptionsArray:GetJsonObject(iLoop),
                                        FormatMaskEnum:DashSpace:ToString()).
                end.
            end.
            this-object:ResolvedOptions = cConnectionString + substitute(' -WSDL &1 ', cUrl) + cOptions.
        end.
        
        return this-object:ResolvedOptions.
    end method.
    
end class./************************************************
Copyright (c) 2013, 2015, 2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : OpenEdge.Core.System.ApplicationError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Mon Mar 09 10:37:02 EDT 2009
    Notes       : * Based on the AutoEdge|TheFactory version
  ----------------------------------------------------------------------*/
block-level on error undo, throw.


using OpenEdge.Core.System.ApplicationError.
using OpenEdge.Core.System.ErrorSeverityEnum.

using OpenEdge.Core.DataTypeEnum.
using OpenEdge.Core.IOModeEnum.
using OpenEdge.Core.Assert.

using Progress.Lang.ParameterList.
using Progress.Lang.AppError.
using Progress.Lang.Error.
using Progress.Lang.Object.
using Progress.Lang.Class.
using OpenEdge.Core.DataTypeHelper.

class OpenEdge.Core.System.ApplicationError abstract serializable inherits AppError:
    /* Registry of error strings. These can be added via */
    define static private temp-table ApplicationErrorText no-undo
        field ErrorType as character
        field ShortMessage as character
        field ErrorMessage as clob
        index idx1 as primary unique ErrorType. 
    
    define public property InnerError as Error no-undo get. private set.
    
    constructor static ApplicationError():
        ApplicationError:AddError(
            get-class(ApplicationError), 
            'Application Error',
            'Default Application Error: &1 &2 &3 &4 &5 &6 &7 &8 &9').
    end constructor.
    
    /** Registers an error's texts. Works on last-in-wins basis,
        so if an error text is registered multiple times, the last 
        one wins. 
        
        @param Progress.Lang.Class The application error type
        @param character The short message
        @param lonchar The complete, long error description */
    method protected static void AddError(input poType as Progress.Lang.Class,
                                          input pcShortMessage as character,
                                          input pcMessage as longchar):
        define buffer ApplicationErrorText for ApplicationErrorText.
         
        if can-find(ApplicationErrorText where ApplicationErrorText.ErrorType eq poType:TypeName) then
            find ApplicationErrorText where ApplicationErrorText.ErrorType eq poType:TypeName.
        if not available ApplicationErrorText then
        do:
            create ApplicationErrorText.
            assign ApplicationErrorText.ErrorType = poType:TypeName.
        end.
        
        assign ApplicationErrorText.ShortMessage = pcShortMessage
               ApplicationErrorText.ErrorMessage = pcMessage.                                            
    end method.
    
    constructor public ApplicationError():
        this-object(?).
    end constructor.
    
    constructor public ApplicationError(input poInnerError as Error):
        /* Severity can/will be overwritten by individual Error */
        assign this-object:Severity = integer(ErrorSeverityEnum:Default)
               /* may be null */
               this-object:InnerError = poInnerError.
    end constructor.
    
    method public override Object Clone():
        define variable oParams as ParameterList no-undo.
        define variable oClone as ApplicationError no-undo.
        define variable oClass as Progress.Lang.Class no-undo. 
        define variable iLoop  as integer no-undo.
        
        oClass = this-object:GetClass().
        oParams = new ParameterList(1).
        oParams:SetParameter(1,
                             substitute(DataTypeHelper:GetMask(DataTypeEnum:Class), 'Progress.Lang.Error':u),
                             IOModeEnum:Input:ToString(),
                             this-object:InnerError).
        oClone = cast(oClass:New(oParams), ApplicationError).
        do iLoop = 1 to NumMessages:
            oClone:AddMessage(GetMessage(iLoop), iLoop).
        end.
        
        oClone:Severity = this-object:Severity.
        oClone:ReturnValue = this-object:ReturnValue.
        
        return oClone.
    end method.
 
    /** Returns the resolved/substituted short message for the error. Note
        that this excludes the inner error, if any.
        
        @return character A resolve string version of the short message. */
    method public character GetShortMessage():
        define buffer ApplicationErrorText for ApplicationErrorText.
        
        if can-find(ApplicationErrorText where ApplicationErrorText.ErrorType eq this-object:GetClass():TypeName) then
            find ApplicationErrorText where ApplicationErrorText.ErrorType = this-object:GetClass():TypeName.
        
        if not available ApplicationErrorText 
           and can-find(ApplicationErrorText where ApplicationErrorText.ErrorType eq get-class(ApplicationError):TypeName)
        then
            find ApplicationErrorText where ApplicationErrorText.ErrorType eq get-class(ApplicationError):TypeName.
        
        return substitute(ApplicationErrorText.ShortMessage,
                               GetMessage(1),
                               GetMessage(2),
                               GetMessage(3),
                               GetMessage(4),
                               GetMessage(5),
                               GetMessage(6),
                               GetMessage(7),
                               GetMessage(8),
                               GetMessage(9)).
    end method.
    
    /** Returns the resolved/substituted message text for the error. Note
        that this excludes the inner error, if any.
        
        @return longchar A resolved version of the error message. */
    method public longchar GetErrorMessage():
        define variable cMessage as longchar no-undo.
        define buffer ApplicationErrorText for ApplicationErrorText.
        
        if can-find(ApplicationErrorText where 
                    ApplicationErrorText.ErrorType eq this-object:GetClass():TypeName) then
        find ApplicationErrorText where ApplicationErrorText.ErrorType = this-object:GetClass():TypeName.
        
        if not available ApplicationErrorText 
           and can-find(ApplicationErrorText where ApplicationErrorText.ErrorType eq get-class(ApplicationError):TypeName)
        then
            find ApplicationErrorText where ApplicationErrorText.ErrorType = get-class(ApplicationError):TypeName.
        
        assign cMessage = ApplicationErrorText.ErrorMessage.
        return substitute(cMessage,
                               GetMessage(1),
                               GetMessage(2),
                               GetMessage(3),
                               GetMessage(4),
                               GetMessage(5),
                               GetMessage(6),
                               GetMessage(7),
                               GetMessage(8),
                               GetMessage(9)).
    end method.

    method override public character ToString(  ):
        return GetShortMessage().
    end method.
        
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ArgumentError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Apr 13 12:43:45 EDT 2010
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.System.ArgumentError.
using OpenEdge.Core.System.ApplicationError.
using Progress.Lang.Error.

class OpenEdge.Core.System.ArgumentError inherits ApplicationError: 

    constructor static ArgumentError ():
        ApplicationError:AddError(
            get-class(ArgumentError),
            /* short message */
            'Argument Error',
            /* message */
            '&1 (name &2)').       
    end constructor.
    
    constructor public ArgumentError(pcArgs1 as char, pcArgs2 as char):
        this-object(?, pcArgs1, pcArgs2).
    end constructor.
    
    constructor public ArgumentError(poInnerError as Error, pcArgs1 as char, pcArgs2 as char):
        super(poInnerError).
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.

end class.
/************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : ErrorSeverityEnum
    Purpose     : Enumeration of error severities 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Fri Jun 26 14:23:12 EDT 2009
    Notes       : * Based on the AutoEdge|TheFactory version 
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

enum OpenEdge.Core.System.ErrorSeverityEnum flags:
    define enum       Default
                      None     
                      Fatal    
                      Critical 
                      Error    
                      Warning  
                      Message  
                      Info     
                      Debug.    
end enum.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : InvalidCallError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Apr 13 12:38:37 EDT 2010
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.System.InvalidCallError.
using OpenEdge.Core.System.ApplicationError.

class OpenEdge.Core.System.InvalidCallError inherits ApplicationError:
    
    constructor static InvalidCallError():
        ApplicationError:AddError(
            get-class(InvalidCallError),
            /* short message */
            'Invalid Call Error',
            /* message */
            'Invalid &1 call: &2').       
    end constructor.
    
    constructor public InvalidCallError(pcArgs1 as char, pcArgs2 as char):
        super().
        
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.
    
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : InvalidValueSpecifiedError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Wed Jul 08 10:06:54 EDT 2009
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.System.ApplicationError.
using OpenEdge.Core.System.InvalidValueSpecifiedError.
using Progress.Lang.Error.

class OpenEdge.Core.System.InvalidValueSpecifiedError inherits ApplicationError: 
    
    constructor static InvalidValueSpecifiedError():
        ApplicationError:AddError(
            get-class(InvalidValueSpecifiedError),
            /* short message */
            'Invalid Value Specified Error',
            'Invalid &1 specified &2').
    end constructor.
    
    constructor protected InvalidValueSpecifiedError ():
        define variable oNullError as Error no-undo.
        super(oNullError).
    end constructor.
    
    constructor public InvalidValueSpecifiedError (pcArgs1 as char, pcArgs2 as char):
        super().
        
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.
    
    constructor public InvalidValueSpecifiedError (e as Error, pcArgs1 as char, pcArgs2 as char):
        super(e).
        
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.
    
    constructor public InvalidValueSpecifiedError (pcArgs1 as char):
        this-object().
        AddMessage(pcArgs1, 1).
    end constructor.
    
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : InvocationError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Mon Apr 12 15:06:24 EDT 2010
    Notes       : 
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.System.InvocationError. 
using OpenEdge.Core.System.ApplicationError.
using Progress.Lang.Error.

class OpenEdge.Core.System.InvocationError inherits ApplicationError: 
    constructor static InvocationError():
        ApplicationError:AddError(
            get-class(InvocationError),
            /* short message */
            'Invocation Error',
            /* message */
            'Cannot invoke &1 on class &2').       
    end constructor.
    
    constructor public InvocationError(poErr as Error,
                                       pcArgs1 as char,
                                       pcArgs2 as char):
        super(poErr).
        
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.

    constructor public InvocationError(pcArgs1 as char,
                                       pcArgs2 as char):
        super().
        
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.
    
    constructor public InvocationError():
        define variable oUnknown as Error no-undo.
        super(oUnknown).
    end constructor.
    
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : NotFoundError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Mon Feb 22 12:56:33 EST 2010
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.System.NotFoundError.
using OpenEdge.Core.System.ApplicationError.
using Progress.Lang.Error.

class OpenEdge.Core.System.NotFoundError inherits ApplicationError: 
    constructor static NotFoundError():
        ApplicationError:AddError(
            get-class(NotFoundError),
            /* short message */
            'Not Found Error',
            /* message */
            '&1 not found in &2').       
    end constructor.
        
    constructor public NotFoundError(poErr as Error, pcArgs1 as char, pcArgs2 as char):
        super(poErr).
        
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.
    
    constructor public NotFoundError(pcArgs1 as char, pcArgs2 as char):
        define variable oUnknown as Error no-undo.
        
        this-object(oUnknown,pcArgs1, pcArgs2).
    end constructor.
        
end class.
/************************************************
Copyright (c)  2013 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : UnsupportedOperationError
    Purpose     : 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Wed Sep 02 13:46:49 EDT 2009
    Notes       : 
  ---------------------------------------------------------------------- */
routine-level on error undo, throw.

using OpenEdge.Core.System.ApplicationError.
using OpenEdge.Core.System.ErrorSeverityEnum.
using OpenEdge.Core.System.UnsupportedOperationError.
using Progress.Lang.Error.

class OpenEdge.Core.System.UnsupportedOperationError inherits ApplicationError: 
    constructor static UnsupportedOperationError():
        ApplicationError:AddError(
            get-class(UnsupportedOperationError),
            /* short message */
            'Unsupported Operation Error',
            /* message */
            '&1 is not supported for &2').       
    end constructor.
    
    constructor public UnsupportedOperationError (pcArgs1 as char, pcArgs2 as char):
        this-object(?,pcArgs1,pcArgs2).       
    end constructor.

    constructor public UnsupportedOperationError (poErr as Error, pcArgs1 as char, pcArgs2 as char):
        super(poErr).
        AddMessage(pcArgs1, 1).
        AddMessage(pcArgs2, 2).
    end constructor.
    
end class.
/************************************************
Copyright (c) 2016-2018 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : BuilderRegistry
    Purpose     : General registry for name/Progress.Lang.Class pairs used
                  by the various builders. 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Feb 12 11:39:54 EST 2015
    Notes       : * this is technically a typed Map, but will be kept separate
  ----------------------------------------------------------------------*/
block-level on error undo, throw.
 
using OpenEdge.Core.Assert.
using Progress.Lang.Object.
using OpenEdge.Core.Util.BuilderRegistry.

class OpenEdge.Core.Util.BuilderRegistry:
    /* Returns the number of mappings in this map.*/
    define public property Size as integer no-undo get. private set.
    
    /** (optional) The type of the registered Type (defaults to PLO) */
    define public property ValueType as Progress.Lang.Class no-undo get. private set.
    
    define static private temp-table Registry no-undo
        field ParentRegistry as integer
        field TypeKey as character 
        field Type as Object
        index idx1 as primary unique ParentRegistry TypeKey.
        
    /** Default constructor */
    constructor public BuilderRegistry():
        this-object(get-class(Progress.Lang.Object)).
    end constructor.
    
    /** Constructor 
    
        Creates clone of the input registry into the current one.
        
        @param BuilderRegistry THe source registry     */
    constructor public BuilderRegistry(input poRegistry as BuilderRegistry):
        Assert:NotNull(poRegistry, 'Source registry').
        assign this-object:ValueType = poRegistry:ValueType.
        
        PutAll(poRegistry).        
    end constructor.
    
    /** Constructor
    
        @param Progress.Lang.Class The type that the registered value must conform to
                                   (via IsA() ). */
    constructor public BuilderRegistry(input poValueType as Progress.Lang.Class):
        Assert:NotNull(poValueType, 'Value type').
        assign this-object:ValueType = poValueType.
    end constructor.
    
    destructor BuilderRegistry():
        this-object:Clear().
    end destructor.
    
    /* Adds the contents of one registry to another. THis is an overwite 
       operation (ie existing maps are overwritten; new ones added)
       
       Call Clear() to delete nefore additions.
       
       @param BuilderRegistry THe source of entries to add */
    method public void PutAll(input poRegistry as BuilderRegistry):
        define buffer lbSourceRegistry for Registry.
        
        Assert:NotNull(poRegistry, 'Source registry').
        Assert:IsType(poRegistry:ValueType, this-object:ValueType).
        
        /* We use the 'internals' TT for speed/simplicity */
        for each lbSourceRegistry where
                 lbSourceRegistry.ParentRegistry eq int64(poRegistry):
            this-object:Put(lbSourceRegistry.TypeKey,
                            cast(lbSourceRegistry.Type, Progress.Lang.Class)).
        end.
    end method.
    
    /** Registers type for a key 
    
        @param character The key of the type to register
        @param Class The type of the writer used to process that type
        @return logical True if the type was previously registered */
    method public logical Put(input pcTypeKey as character,
                              input poType as class Progress.Lang.Class):
        define variable lExists as logical no-undo.
        define buffer lbRegistry for Registry.
        
        Assert:NotNull(pcTypeKey, 'Type key').
        Assert:IsType(poType, this-object:ValueType).
                
        assign lExists = can-find(lbRegistry where
                                  lbRegistry.ParentRegistry eq int64(this-object) and
                                  lbRegistry.TypeKey        eq pcTypeKey).
        
        if lExists then
            find lbRegistry where
                 lbRegistry.ParentRegistry eq int64(this-object) and
                 lbRegistry.TypeKey        eq pcTypeKey.
        else
        do:
            create lbRegistry.
            assign lbRegistry.ParentRegistry = int64(this-object)
                   lbRegistry.TypeKey        = pcTypeKey
                   this-object:Size          = this-object:Size + 1.
        end.
        assign lbRegistry.Type = poType.
        
        return lExists.                                       
    end method.
    
    /** Deregisters a content type writer 
    
        @param character The name of the content type to register
        @return logical True if the content type was previously registered */
    method public logical Remove(input pcTypeKey as character):
        define variable lExists as logical no-undo.
        define buffer lbRegistry for Registry.
        
        Assert:NotNull(pcTypeKey, 'Type key').
        
        assign lExists = can-find(lbRegistry where
                                  lbRegistry.ParentRegistry eq int64(this-object) and
                                  lbRegistry.TypeKey        eq pcTypeKey).
        
        if lExists then
        do:
            find lbRegistry where
                 lbRegistry.ParentRegistry eq int64(this-object) and
                 lbRegistry.TypeKey        eq pcTypeKey
                 .
            delete lbRegistry.
            assign this-object:Size = this-object:Size - 1.
        end.
        return lExists.                                       
    end method.    

    /** Indicates whether a content type is registered or not. 
        
        @param character The name of the content type to register
        @return logical True if the content type is registered */
    method public logical Has(input pcTypeKey as character):
        define buffer lbRegistry for Registry.
        
        Assert:NotNull(pcTypeKey, 'Type key').

        return can-find(lbRegistry where
                        lbRegistry.ParentRegistry eq int64(this-object) and
                        lbRegistry.TypeKey        eq pcTypeKey).
    end method.
    
    /** Returns a registered type, if it exists. returns null otherwise.
        
        @param character The name of the content type to register
        @return Progress.Lang.Class A valid value if it exists. Null otherwise .*/
    method public class Progress.Lang.Class Get(input pcTypeKey as character):
        define buffer lbRegistry for Registry.
        
        Assert:NotNull(pcTypeKey, 'Type key').
        
        if can-find(lbRegistry where
                    lbRegistry.ParentRegistry eq int64(this-object) and
                    lbRegistry.TypeKey        eq pcTypeKey) then
        do:                    
            find lbRegistry where
                 lbRegistry.ParentRegistry eq int64(this-object) and
                 lbRegistry.TypeKey eq pcTypeKey
                 .
                return cast(lbRegistry.Type, Progress.Lang.Class).
        end.
        
        return ?.
    end method.
    
    /** Clears all the entries from this registry */
    method public void Clear():
        define buffer lbRegistry for Registry.
        for each lbRegistry where
                 lbRegistry.ParentRegistry eq int64(this-object):
            delete lbRegistry.
        end.
        assign this-object:Size = 0.
    end method.
    
    /** Returns an array of the key names in this registry.
        
        @return character[] The key values. Indeterminate array if empty. */
    method public character extent GetKeys():
        define variable cKeys as character extent no-undo.
        define buffer lbRegistry for Registry.
        define query qryRegistry for lbRegistry.
        
        open query qryRegistry 
            preselect each lbRegistry where
                           lbRegistry.ParentRegistry eq int64(this-object).
        
        extent(cKeys) = query qryRegistry:num-results.
        
        get first qryRegistry.
        do while not query qryRegistry:query-off-end:
            assign cKeys[query qryRegistry:current-result-row] = lbRegistry.TypeKey.
            get next qryRegistry.
        end. 
        
        return cKeys.
        finally:
            close query qryRegistry.
        end finally.
    end method.
    
end class./************************************************
Copyright (c)  2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ConfigBuilder
    Purpose     : helper class for configuration data used by builders 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Mar 19 14:55:32 EDT 2015
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using Progress.Json.ObjectModel.JsonArray.
using Progress.Lang.Object.

class OpenEdge.Core.Util.ConfigBuilder use-widget-pool abstract: 
    /* single static tt for perf */
    define static protected temp-table ConfigOption no-undo
        field ParentBuilder as integer
        field ConfigName as character
        field ValueType as character        /* object|string|numeric|logical */
        field ObjectValue as Progress.Lang.Object
        field StringValue as character
        field NumericValue as decimal
        field LogicalValue as logical
        field DateTimeValue as datetime-tz
        index idx1 as primary unique ParentBuilder ConfigName .

    destructor ConfigBuilder():
        ClearOptions().
    end destructor.
    
    /** Clears all options for this builder */
    method protected void ClearOptions():
        define buffer ConfigOption for ConfigOption.
        
        for each ConfigOption where
                 ConfigOption.ParentBuilder eq integer(this-object):
            delete ConfigOption.
        end.
    end method.
    
    /** Stores an numeric value as an option
        
        @param character The option name
        @param Object the value     
        @return logical True is the option was overwritten */
    method protected logical SetOption(input pcName as character,
                                       input pdValue as decimal):
        define buffer ConfigOption for ConfigOption.
         
        define variable lExists as logical no-undo.
        
        Assert:NotNullOrEmpty(pcName, 'Config name').
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName
             no-error.
        assign lExists = available ConfigOption.
        if not lExists then
        do:
            create ConfigOption.
            assign ConfigOption.ParentBuilder = integer(this-object)
                   ConfigOption.ConfigName = pcName
                   ConfigOption.ValueType = 'number':u.
        end.
        
        Assert:Equals(ConfigOption.ValueType, 'number':u).
        assign ConfigOption.NumericValue = pdValue.
        
        return lExists.
    end method.
    
    /** Returns an option's object value
    
        @param character The option name
        @return Object the value    */
    method protected Object GetOptionObjectValue(input pcName as character):
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').
        
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName
             no-error.
        if available ConfigOption then
        do:
            Assert:Equals(ConfigOption.ValueType, 'object':u).
            return ConfigOption.ObjectValue. 
        end.
        
        return ?.
    end method.
    
    /** Returns an option's decimal value
    
        @param character The option name
        @return decimal the value    */
    method protected decimal GetOptionNumericValue(input pcName as character):
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').
        
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        if available ConfigOption then
        do:
            Assert:Equals(ConfigOption.ValueType, 'number':u).
            return ConfigOption.NumericValue.
        end.
        
        return ?.
    end method.
    
    /** Returns an option's character array value 
    
        @param character The option name
        @return character[] the value    */
    method protected character extent GetOptionStringArrayValue(input pcName as character):
        define variable cValue as character extent no-undo.
        define variable oArray as JsonArray no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').

        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        if available ConfigOption then
        do:
            Assert:Equals(ConfigOption.ValueType, 'object':u).
            Assert:IsType(ConfigOption.ObjectValue, get-class(JsonArray)).
            
            assign oArray = cast(ConfigOption.ObjectValue, JsonArray).
            if valid-object(oArray) then
                assign iMax = oArray:Length
                       extent(cValue) = iMax.
            do iLoop = 1 to iMax:
                assign cValue[iLoop] = oArray:GetCharacter(iloop).
            end.
        end.
        
        return cValue.
    end method.

    /** Returns an option's character value
    
        @param character The option name
        @return character the value    */
    method protected character GetOptionStringValue(input pcName as character):
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').

        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        if available ConfigOption then
        do:
            Assert:Equals(ConfigOption.ValueType, 'string':u).
            return ConfigOption.StringValue.
        end.
        
        return ?.
    end method.

    /** Returns an option's longchar value
    
        @param character The option name
        @return longchar the value    */
    method protected longchar GetOptionLongcharValue(input pcName as character):

        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').

        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        if available ConfigOption then
        do:
            Assert:Equals(ConfigOption.ValueType, 'string':u).
            return ConfigOption.StringValue.
        end.
        
        return ?.
    end method.
    
    /** Returns an option's logical value
    
        @param character The option name
        @return logical the value    */
    method protected logical GetOptionLogicalValue(input pcName as character):
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').
        
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        if available ConfigOption then
        do:
            Assert:Equals(ConfigOption.ValueType, 'logical':u).
            return ConfigOption.LogicalValue.
        end.
        
        return ?.
    end method.
        
    /** Returns an option's datetime value
    
        @param character The option name
        @return datetime-tz the value    */
    method protected datetime-tz GetOptionDateTimeValue(input pcName as character):
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').
        
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        if available ConfigOption then
        do:
            Assert:Equals(ConfigOption.ValueType, 'datetime':u).
            return ConfigOption.DateTimeValue.
        end.
        
        return ?.
    end method.
            
    /** Checks whether a config option already exists 
        
        @param  character The option name
        @return logical True if the named configuration option exists */
    method protected logical HasOption(input pcConfigName as character):
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcConfigName, 'Config name').

        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcConfigName 
             no-error.
        return available ConfigOption.
    end method.
    
    /** Removes an option
        
        @param character The option name */
    method protected logical RemoveOption(input pcName as character):
        define variable lExists as logical no-undo.
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').
        
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName eq pcName
             no-error.
        assign lExists = available ConfigOption.
        if lExists then
            delete ConfigOption.
                    
        return lExists.
    end method.
    
    /** Stores an object value as an option
        
        @param Progress.Lang>Class The option name (as a type)
        @param Object the value 
        @return logical True is the option was overwritten    */
    method protected logical SetOption(input pName as class Progress.Lang.Class,
                                       input pValue as Object):
        Assert:NotNull(pName, 'Config name').
        return SetOption(pName:TypeName, pValue).
    end method.
    
    /** Stores an object value as an option
        
        @param character The option name
        @param Object the value 
        @return logical True is the option was overwritten    */
    method protected logical SetOption(input pcName as character,
                                       input poValue as Object):
        define variable lExists as logical no-undo.
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').

        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        assign lExists = available ConfigOption.
        if not lExists then
        do:
            create ConfigOption.
            assign ConfigOption.ParentBuilder = integer(this-object)
                   ConfigOption.ConfigName = pcName
                   ConfigOption.ValueType = 'object':u.
        end.
        
        Assert:Equals(ConfigOption.ValueType, 'object':u).
        assign ConfigOption.ObjectValue = poValue.                                                        
    
        return lExists.
    end method.

    /** Stores a logical value as an option
        
        @param character The option name
        @param logical the value     
        @return logical True is the option was overwritten */
    method protected logical SetOption(input pcName as character,
                                       input plValue as logical):
        define variable lExists as logical no-undo.
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        assign lExists = available ConfigOption.
        if not lExists then
        do:
            create ConfigOption.
            assign ConfigOption.ParentBuilder = integer(this-object)
                   ConfigOption.ConfigName = pcName
                   ConfigOption.ValueType = 'logical':u.
        end.
        
        Assert:Equals(ConfigOption.ValueType, 'logical':u).
        assign ConfigOption.LogicalValue = plValue. 

        return lExists.                                                      
    end method.

    /** Stores a datetime-tzvalue as an option
        
        @param character The option name
        @param datetime-tz the value    
        @return logical True is the option was overwritten */
    method protected logical SetOption(input pcName as character,
                                       input ptValue as datetime-tz):
        define variable lExists as logical no-undo.
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        assign lExists = available ConfigOption.
        if not lExists then
        do:
            create ConfigOption.
            assign ConfigOption.ParentBuilder = integer(this-object)
                   ConfigOption.ConfigName = pcName
                   ConfigOption.ValueType = 'datetime':u.
        end.
        
        Assert:Equals(ConfigOption.ValueType, 'datetime':u).
        assign ConfigOption.DateTimeValue = ptValue.
        
        return lExists.
    end method.
    
    /** Stores an value as an option
        
        @param character The option name
        @param character the value     
        @return logical True is the option was overwritten */
    method protected logical SetOption(input pcName as character,
                                       input pcValue as character):
        define variable lExists as logical no-undo.
        define buffer ConfigOption for ConfigOption.
         
        Assert:NotNullOrEmpty(pcName, 'Config name').
        
        find ConfigOption where
             ConfigOption.ParentBuilder eq integer(this-object) and
             ConfigOption.ConfigName    eq pcName 
             no-error.
        assign lExists = available ConfigOption.
        if not lExists then
        do:
            create ConfigOption.
            assign ConfigOption.ParentBuilder = integer(this-object)
                   ConfigOption.ConfigName = pcName
                   ConfigOption.ValueType = 'string':u.
        end.
        
        Assert:Equals(ConfigOption.ValueType, 'string':u).
        assign ConfigOption.StringValue = pcValue.
        
        return lExists.
    end method.

    /** Appends a character value to an array (convenience)
        
        @param character The option name
        @param character the value          */
    method protected logical AppendArrayCharacterValue(input pcName as character,
                                                       input pcValue as character):
        define variable oValue as JsonArray no-undo.
        define variable lExists as logical no-undo.
        
        Assert:NotNullOrEmpty(pcName, 'Config name').
        
        assign lExists = HasOption(pcName).
        
        if lExists then
            assign oValue = cast(GetOptionObjectValue(pcName), JsonArray).
        else
            assign oValue = new JsonArray().
        
        oValue:Add(pcValue).
        
        SetOption(pcName, oValue).
        
        return lExists.    
    end method.
        
end class./************************************************
Copyright (c) 2014, 2017 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : MathUtil
    Purpose     : General-purpose math functionality.
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu May 15 14:44:19 EDT 2014
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.String.
using OpenEdge.Core.Assert.
using OpenEdge.Core.Util.MathUtil.

class OpenEdge.Core.Util.MathUtil:
    /* Keep the default in a readonly property - it is 10 */
    define static private property DEFAULT_BASE as integer initial 10 no-undo get.
    
    /** Return a ceiling value (a always-round-up value).
            
        So,
            2.1 returns 3
            1.9 returns 2
            5.0 returns 5
    
        @param decimal  The value to adjust
        @return integer The ceiling value   */
    method static public integer Ceiling (input pdVal as decimal):
        if truncate(pdVal,0) eq pdVal then
            return integer(pdVal).
        else
            return integer(truncate(pdVal, 0) + 1).
    end method.

    /** Converts hex to integer values 
        
        @param character A hex value
        @return integer The integer representation of that hex value.   */
    method public static integer HexToInt(input pcHex as character):
        define variable iResult as integer no-undo.
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable cHex as character no-undo.
        define variable rHex as raw no-undo.
        
        assign cHex = trim(pcHex).
        
        if length( cHex ) modulo 2 eq 1 then
            assign cHex = "0":u + cHex.
        
        assign rHex = hex-decode( cHex )
               iMax = length( rHex, 'raw')
               .
        do iLoop = 1 to iMax.
          assign iResult = iResult * 256
                 iResult = iResult + get-byte(rHex, iLoop)
                 .
       end.
       return iResult.  
    end method.
    
    /** Converts an exponent (123e4) value into a decimal using a exponent
        base of 10.
        
        @param character The exponent value
        @param decimal The converted value  */
    method static public decimal ExponentialToDec(input pExpVal as character):
        return MathUtil:ExponentialToDec(pExpVal, DEFAULT_BASE).
    end method.
    
    /** Converts an exponent (123e4) value into a decimal.
        The format is
             nnn[.nnn]e[-]nnn
             <base>e<exponent>
        The <exponent> is raised as a power of the exponent-base.
        
        @param character The exponent value
        @param integer The exponent base. Must be a positive value (>0)
        @param decimal The converted value  */
    method static public decimal ExponentialToDec(input pExpVal as character,
                                                  input pBase as integer):
        define variable idx as integer no-undo.
        define variable decVal as decimal no-undo initial 0.00.
        define variable coefficient as decimal no-undo.
        define variable exponent as integer no-undo.
        
        if String:IsNullOrEmpty(pExpVal) then
            return decVal.
        Assert:IsPositive(pBase, 'Exponent base').
        
        assign idx = index(pExpVal, 'e':u).
        if idx eq 0 then
            assign decVal = decimal(pExpVal).
        else
            assign coefficient = decimal(substring(pExpVal, 1, idx - 1))
                   exponent    = integer(substring(pExpVal, idx + 1))
                   decVal      = coefficient * exp(pBase, exponent)
                   .
        return decVal.
    end method.
    
    /** Converts an integer to a padded hax values 
        
        @param integer An integer value
        @param integer The total length of the hex value. If the integer hex value is larger than this, 
                       use the larger and padd with leading zeros 
        @return character A hex value */
    method static public character IntToHex(input pValue as integer,
                                            input pPadding as integer):
        define variable hexVal as character no-undo.
        define variable rawInt as raw no-undo.
        define variable rawHex as character no-undo.
        define variable strLen as integer no-undo.
        
        if pValue eq 0 then
            return fill('0':u, pPadding).
        
        put-long(rawInt, 1) = pValue.
        
        assign rawHex = right-trim(hex-encode(rawInt), '0':u)
               strLen = max(pPadding, length(rawHex))
               hexVal = fill('0':u, strLen)
               .
        overlay(hexVal, strLen - length(rawHex) + 1) = rawHex.
        
        return hexVal.
    end method.
    
end class./* *************************************************************************************************************************
Copyright (c) 2018 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : TokenResolver
    Purpose     : Resolves certain known token names into useful values
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 16 13:02:52 EST 2016
    Notes       : * Token substitutions are allowed for file names
                    the token format is ${<token>}, where
                    token = group "." arg
                    groups = session | env | guid | t[ime] | web | ver[sion]
                             cp | req[uest] | name
                   
                    If a token cannot be resovled, or resolves to a value of
                    ? (unknown) then the token name is used.  
                  
                  * Group args for SESSION
                    - any readable attribute on the session handle may be used
                   
                  * Group args for ENV
                    - any env var available via OE-GETENV() may be used
                    
                  * Group args for VERSION
                    - Correlates to the SESSION:LOCAL-VERSION-INFO 
                    - MAJOR, MINOR, MAINT
                    
                  * Group args for GUID
                    - a default-format GUID is used
                  
                  * Group args for T (T= time).
                    - Values are taken from the time at which the file name is being built.
                    - The args are based on http://en.cppreference.com/w/c/chrono/strftime
                    TODAY: An ISO-DATE formated DATE value is used
                    NOW  : An ISO-DATE formated datetime-tz value is used
                    YYYY : The current year, incl century
                    YY   : The current year, sans century
                    BB   : The full month name (from the MONTH_LONG property)
                    B    : The shortened month name (from the MONTH_SHORT property)
                    MM   : The integer month value, with leading 0 if needed
                    M    : The integer month value with no leading 0
                    DD   : The integer day value, with leading 0 if needed
                    D    : The integer month value, with no leading 0 
                    HH   : The hour value, in 24-hour clock format (ie 18 for 6pm)
                    H    : The hour value, in 12-hour clock format (ie 6 for 6pm)
                    MMM  : The minute value, with leading 0
                    SS   : The second value, with leading 0
                    SSS  : The millisecond value, with leading 0
                    Z    : The timezone (based on the current session), with leading +/-
                    PP   : The AM/PM indicator, as AM or PM
                    P    : The AM/PM indicator, as A or P
                    AA   : The full day of the week, from the WEEKDAY_LONG property
                    A    : The short day of the week, from the WEEKDAY_SHORT property
                    W    : The integer day of the week
                    
                 * Group args for REQ (request).
                   Will return ? if we're not in a request (ie startup event procs). Values
                   are taken from the session:current-request-info
                   TPT      : The adapter type (transport) for this request
                   CCID     : The client context id
                   ID       : The current request id 
                   SESSION  : The current session id
                   THREAD   : (PASOE) the current thread id 
                 
                 * Group args for WEB
                    WEBAPP["." webapp-type]
                        webapp-type
                            NAME : the context/webapp name (default) 
                            PATH : the fully-qualified path of the webapp 
                            
                    SVC
                    any other cgi value
                    
                 * Group args for CP (client principal)
                   credential-arg "." db-name
                   credential-arg 
                       The current user will be used (from the request info or the security-policy)
                       UID    : The current user id
                       QUID   : The qualified user id (user@domain) 
                       DOMAIN : The domain name of the current user
                   db-name
                        An optional logical db name from which to extract the CP. If none is set, use the security-policy
                   
                 * Group args for NAME
                   tokenArg = format-expression "." logger-name
                   - logger-name : a named-hierarchy dotted-name
                                           
                   - named-hierarchy
                          something like OpenEdge.Net.DataObject.DataObjectHandler (a logger name) will become
                          O.N.D.DataObjectHandler       (default or .1K)
                          o.n.d.DataObjectHandler       (.1L) 
                          OE.N.DO.DataObjectHandler     (.1C) 
                          OE.N.DO.DOH                   (.0C) 
                          
                   - format-expression
                        keep-expr case-expr
                        keep-expr:
                            number of significant entries to keep (from right)
                            0   : All entries will be trimmed (ie zero kept) 
                            1   : Only the last/only will be keep whole (default)
                            2..n: The number of entries (from the right) to keep 
                        case-expr
                            U   : trimmed elements are upper-cased
                            L   : trimmed elements are lower-cased
                            K   : trimmed elements are left alone (default)
                            C   : trimmed elements are Camel-cased (caps only written) 
 ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Session.
using OpenEdge.Core.String.
using OpenEdge.Core.StringConstant.
using OpenEdge.Core.TimeStamp.
using OpenEdge.Core.Util.TokenResolver.
using OpenEdge.Core.Util.TokenResolverEventArgs.
using OpenEdge.Security.Principal.

class OpenEdge.Core.Util.TokenResolver:
    
    /* Event published after a token is resolved by this resolver. Allows a listener to override the value */
    define static public event TokenResolved signature void (input pSender as Progress.Lang.Object,
                                                             input pArgs as TokenResolverEventArgs). 
    
    // Long/full names of the month, for use with ${t.BB} tokens
    define static public property MONTH_LONG as character extent 12 no-undo
            initial ['January','February','March','April','May','June','July','August','September','October','November','December']
            get.
            set.
    // Short names of the month, for use with ${t.B} tokens
    define static public property MONTH_SHORT as character extent 12 no-undo
            initial ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
            get.
            set.
    
    // Long names of the week days, for use with ${t.AA} tokens
    define static public property WEEKDAY_LONG as character extent 7 no-undo
            initial ['Sunday','Monday','Tuesday','Wednesday','Thursday','Friday','Saturday']
            get.
            set.
    
    // Long names of the week days, for use with ${t.A} tokens
    define static public property WEEKDAY_SHORT as character extent 7 no-undo
            initial ['Sun','Mon','Tue','Wed','Thu','Fri','Sat']
            get.
            set.
    
    define static private variable mInstanceRoot as character no-undo.
    
    /* Resolves a NAME-based token arg, based on the type/logger name given
       
       @param character  The token argument for ${NAME.*} tokens
       @param character  The (type) name to resolve
       @return character The resolved string  */
    method static public character ResolveName(input pTokenArg  as character,
                                               input pName as character):
        define variable tokenValue as character no-undo.
        define variable numKeep as integer no-undo.
        define variable numChars as integer no-undo.
        define variable charLoop as integer no-undo.
        define variable numEntries as integer no-undo.
        define variable entryLoop as integer no-undo.
        define variable singleEntry as character no-undo.
        define variable sensitiveChar as character no-undo case-sensitive.
        define variable charAsc as integer no-undo.
        define variable delim as character no-undo.
        
        if pName eq ? then
            return ?.
        
        assign numEntries = num-entries (pName, '.':u)
               delim      = '':u
               tokenValue = '':u
               .
        
        if pTokenArg eq '':u then
            assign pTokenArg = '1K':u.
        
        assign numKeep = ?
               numKeep = integer(substring(pTokenArg, 1, 1)) 
               no-error.
        if numKeep eq ? then
            assign numKeep = 1.
        
        do entryLoop = 1 to numEntries:
            assign singleEntry = entry(entryLoop, pName, '.':u).
            
            if entryLoop gt numEntries - numKeep then
                assign tokenValue = tokenValue
                                  + delim
                                  + singleEntry.
            else
            case substring(pTokenArg, 2, 1):
                when 'U':u then     //Upper
                    assign tokenValue = tokenValue
                                      + delim
                                      + caps(substring(singleEntry, 1, 1)).
                
                when 'L':u then     //Lower
                    assign tokenValue = tokenValue
                                      + delim
                                      + lc(substring(singleEntry, 1, 1)).
                
                when 'C':u then     //camelCase
                do:                                
                    /* Loop through entire input string */
                    assign numChars   = length(singleEntry)
                           tokenValue = tokenValue
                                      + delim
                                      + substring(singleEntry, 1, 1)
                                      .
                    do charLoop = 2 to numChars:
                        assign sensitiveChar = substring(singleEntry, charLoop, 1).
                        if sensitiveChar eq caps(sensitiveChar) then
                            assign tokenValue = tokenValue + sensitiveChar.
                    end.
                end.    // CamelCase
                
                otherwise           // Keep
                    assign tokenValue = tokenValue
                                      + delim
                                      + substring(singleEntry, 1, 1).
            end case.
            assign delim = '.':u.
        end.                                                   

        return tokenValue.
    end method.

    /* Resolves a time-based token arg, based on the timestamp given
       
       @param character   The token argument for ${T.*} tokens
       @param datetime-tz The timestamp to use to resolve the token
       @return character  The resolved string */
    method static public character ResolveTime(input pTokenArg  as character,
                                               input pTimestamp as datetime-tz):
        return ResolveTime(pTokenArg,
                           MONTH_LONG, MONTH_SHORT,
                           WEEKDAY_LONG, WEEKDAY_SHORT,
                           pTimestamp).                                                   
    end method.
    
    /* Resolves a time-based token arg, based on the timestamp given
       
       @param character     The token argument for ${T.*} tokens
       @param character[12] The long-form month names (ie January)
       @param character[12] The short-form month names (ie Jan)
       @param character[7]  The long-form weekday names (ie Thursday)
       @param character[7]  The short-form weekday names (ie Thurs)
       @param datetime-tz   The timestamp to use to resolve the token
       @return character    The resolved string */
    method static public character ResolveTime(input pTokenArg  as character,
                                               input pMonthLong as character extent 12,
                                               input pMonthShort as character extent 12,
                                               input pWeekdayLong as character extent 7,
                                               input pWeekdayShort as character extent 7,
                                               input pTimestamp as datetime-tz ):
        define variable tokenValue as character no-undo.
        define variable formatString as character no-undo.
        define variable timeValue as integer no-undo.
        
        if pTimestamp eq ? then
            return ?.
        
        assign formatString = '99':u
               tokenValue   = ?.
        
        if length(pTokenArg) eq 1 then
            assign formatString = '>9':u.
        
        case pTokenArg:
            // predefined 
            when 'now':u then
                assign tokenValue = iso-date(pTimestamp).
            
            when 'today':u then
                assign tokenValue = iso-date(date(pTimestamp)).
            // years
            when 'YYYY':u then
                assign tokenValue = string(year(pTimestamp), '9999':u).
            when 'YY':u then
                assign tokenValue = string(year(pTimestamp) mod 100, '99':u).
            
            // Months
            when 'B':u then 
                assign tokenValue = pMonthShort[month(pTimestamp)].
            when 'BB':u then
                assign tokenValue = pMonthLong[month(pTimestamp)].
                
            // Months (M and MM)
            when 'M':u or
            when 'MM':u then
                assign tokenValue = string(month(pTimestamp), formatString).
            
            // Days
            when 'D':u or   
            when 'DD':u then
                assign tokenValue = string(day(pTimestamp), formatString).
            
            // Hours
            when 'H':u or   
            when 'HH':u then
                assign tokenValue = string(interval(pTimestamp, date(pTimestamp), 'hour':u),
                                         formatString).
            // Minutes
            when 'MMM':u then
                    assign tokenValue = string(interval(pTimestamp, date(pTimestamp), 'minutes':u) 
                                               - 60  * interval(pTimestamp, date(pTimestamp), 'hours':u),
                                               '99':u). 
            
            // Seconds
            when 'SS':u then
                    assign tokenValue = string(interval(pTimestamp, date(pTimestamp), 'seconds':u) 
                                               - 60  * interval(pTimestamp, date(pTimestamp), 'minutes':u),
                                               '99':u). 
            // Milliseconds
            when 'SSS':u then
                    assign tokenValue = string(interval(pTimestamp, date(pTimestamp), 'milliseconds':u) 
                                               - 1000 * interval(pTimestamp, date(pTimestamp), 'seconds':u),
                                               '999':u). 
            
            // Timezone
            when 'Z':u then
                assign tokenValue = string(timezone(pTimestamp), '+999':u).
            
            // Weekday
            when 'A':u then 
                assign tokenValue = pWeekdayShort[weekday(pTimestamp)].
            when 'AA':u then
                assign tokenValue = pWeekdayLong[weekday(pTimestamp)].
            when 'W':u then 
                assign tokenValue = string(weekday(pTimestamp)).
            
            // AM/PM
            when 'P':u or
            when 'PP':u then
            do:
                assign timeValue = interval(pTimestamp, date(pTimestamp), 'hour':u).
                if timeValue ge 12 then                        
                    assign tokenValue = 'PM':u.
                else
                    assign tokenValue = 'AM'.
                // A -> A or P; AA -> AM or PM    
                assign tokenValue = substring(tokenValue, 1, length(pTokenArg)).
            end.
        end.
        
        return tokenValue.
    end method.
    
    /** Splits a .-delimited token argument into an array
    
        @param character the token argument to return
        @return character[] An array of character. If the input arg is empty/null we return a [1] array */
    method static private character extent SplitTokenArg (input pTokenArg as character):
        define variable args as character extent no-undo.
        define variable loop as integer no-undo.
        define variable cnt as integer no-undo.
        
        if    pTokenArg eq '':u 
           or pTokenArg eq ?
           then
            assign extent(args) = 1.
        else
        do:
            assign cnt          = num-entries(pTokenArg, '.':u)
                   extent(args) = cnt
                   .
            do loop = 1 to cnt:
                args[loop] = entry(loop, pTokenArg, '.':u).
            end.
        end.
        return args.
    end method. 

    /* Resolves a CP-based token arg, based on the client-principal.
        
       It is the CALLER's responsibility to clean up the C-P object represented by this handle
       
       @param character The token argument for ${CP.*} tokens
       @param handle     A user represented by a client-principal 
       @return character The resolved string  */
    method static public character ResolveUser(input pTokenArg as character,
                                               input pUser as handle):
        define variable tokenValue as character no-undo.
        define variable args as character extent no-undo.
        define variable dynCall as handle no-undo.
        
        if not valid-handle(pUser) then
            return ?.
        
        if not pUser:type eq 'Client-Principal':u then
            return ?. 
        
        assign tokenValue = ?
               args       = SplitTokenArg(pTokenArg)
               .
        case args[1]:
            when 'tid':u then
            do:
                if extent(args) eq 1 then
                    assign tokenValue = string(pUser:tenant-id()).
                else
                    assign tokenValue = string(pUser:tenant-id(args[2])).
            end.
            when 'tname':u then
            do:
                if extent(args) eq 1 then
                    assign tokenValue = pUser:tenant-name().
                else
                    assign tokenValue = pUser:tenant-name(args[2]).
            end.    //tenant
            when 'uid':u then
                assign tokenValue = pUser:user-id. 
            when 'quid':u then
                assign tokenValue = pUser:qualified-user-id.
            when 'domain':u then
                assign tokenValue = pUser:domain-name.
            otherwise
            do:
                create call dynCall.
                assign dynCall:call-type = get-attr-call-type
                       dynCall:call-name = args[1]
                       dynCall:in-handle = pUser
                       .
                dynCall:invoke no-error.
                assign tokenValue = dynCall:return-value. 
            end.    //other properties
        end case.
        
        return tokenValue.
        finally:
            if valid-object(dynCall) then
                delete object dynCall no-error.
        end finally.
    end method.
    
    /* Resolves any tokens in the file name into appropriate values
       
       @param character The source string
       @return character The resolved string */
    method static public character Resolve(input pcBaseString as character):
        define variable resolvedName as character no-undo.
        define variable startPos as integer no-undo.
        define variable endPos as integer no-undo.
        define variable token as character no-undo.
        define variable dynCall as handle no-undo.
        define variable logicalDb as character no-undo.
        define variable currentTime as datetime-tz no-undo.
        define variable formatString as character no-undo.
        define variable currentUser as handle no-undo.
        define variable tokenEventArgs as TokenResolverEventArgs no-undo.
        define variable dotPos as integer no-undo.
        
        if pcBaseString eq ? then
            return '':u.
        
        //assign startPos = index(pcBaseString, '$':u).
        assign startPos = index(pcBaseString, '$':u + StringConstant:CURLY_OPEN).
        if startPos eq 0 then
            return pcBaseString.
        
        assign /* use a variable to fix the time used in the filename. if we use now or time, we may flip 
                  to the next (milli)second during the execution of this loop */
               currentTime    = now
               .
        do while startPos gt 0:
            assign endPos     = index(pcBaseString, StringConstant:CURLY_CLOSE)
                   token      = substring(pcBaseString, startPos, endPos - startPos + 1)
                   token      = trim(token, '$':u + StringConstant:CURLY_OPEN)
                   token      = trim(token, StringConstant:CURLY_CLOSE)
                   .
            
            // TokenValue is set to ? in the ctor
            assign tokenEventArgs = new TokenResolverEventArgs(token).
            case tokenEventArgs:TokenGroup:
                when 'session':u then
                do:
                    // we can get the rest dynamically.
                    if not valid-handle(dynCall) then
                        create call dynCall.
                    else
                        dynCall:clear().
                    
                    assign dynCall:call-type = get-attr-call-type
                           dynCall:call-name = tokenEventArgs:TokenArg
                           dynCall:in-handle = session:handle
                           .                              
                    dynCall:invoke no-error.
                    assign tokenEventArgs:TokenValue = substitute('&1':u, dynCall:return-value). 
                end.   // session
                
                when 't':u or
                when 'time':u then
                    assign tokenEventArgs:SourceValue = new TimeStamp(currentTime)
                           tokenEventArgs:TokenValue  = ResolveTime(tokenEventArgs:TokenArg, currentTime).
                
                when 'guid':u then
                    assign tokenEventArgs:TokenValue = guid.
                
                when 'env':u then
                do:
                    case tokenEventArgs:TokenArg:
                        when 'CATALINA_BASE':u then
                        do:
                            if mInstanceRoot eq '':u then
                                assign tokenEventArgs:TokenValue = os-getenv(tokenEventArgs:TokenArg)
                                       mInstanceRoot             = tokenEventArgs:TokenValue.
                            else
                                assign tokenEventArgs:TokenValue = mInstanceRoot. 
                        end.
                        otherwise
                            assign tokenEventArgs:TokenValue = os-getenv(tokenEventArgs:TokenArg).
                    end case.
                end.    //env
                
                when 'version':u or
                when 'ver':u then
                case tokenEventArgs:TokenArg:
                    when 'major':u then
                        assign tokenEventArgs:TokenValue = session:local-version-info:OEMajorVersion.
                    when 'minor':u then
                        assign tokenEventArgs:TokenValue = session:local-version-info:OEMinorVersion.
                    when 'maint':u then
                        assign tokenEventArgs:TokenValue = session:local-version-info:OEMaintVersion.
                end.    // version
                
                when 'request':u or
                when 'req':u then
                case tokenEventArgs:TokenArg:
                    when 'tpt':u then
                        assign tokenEventArgs:TokenValue = string(session:current-request-info:AdapterType). 
                   when 'ccid':u then
                        assign tokenEventArgs:TokenValue = session:current-request-info:ClientContextId.
                    when 'id':u then
                        assign tokenEventArgs:TokenValue = session:current-request-info:RequestId.
                    when 'session':u then
                        assign tokenEventArgs:TokenValue = string(session:current-request-info:SessionId).
                    when 'thread':u then
                        assign tokenEventArgs:TokenValue = string(session:current-request-info:ThreadId).
                end case.
                
                when 'web':u then
                // if we're not in a WEBSPEED or PASOE session, these'll resiolve to null/unknown
                case tokenEventArgs:TokenArg:
                    // the file-system path to the webapp
                    when 'webapp.path':u then
                        assign tokenEventArgs:TokenValue = web-context:get-cgi-value('env':u, 'BASE_PATH':u).
                    // the webapp name
                    when 'webapp':u or
                    when 'webapp.name':u then
                    do:
                        // we want a name here not a path. for that, use webapp.path
                        assign tokenEventArgs:TokenValue = trim(web-context:get-cgi-value('env':u, 'CONTEXT_PATH':u), '/':u).
                        if tokenEventArgs:TokenValue eq '':u then
                            assign tokenEventArgs:TokenValue = 'ROOT':u.
                    end.
                    
                    otherwise
                        assign tokenEventArgs:TokenValue = web-context:get-cgi-value('env':u, caps(tokenEventArgs:TokenArg)).
                end case.  // web
                
                when 'cp':u then
                do:
                    if num-entries(tokenEventArgs:TokenArg, '.':u) gt 1 then
                    do:
                        assign logicalDb = entry(2, tokenEventArgs:TokenArg, '.':u).
                        if     valid-handle(currentUser) 
                           and lookup(logicalDb, currentUser:db-list) eq 0 
                        then
                            delete object currentUser no-error.
                        
                        if not valid-handle(currentUser) then
                            assign currentUser = get-db-client(logicalDb) no-error.
                    end.
                    
                    if not valid-handle(currentUser) then
                        assign currentUser = security-policy:get-client().
                    
                    if valid-handle(currentUser) then
                        // the C-P represented by currentUser is manually cleaned up in this method's finally block
                        assign tokenEventArgs:SourceValue = new Principal(currentUser)
                               tokenEventArgs:TokenValue  = ResolveUser(tokenEventArgs:TokenArg, currentUser)
                               .
                end.    //cp
                
                when 'name':u then
                    //tokenArg = format-expression "." logger-name 
                    assign dotPos                     = index(tokenEventArgs:TokenArg, '.':u)
                           tokenEventArgs:SourceValue = new String(substring(tokenEventArgs:TokenArg, dotPos + 1))
                           tokenEventArgs:TokenValue  = ResolveName(substring(tokenEventArgs:TokenArg, 1, dotPos - 1),
                                                                    tokenEventArgs:SourceValue:ToString()).
            end case.   // token-group 
            
            // see if anyone wants to change this token, or handle tokens we don't know about
            TokenResolved:Publish(get-class(TokenResolver), tokenEventArgs).
            
            // null values aren't nice in the filesystem. use the original token instead
            if tokenEventArgs:TokenValue eq ? then
                assign tokenEventArgs:TokenValue = token.
            
            assign resolvedName = resolvedName
                                // add the stuff before the ${
                                + substring(pcBaseString, 1, startPos - 1)
                                // add the replaced value
                                + tokenEventArgs:TokenValue
                    
                   // chop off the and everything preceeding the first } in the string
                   pcBaseString = substring(pcBaseString, endPos + 1)
                   // see if there's another token
                   startPos     = index(pcBaseString, '$':u + StringConstant:CURLY_OPEN).
                   .
        end.
        
        return resolvedName + pcBaseString.
        finally:
            if valid-object(currentUser) then
                delete object currentUser no-error.
            if valid-object(dynCall) then
                delete object dynCall no-error.
        end finally.
    end method.
    
end class.
/************************************************
Copyright (c) 2018 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : TokenResolverEventArgs
    Purpose     : Arguments for events published when an individual token is resolved
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2018-01-24
    Notes       : * See OE.Core.Util.TokenResolver for info about the type and args
                  * Token substitutions are allowed for file names
                    the token format is ${<token>}, where
                        token = group "." arg
                    groups = session | env | guid | t[ime] | web | ver[sion]
                             cp | req[uest] | name 
                    
                    If a token cannot be resovled, or resolves to a value of
                    ? (unknown) then the token name is used.   
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.EventArgs.

class OpenEdge.Core.Util.TokenResolverEventArgs inherits EventArgs:
    /* (mandatory) The token group being resolved */
    define public property TokenGroup as character no-undo get. private set.
    /* (optional) The token arguments being resolved */
    define public property TokenArg  as character no-undo get. private set.
    /* The resolved value */
    define public property TokenValue as character initial ? no-undo get. set.

    /* (optional) The complete original token being resolved */
    define public property BaseToken as character no-undo get. private set.
    /* (optional) Some tokens may be resolved via input values (name, user, cp). This property holds the 
       input/base value */
    define public property SourceValue as Progress.Lang.Object no-undo get. set.
    
    /* Constructor
       
       @param character The base token (mandatory) */
    constructor public TokenResolverEventArgs(input pToken as character):
        Assert:NotNull(pToken, 'Base token').
        
        assign this-object:TokenArg   = substring(pToken, index(pToken, '.':u) + 1)
               this-object:TokenGroup = entry(1, pToken, '.':u)
               this-object:BaseToken  = pToken
               this-object:TokenValue = ?
               .
    end constructor.
    
    /* Constructor
       
       @param character The token group (mandatory)
       @param character The token arguments (if any) */
    constructor public TokenResolverEventArgs(input pGroup as character,
                                              input pArg as character):
        this-object(pGroup, pArg, ?).
    end constructor.
    
    /* Constructor
       
       @param character The token group (mandatory)
       @param character The token arguments (if any)
       @param character The token value     */
    constructor public TokenResolverEventArgs(input pGroup as character,
                                              input pArg as character,
                                              input pValue as character):
        Assert:NotNullOrEmpty(pGroup, 'Token group').
        Assert:NotNull(pArg, 'Token argument').
        
        assign this-object:TokenGroup = pGroup
               this-object:TokenArg   = pArg
               this-object:TokenValue = pValue
               .
    end constructor.
    
end class. /************************************************
Copyright (c) 2013,2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : SaxReader
    Purpose     : Wrapper OpenEdge/Core/XML/SaxReaderfacade.p which handles SAX
                  parser events.
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Jul 13 09:50:23 EDT 2010
    Notes       : * The strongly-typed events in this class correspond to the
                    SAX-READER events, as documented in the ABL documentation
                    set. This class basically acts as a wrapper around a .P 
                    since classes can't be specified as listeners for the SAX-
                    READER object. This class then re-publishes the events as
                    strongly typed events.
                  * The strongly-typed events in this class follow the ABL convention,
                    and not the sender,eventargs convention otherwise used in
                    this reference code.
                  * This class based on the AutoEdge|TheFactory version
  ---------------------------------------------------------------------- */
block-level on error undo, throw.
using OpenEdge.Core.XML.SaxReader.

class OpenEdge.Core.XML.SaxReader:
    
    /* SAX Events from SAX-READER callbacks */
    define public event SaxReaderStartDocument signature void(input phReader as handle).
     
    define public event SaxReaderProcessingInstruction signature void (input phReader as handle, 
                                                                       input pcTarget as character,
                                                                       input pcData as character).    
    define public event SaxReaderResolveEntity signature void (input phReader as handle,
                                                               input pcPublicID as character,
                                                               input pcSystemID as character,
                                                               output pcFilePath as character,
                                                               output pcMemPointer as longchar).
    define public event SaxReaderStartPrefixMapping signature void (input phReader as handle,
                                                                    input pcPrefix as character,
                                                                    input pcURI as character).    
    define public event SaxReaderEndPrefixMapping signature void (input phReader as handle,
                                                                  input pcPrefix as character).    
    define public event SaxReaderStartElement signature void (input phReader as handle,
                                                              input pcNamespaceURI as character,
                                                              input pcLocalName as character,
                                                              input pcQName as character,
                                                              input phAttributes as handle ).
    define public event SaxReaderCharacters signature void (input phReader as handle,
                                                            input pcCharData as longchar,
                                                            input piNumChars as integer).
    define public event SaxReaderIgnorableWhitespace signature void (input phReader as handle,
                                                                     input pcCharData as character,
                                                                     input piNumChars as integer).
    define public event SaxReaderEndElement signature void (input phSaxReader as handle,
                                                            input pcNamespaceURI as character,
                                                            input pcLocalName as character,
                                                            input pcQName as character).
    define public event SaxReaderEndDocument signature void (input phReader as handle).
    define public event SaxReaderNotationDecl signature void (input phReader as handle,
                                                              input pcName  as character,
                                                              input pcPublicID as character,
                                                              input pcSystemID as character).
    define public event SaxReaderUnparsedEntityDecl signature void (input phReader as handle,
                                                                    input pcName as character,
                                                                    input publicID     as character,
                                                                    input systemID     as character,
                                                                    input pcNotationName as character).
    define public event SaxReaderWarning signature void (input phReader as handle,
                                                         input pcErrMessage as character).
    define public event SaxReaderError signature void (input phReader as handle,
                                                       input pcErrMessage as character).
    define public event SaxReaderFatalError signature void (input phReader as handle,
                                                            input pcErrMessage as character).
    
    define private variable mhParserProc as handle no-undo.
    
    constructor public SaxReader():
    end constructor.
    
    destructor public SaxReader():
        delete procedure mhParserProc no-error.
    end destructor.
    
    /* Parses the XML contained in the input longchar
       
       @param longchar The XML data to parse. */
    method public void ParseDocument(input pcXML as longchar):
        /* run the facade.p for each  document run, since we set up a circular dependency
           and GC cannot clean it up */
        run OpenEdge/Core/XML/saxreaderfacade.p persistent set mhParserProc (this-object).        
        
        run ParseDocument in mhParserProc (pcXML).
        
        finally:
            delete object mhParserProc no-error.
        end finally.
    end method.
    
    /* Parses the XML contained in the input memptr
       
       @param memptr The XML data to parse. */
    method public void ParseDocument(input pmXML as memptr):
        /* run the facade.p for each  document run, since we set up a circular dependency
           and GC cannot clean it up */
        run OpenEdge/Core/XML/saxreaderfacade.p persistent set mhParserProc (this-object).
                
        run ParseMemptr in mhParserProc (pmXML).
        finally:
            set-size(pmXML) = 0.
            delete object mhParserProc no-error.
        end finally.
    end method.

    /* Parses the XML contained in the input file
       
       @param character The name of the file to parse. */
    method public void ParseFile(input pcFilename as character):
        /* run the facade.p for each  document run, since we set up a circular dependency
           and GC cannot clean it up */
        run OpenEdge/Core/XML/saxreaderfacade.p persistent set mhParserProc (this-object).
                
        run ParseFile in mhParserProc (pcFilename).
        finally:
            delete object mhParserProc no-error.
        end finally.
    end method.
    
    /* Tell the parser where to find an external entity. */
    method public void ResolveEntity (input pcPublicID as character,
                                      input pcSystemID as character,
                                      output pcFilePath as character,
                                      output pcMemPointer as longchar):
        SaxReaderResolveEntity:Publish(self:handle, pcPublicID, pcSystemID, output pcFilePath, output pcMemPointer).                                          
    end method.
    
    /** Process various XML tokens. */
    method public void StartDocument():
        SaxReaderStartDocument:Publish(self:handle).
    end method.

    method public void ProcessingInstruction(input pcTarget as character,
                                             input pcData as character):
        SaxReaderProcessingInstruction:Publish(self:handle, pcTarget, pcData).
    end method.
    
    method public void StartPrefixMapping(input pcPrefix as character,
                                          input pcURI as character):
        SaxReaderStartPrefixMapping:Publish(self:handle, pcPrefix, pcURI).                                              
    end method.

    method public void EndPrefixMapping(input pcPrefix as character):
        SaxReaderEndPrefixMapping:Publish(self:handle, pcPrefix).
    end method.

    method public void StartElement(input pcNamespaceURI as character,
                                    input pcLocalName as character,
                                    input pcQName as character,
                                    input phAttributes as handle ):
        SaxReaderStartElement:Publish(self:handle, pcNamespaceURI, pcLocalName, pcQName, phAttributes).                                        
    end method.

    method public void Characters(input pcCharData as longchar,
                                  input piNumChars as integer):
        SaxReaderCharacters:Publish(self:handle, pcCharData, piNumChars).
    end method.

    method public void IgnorableWhitespace(input pcCharData as character,
                                           input piNumChars as integer):
        SaxReaderIgnorableWhitespace:Publish(self:handle, pcCharData, piNumChars).
    end method.

    method public void EndElement(input pcNamespaceURI as character,
                                  input pcLocalName as character,
                                  input pcQName as character):
        SaxReaderEndElement:Publish(self:handle, pcNamespaceURI, pcLocalName, pcQName).                                      
    end method.

    method public void EndDocument():
        SaxReaderEndDocument:Publish(self:handle).
    end method.

    /** Process notations and unparsed entities.*/
    method public void NotationDecl(input pcName  as character,
                                    input pcPublicID as character,
                                    input pcSystemID as character):
        SaxReaderNotationDecl:Publish(self:handle, pcName, pcPublicID, pcSystemID).                                        
    end method.

    method public void UnparsedEntityDecl(input pcName as character,
                                          input pcPublicID as character,
                                          input pcSystemID as character,
                                          input pcNotationName as character):
        SaxReaderUnparsedEntityDecl:Publish(self:handle, pcName, pcPublicID, pcSystemID, pcNotationName).                                              
    end method.

    /*Handle errors.*/
    method public void Warning(input pcErrMessage as character):
        SaxReaderWarning:Publish(self:handle, pcErrMessage).
    end method.

    method public void Error(input pcErrMessage as character):
        SaxReaderError:Publish(self:handle, pcErrMessage).
    end method.
    
    method public void FatalError(input pcErrMessage as character):
        SaxReaderFatalError:Publish(self:handle, pcErrMessage).
    end method. 
    
end class.
/************************************************
Copyright (c) 2013,2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : SaxReaderfacade.p
    Purpose     : XML SAX parser facade procedure.
    Syntax      :
    Description : 
    @author pjudge
    Created     : Tue Jul 13 09:40:09 EDT 2010
    Notes       : * This procedure acts as a facade object for the SaxReader
                    class, since classes can't be subscribed as event listeners
                    for the ABL SAX-READER.
                  * The individual procedures here are as documented in the
                    ABL documentation set. 
                  * This program based on the AutoEdge|TheFactory version
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.XML.SaxReader.

/* ***************************  Definitions  ************************** */
/** The facade object that handles the callbacks from the SAX parser, and which
    publishes them as typed events. */
define input parameter poSaxReader as SaxReader no-undo.

create widget-pool.

/* ***************************  Main Block  *************************** */
procedure ParseMemptr:
    define input parameter pmXML as memptr no-undo.
    
    define variable hSaxReader as handle no-undo.
    define variable hSaxAttributes as handle no-undo.
    
    create sax-reader hSaxReader.
    assign hSaxReader:handler      = this-procedure
           hSaxReader:private-data = poSaxReader:ToString()
           . 
    create sax-attributes hSaxAttributes.
    
    hSaxReader:set-input-source('memptr':u, pmXML).
    hSaxReader:sax-parse().
    
    finally:
        delete object hSaxAttributes no-error.
        delete object hSaxReader no-error.
        set-size(pmXML) = 0.
    end finally.
end procedure.

procedure ParseDocument:
    define input parameter pcXML as longchar no-undo.
    
    define variable hSaxReader as handle no-undo.
    define variable hSaxAttributes as handle no-undo.
    
    create sax-reader hSaxReader.
    assign hSaxReader:handler      = this-procedure
           hSaxReader:private-data = poSaxReader:ToString()
           .
    create sax-attributes hSaxAttributes.
    
    hSaxReader:set-input-source('longchar':u, pcXML).
    hSaxReader:sax-parse().
    
    finally:
        delete object hSaxAttributes no-error.
        delete object hSaxReader no-error.
    end finally.
end procedure.

procedure ParseFile:
    define input parameter pcFileName as character no-undo.
    
    define variable hSaxReader as handle no-undo.
    define variable hSaxAttributes as handle no-undo.
    
    assign file-info:file-name = pcFileName.
    
    create sax-reader hSaxReader.
    assign hSaxReader:handler      = this-procedure
           hSaxReader:private-data = poSaxReader:ToString()
           .
    create sax-attributes hSaxAttributes.
    
    hSaxReader:set-input-source('file':u, file-info:full-pathname).
    hSaxReader:sax-parse().
    
    finally:
        delete object hSaxAttributes no-error.
        delete object hSaxReader no-error.
    end finally.
end procedure.

/* ***************************  Callbacks  *************************** */

/* Tell the parser where to find an external entity. */
procedure ResolveEntity:
    define input  parameter publicID   as character no-undo.
    define input  parameter systemID   as character no-undo.
    define output parameter filePath   as character no-undo.
    define output parameter memPointer as longchar no-undo.
    
    poSaxReader:ResolveEntity(publicID, systemID, output filePath, output memPointer).
end procedure.

/** Process various XML tokens. */
procedure StartDocument:
    poSaxReader:StartDocument().
end procedure.

procedure ProcessingInstruction:
    define input parameter target as character no-undo.
    define input parameter data   as character no-undo.
    
    poSaxReader:ProcessingInstruction(target, data).
end procedure.

procedure StartPrefixMapping:
    define input parameter prefix as character no-undo.
    define input parameter uri    as character no-undo.
    
    poSaxReader:StartPrefixMapping(prefix, uri).
end procedure.

procedure EndPrefixMapping:    
    define input parameter prefix as character no-undo.
    
    poSaxReader:EndPrefixMapping(prefix).
end procedure.

procedure StartElement:
    define input parameter namespaceURI as character no-undo.
    define input parameter localName    as character no-undo.
    define input parameter qName        as character no-undo.
    define input parameter attributes   as handle no-undo.
    
    poSaxReader:StartElement(namespaceURI, localName, qName, attributes).
end procedure.

procedure Characters:
    define input parameter charData as longchar no-undo.
    define input parameter numChars as integer no-undo.
    
    poSaxReader:Characters(charData, numChars).
end procedure.

procedure IgnorableWhitespace:
    define input parameter charData as character no-undo.
    define input parameter numChars as integer.
    
    poSaxReader:IgnorableWhitespace(charData, numChars).
end procedure.

procedure EndElement:
     define input parameter namespaceURI as character no-undo.
     define input parameter localName    as character no-undo.
     define input parameter qName        as character no-undo.
     
     poSaxReader:EndElement(namespaceURI, localName, qName).
end procedure.

procedure EndDocument:
    poSaxReader:EndDocument().
end procedure.

/** Process notations and unparsed entities.*/
procedure NotationDecl:
    define input parameter name     as character no-undo.
    define input parameter publicID as character no-undo.
    define input parameter systemID as character no-undo.
    
    poSaxReader:NotationDecl(name, publicID, systemID).
end procedure.

procedure UnparsedEntityDecl:
    define input parameter name         as character no-undo.
    define input parameter publicID     as character no-undo.
    define input parameter systemID     as character no-undo.
    define input parameter notationName as character no-undo.
    
    poSaxReader:UnparsedEntityDecl(name, publicID, systemID, notationName).
end procedure.

/*Handle errors.*/
procedure Warning:
    define input parameter errMessage as character no-undo.
    
    poSaxReader:Warning(errMessage).
end procedure.

procedure Error:
    define input parameter errMessage as character no-undo.
     
    poSaxReader:Error(errMessage).
end procedure.

procedure FatalError:
    define input parameter errMessage as character no-undo.
    
    poSaxReader:FatalError(errMessage).
end procedure.

/** EOF **/
/************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/* ------------------------------------------------------------------------
    File        : SaxWriter
    Purpose     : An OOABL wrapper around the ABL SAX-WRITER handle. 
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Mon Nov 22 15:40:24 EST 2010
    Notes       : * The majority of method names correspond to the ABL attributes/methods,
                    which are comprehensively documented in the ABL documentation set.
                  * This program based on the AutoEdge|TheFactory version
  --------------------------------------------------------------------- */
block-level on error undo, throw.

using OpenEdge.Core.XML.SaxWriter.
using OpenEdge.Core.XML.SaxWriterDataTypeEnum.
using OpenEdge.Core.XML.SaxWriteStatusEnum.
using OpenEdge.Core.SerializationModeEnum.
using OpenEdge.Core.Assert.
using OpenEdge.Core.DataTypeEnum.
using Progress.Lang.AppError.

class OpenEdge.Core.XML.SaxWriter use-widget-pool:
    
    /* The actual SAX-WRITER handle */
    define private variable mhSaxWriter as handle no-undo.
    
    /** (derived) Maps to SAX-WRITER WRITE-STATUS attribute. See the ABL documentation for more details. */
    define public property WriteStatus as SaxWriteStatusEnum no-undo
        get():
            if valid-handle(mhSaxWriter) then
                return SaxWriteStatusEnum:GetEnum(/* STRING() because of PSC00330756 */ string(mhSaxWriter:write-status)).
        end get.
    
    /** Maps to SAX-WRITER ENCODING attribute. See the ABL documentation for more details. */
    define public property Encoding  as character no-undo
        get.
        set(input pcEncoding as character):
            ValidateCanUpdateProperty('Encoding').
            mhSaxWriter:encoding = pcEncoding.
            Encoding = pcEncoding.
        end set.
        
    
    /** Maps to SAX-WRITER FORMATTED attribute. See the ABL documentation for more details. */
    define public property IsFormatted as logical no-undo 
        get.
        set (input plFormatted as logical):
            ValidateCanUpdateProperty('IsFormatted').
            IsFormatted = plFormatted.
            mhSaxWriter:formatted = plFormatted.
        end set.
    

    /** Maps to SAX-WRITER FRAGMENT attribute. See the ABL documentation for more details. */
    define public property IsFragment as logical no-undo
        get.
        set (input plFragment as logical):
            ValidateCanUpdateProperty('IsFragment').
            IsFragment = plFragment.
            mhSaxWriter:fragment = plFragment.
        end set.
    
    /** Maps to SAX-WRITER STANDALONE attribute. See the ABL documentation for more details. */ 
    define public property IsStandalone as logical no-undo
        get.
        set(input plStandalone as logical):
            ValidateCanUpdateProperty('IsStandalone').
            IsStandalone = plStandalone.
            mhSaxWriter:standalone = plStandalone.
        end set.
    
    /** Maps to SAX-WRITER STRICT attribute. See the ABL documentation for more details. */
    define public property IsStrict as logical no-undo
        get.
        set(input plStrict as logical):
            ValidateCanUpdateProperty('IsStrict').
            IsStrict = plStrict.
            mhSaxWriter:strict= plStrict.
        end set.
    
    /** Maps to SAX-WRITER VERSION attribute. See the ABL documentation for more details. */
    define public property Version  as character no-undo
        get.
        set(input pcVersion as character):
            ValidateCanUpdateProperty('Version').
            
            if IsStrict and Version ne '1.0' then
                undo, throw new AppError (
                    substitute('Error setting "Version" property when with SaxWriter:IsStrict and version is &1',
                            pcVersion)
                    ,0). 
            mhSaxWriter:version = pcVersion.
            Version = pcVersion.
        end set.
        
    /* Public property setter methods provided to enable a Fluent-style interface 
      ( oSW:SetIsStrict(true):StartDocument(): ... ) */
    method public SaxWriter SetVersion(input pcVersion as character):
        this-object:Version = pcVersion.
        return this-object.
    end method.

    method public SaxWriter SetEncoding(input pcEncoding as character):
        this-object:Encoding = pcEncoding.
        return this-object.
    end method.
    
    method public SaxWriter SetIsFormatted(input plIsFormatted as logical):
        this-object:IsFormatted = plIsFormatted.
        return this-object.
    end method.

    method public SaxWriter SetIsStandalone(input plIsStandalone as logical):
        this-object:IsStandalone = plIsStandalone.
        return this-object.
    end method.

    method public SaxWriter SetIsFragment(input plIsFragment as logical):
        this-object:IsFragment = plIsFragment.
        return this-object.
    end method.

    method public SaxWriter SetIsStrict(input plIsStrict as logical):
        this-object:IsStrict = plIsStrict.
        return this-object.
    end method.
        
    constructor public SaxWriter():
        Initialize().
    end constructor.
    
    constructor public SaxWriter(input pcFilename as character):
        Initialize().
        WriteTo(pcFilename).
    end constructor.

    constructor public SaxWriter(input pcDocument as longchar):
        Initialize().
        WriteTo(pcDocument).
    end constructor.

    constructor public SaxWriter(input phStream as handle):
        Initialize().
        WriteTo(phStream).
    end constructor.

    constructor public SaxWriter(input pmDocument as memptr):
        Initialize().
        WriteTo(pmDocument).            
    end constructor.
    
    method protected void ValidateCanUpdateProperty(input pcPropertyName as character):
        if valid-handle(mhSaxWriter) then
        case WriteStatus:
            when SaxWriteStatusEnum:Idle or when SaxWriteStatusEnum:Complete then
                /* allowed to update property */ .
            otherwise
                undo, throw new AppError(
                    substitute('Error setting &1 property when SaxWriter status is &2',
                            quoter(pcPropertyName),
                            this-object:WriteStatus:ToString())
                        ,0).
        end case.
    end method.
    
    method public void Initialize():
        if not valid-handle(mhSaxWriter) then
            create sax-writer mhSaxWriter.
        else
            Reset().                
    end method.
    
    method public SaxWriter Reset():
        if valid-handle(mhSaxWriter) then
            mhSaxWriter:reset().
        return this-object.            
    end method.
    
    method public SaxWriter WriteTo(input pcFilename as character):
        mhSaxWriter:set-output-destination(SerializationModeEnum:File:ToString(), pcFilename).
        return this-object.    
    end method.

    method public SaxWriter WriteTo(input pcDocument as longchar):
        mhSaxWriter:set-output-destination(SerializationModeEnum:LongChar:ToString(), pcDocument).
        return this-object.
    end method.
    
    method public SaxWriter WriteTo(input phStream as handle):
        Assert:IsType(phStream, DataTypeEnum:Stream, 'stream').
        
        mhSaxWriter:set-output-destination(SerializationModeEnum:StreamHandle:ToString(), phStream).
        return this-object.
    end method.

    method public SaxWriter WriteTo(input pmDocument as memptr):    
        mhSaxWriter:set-output-destination(SerializationModeEnum:Memptr:ToString(), pmDocument).
        return this-object.
    end method.
    
    method public SaxWriter StartDocument():
        mhSaxWriter:start-document().
        return this-object.
    end method. 

    method public void EndDocument():
        mhSaxWriter:end-document().
    end method.

    method public SaxWriter DeclareNamespace(input pcNamespaceURI as longchar):
        return DeclareNamespace(pcNamespaceURI, ?).                                               
    end method.                                               
    
    method public SaxWriter DeclareNamespace(input pcNamespaceURI as longchar,
                                           input pcNamespacePrefix as longchar):
        mhSaxWriter:declare-namespace(pcNamespaceURI, pcNamespacePrefix).
        return this-object.                                               
    end method.                                               
    
    method public SaxWriter StartElement(input pcName as longchar):
        return StartElement(pcName, ?, ?).
    end method.
    
    method public SaxWriter StartElement(input pcName as longchar,
                                       input pcNamespaceURI as longchar):
        return StartElement(pcName, pcNamespaceURI, ?).
    end method.
    
    method public SaxWriter StartElement(input pcName as longchar,
                                       input pcNamespaceURI as longchar,                                       
                                       input phSaxAttributes as handle):
        mhSaxWriter:start-element(pcName, pcNamespaceURI, phSaxAttributes).
        return this-object.
    end method.

    
    method public SaxWriter EndElement(input pcName as longchar):
        return EndElement(pcName, ?).
    end method.
    
    method public SaxWriter EndElement(input pcName as longchar,
                                     input pcNamespaceURI as longchar):
        mhSaxWriter:end-element(pcName, pcNamespaceURI).
        return this-object.                                           
    end method.

    method public SaxWriter InsertAttribute (input pcName as longchar,
                                           input pcValue as longchar):
        return InsertAttribute(pcName, pcValue, ?). 
    end method.            

    method public SaxWriter InsertAttribute (input pcName as longchar,
                                             input pcValue as longchar,
                                             input pcNamespaceURI as longchar):
        mhSaxWriter:insert-attribute(pcName, pcValue, pcNamespaceURI).
        return this-object. 
    end method.
    
    /** Writes a value to the output destination. This method defaults to
        writing characters. 
        
        @param longchar The value being written.
        @return logical Whether the operation succeeded or not. */
    method public SaxWriter WriteValue(input pcValue as longchar):
        return WriteValue(SaxWriterDataTypeEnum:Characters, pcValue).
    end method.
    
    /** Writes a value to the output destination. This method simply writes
        the value for the given type, using the correct WRITE-* call. 
        
        There's a WriteFragment() method which deals with a noderef handle.
        
        @param SaxWriterDataTypeEnum The element type
        @param longchar The value being written.
        @return logical Whether the operation succeeded or not. */
    method public SaxWriter WriteValue(input poType as SaxWriterDataTypeEnum,
                                       input pcValue as longchar):
        case poType:
            when SaxWriterDataTypeEnum:CData then mhSaxWriter:write-cdata(pcValue).
            when SaxWriterDataTypeEnum:Characters then mhSaxWriter:write-characters(pcValue).
            when SaxWriterDataTypeEnum:Comment then mhSaxWriter:write-comment(pcValue).
            when SaxWriterDataTypeEnum:EntityReference then mhSaxWriter:write-entity-ref(pcValue).
            when SaxWriterDataTypeEnum:Fragment then mhSaxWriter:write-fragment(pcValue).
        end case.
        return this-object.
    end method.
    
    /** Writes a fragment's values from a specified XML node ref 
        
        @param handle The valid XML node-ref handle containing the fragment
        @return logical Whether the operation succeeded or not. */
    method public SaxWriter WriteFragment(input phNodeRef as handle):
        Assert:IsType(phNodeRef, DataTypeEnum:XmlNodeRef, 'XML Node Ref').
        
        mhSaxWriter:write-fragment(phNodeRef).
        return this-object.
    end method.
    
    /** Writes a fragment's values from a specified XML node ref 
        
        @param longchar The longchar containing the fragment
        @return logical Whether the operation succeeded or not. */
    method public SaxWriter WriteFragment(input pcValue as longchar):
        mhSaxWriter:write-fragment(pcValue).
        return this-object.
    end method.
    
    method public SaxWriter WriteDataElement(input pcName as longchar,
                                           input pcValue as longchar):
        return WriteDataElement(pcName, pcValue, ?, ?).                                               
    end method.

    method public SaxWriter WriteDataElement(input pcName as longchar,
                                           input pcValue as longchar,
                                           input pcNamespaceURI as longchar):
        return WriteDataElement(pcName, pcValue, pcNamespaceURI, ?).                                               
    end method.
    
    method public SaxWriter WriteDataElement(input pcName as longchar,
                                           input pcValue as longchar,
                                           input pcNamespaceURI as longchar,
                                           input phSaxAttributes as handle ):
        mhSaxWriter:write-data-element(pcName, pcValue, pcNamespaceURI, phSaxAttributes).
        return this-object.                                               
    end method.

    method public SaxWriter WriteEmptyElement(input pcName as longchar):
        return WriteEmptyElement(pcName, ?, ?).
    end method.

    method public SaxWriter WriteEmptyElement(input pcName as longchar,
                                            input pcNamespaceURI as longchar):
        return WriteEmptyElement(pcName, pcNamespaceURI, ?).
    end method.
    
    method public SaxWriter WriteEmptyElement(input pcName as longchar,
                                            input pcNamespaceURI as longchar,
                                            input phSaxAttributes as handle ):
        mhSaxWriter:write-empty-element(pcName, pcNamespaceURI, phSaxAttributes).
        return this-object.
    end method.

    method public SaxWriter WriteExternalDTD(input pcName as longchar,
                                           input pcSystemId as longchar):
        return WriteExternalDTD(pcName, pcSystemId, ?).
    end method.
    
    method public SaxWriter WriteExternalDTD(input pcName as longchar,
                                           input pcSystemId as longchar,
                                           input pcPublicId as longchar):
        mhSaxWriter:write-external-dtd(pcName, pcSystemId, pcPublicId).
        return this-object.
    end method.
    
    method public SaxWriter WriteProcessingInstruction(input pcTarget as longchar,
                                                     input pcData as longchar):
        mhSaxWriter:write-processing-instruction(pcTarget, pcData).
        return this-object.                                                         
    end method.
    
end class.
/************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : SaxWriterDataTypeEnum
    Purpose     : Enumeration of the types that the SAX-WRITER can write as values
    Syntax      : 
    Description : 
    @author pjudge
    Created     : Tue Nov 23 09:02:49 EST 2010
    Notes       : * This program based on the AutoEdge|TheFactory version
  ---------------------------------------------------------------------- */
block-level on error undo, throw.

enum OpenEdge.Core.XML.SaxWriterDataTypeEnum :
    define enum       CData
                      Characters
                      Comment 
                      EntityReference 
                      Fragment. 
end enum.
/************************************************
Copyright (c)  2013, 2015 by Progress Software Corporation. All rights reserved.
*************************************************/
/** ------------------------------------------------------------------------
    File        : SaxWriteStatusEnum
    Purpose     : Enumerates the values of the SAX=WRITE WRITE-STATUS attribute 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Mon Nov 22 15:48:43 EST 2010
    Notes       : * See the ABL Help and/or documentation for details 
                  * This program based on the AutoEdge|TheFactory version
                  * The Sax-Write-* versions are added since the underlying
                    values were always those, and the name shortened. Built-in
                    enums don't allow you to set these independently
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

enum OpenEdge.Core.XML.SaxWriteStatusEnum: 
    define enum
            /* No writing has occurred. */
            Sax-Write-Idle
            Idle = Sax-Write-Idle
            
            /* The START-DOCUMENT method has been called and writing has begun. */
            Sax-Write-Begin
            Begin = Sax-Write-Begin
             
            /* The writer has written an opening tag. This is the only time that attributes can 
                be inserted with INSERT-ATTRIBUTE and DECLARE-NAMESPACE. */
            Sax-Write-Tag
            Tag = Sax-Write-Tag
            /* The writer is within an element. */
            Sax-Write-Element
            Element = Sax-Write-Element
            
            /* The writer has written the content of an element. In other words, the WRITE-CHARACTERS method has been called. */
            Sax-Write-Content
            Content  = Sax-Write-Content
            
            /* The END-DOCUMENT method has been called and writing is complete.  */
            Sax-Write-Complete
            Complete = Sax-Write-Complete
            
            /* The SAX-writer could not start or could not continue. Likely causes include: SAX-writer 
               could not be loaded, the XML target could not be written to, a method call fails, etc.
               This is the status if there is an invalid XML generated while STRICT is TRUE.
               If the status is SAX-WRITE-ERROR then no attributes can be written and the only
               method that can be called is RESET. */
            Sax-Write-Error
            Error = Sax-Write-Error
            
            Default = Idle.
                
end enum.
/************************************************
Copyright (c) 2016-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ConfigFileLoggerBuilder
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Mon Dec 05 09:48:11 EST 2016
    Notes       : * Assumes the config is stored in a JSON file
                    - named logging.config
                    - matching the schema in @DLC/src/corelib/OpenEdge/Logging/logging.config.schema
                  * Values are taken from this builder and loaded config read from logging.config. 
                    Any values set in this builder OVERRIDE the config values
                  * The logger name resolution follows that of log4j - described at
                     https://logging.apache.org/log4j/1.2/manual.html .
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.Util.BuilderRegistry.
using OpenEdge.Logging.ConfigFileLoggerBuilder.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.Filter.LogFilterBuilder.
using OpenEdge.Logging.Filter.LoggerFilterList.
using OpenEdge.Logging.Filter.LoggerFilterNode.
using OpenEdge.Logging.ILogWriter.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.Logger.
using OpenEdge.Logging.LoggerBuilder.
using OpenEdge.Logging.VoidLogger.
using Progress.Json.ObjectModel.JsonArray.
using Progress.Json.ObjectModel.JsonDataType.
using Progress.Json.ObjectModel.JsonObject.
using Progress.Json.ObjectModel.ObjectModelParser.
using Progress.Lang.AppError.

class OpenEdge.Logging.ConfigFileLoggerBuilder inherits LoggerBuilder: 
    // Monitors the time at which the config was last loaded
    define static private variable CONFIG_FILE_TIMESTAMP as datetime init ? no-undo.
    
    // The name of the file (in propath) that contains logging configuration.
    define static private variable CONFIG_FILE_NAME as character no-undo
            initial 'logging.config':u.
    
    // variables to hold the JSON property names
    define static private variable PROP_DEFAULT_LOGGER  as character initial 'DEFAULT_LOGGER':u no-undo.
    define static private variable PROP_LOGGER          as character initial 'logger':u         no-undo.
    define static private variable PROP_LEVEL           as character initial 'logLevel':u       no-undo.
    define static private variable PROP_FILTER_LIST     as character initial 'filters':u        no-undo.
    define static private variable PROP_FILTER_GROUP    as character initial 'filter':u         no-undo.
    define static private variable PROP_NAME            as character initial 'name':u           no-undo.
    define static private variable PROP_TYPE            as character initial 'type':u           no-undo.
    define static private variable PROP_HASH            as character initial 'hash':u           no-undo.
    define static private variable PROP_BUILDER         as character initial 'builder':u        no-undo.
    define static private variable PROP_FILE_NAME       as character initial 'fileName':u       no-undo.
    define static private variable PROP_FORMAT_STRING   as character initial 'format':u         no-undo.
    define static private variable PROP_APPEND_LOG      as character initial 'appendTo':u       no-undo.
    
    /** Registry for mapping builder types to their implementations
        
        This is the registry of LogFilterBuilders and not the registry of 
        log writers. */
    define static private property FilterBuilders as BuilderRegistry no-undo
        get():
            if not valid-object(ConfigFileLoggerBuilder:FilterBuilders) then
                assign ConfigFileLoggerBuilder:FilterBuilders = new BuilderRegistry(get-class(LogFilterBuilder)).
            
            return ConfigFileLoggerBuilder:FilterBuilders.
        end get.
        private set.
    
    // Registry for holding this factory's logger filters
    define static private property Filters as BuilderRegistry no-undo
        get():
            if not valid-object(ConfigFileLoggerBuilder:Filters) then
                assign ConfigFileLoggerBuilder:Filters = new BuilderRegistry(get-class(ILoggerFilter)).
            
            return ConfigFileLoggerBuilder:Filters.
        end get.
        private set.
    
    define static private temp-table Logger no-undo
        field LoggerName as character
        field LogLevel   as character
        
        index idx1 as primary unique LoggerName
        .
        
    define static private temp-table LogFilter no-undo
        field LoggerName as character
        field FilterName as character
        field Order as integer
        field FilterOptions as Progress.Lang.Object     // JsonObject
        
        index idx1 as primary unique LoggerName Order
        .
    
    /* Static constructor */
    constructor static ConfigFileLoggerBuilder():
        LoadFromFile(ConfigFileLoggerBuilder:CONFIG_FILE_NAME).
    end constructor.
    
    /* Loads logging config from a file
       
       @param character The filename to load. */
    method static private void LoadFromFile(input pFileName as character):
        define variable lastTouch as datetime no-undo.
        
        Assert:NotNullOrEmpty(pFileName, 'Config file').
        
        assign file-info:file-name = pFileName.
        
        // if there's no file, do nothing.
        if file-info:full-pathname eq ? then
        do: 
            // We previously loaded some config, and now have removed the file
            if not CONFIG_FILE_TIMESTAMP eq ? then
                ClearConfig().
            
            return.
        end.
        
        assign lastTouch = add-interval(datetime(file-info:file-mod-date), file-info:file-mod-time, 'seconds':u).
        
        // Load config file if it exists and the file MOD timestamp is after the last value
        if    CONFIG_FILE_TIMESTAMP eq ?
           or lastTouch gt CONFIG_FILE_TIMESTAMP
           then
        do:
            ClearConfig().
            assign CONFIG_FILE_TIMESTAMP = lastTouch. 
            LoadConfig(cast(new ObjectModelParser():ParseFile(file-info:full-pathname), JsonObject)).
        end.
    end method.
    
    /* Constructor
       
       @param character The logger type being built */
    constructor public ConfigFileLoggerBuilder (input pcLoggerType as character):
        super(pcLoggerType).
    end method.    

    /* Clears all the current logger configurations */
    method static public void ClearConfig():
        empty temp-table Logger.
        empty temp-table LogFilter.
        
        ConfigFileLoggerBuilder:FilterBuilders:Clear().
        ConfigFileLoggerBuilder:Filters:Clear().
    end method.

    /* Loads logging configuration from JSON
       
       @param JsonObject JSON representation of the lgging configuration */
    method static public void LoadConfig(input poJson as JsonObject):
        define variable iLoop as integer no-undo.
        define variable iMax as integer no-undo.
        define variable iInnerLoop as integer no-undo.
        define variable iInnerMax as integer no-undo.
        define variable cNames as character extent no-undo.
        define variable oConfig as JsonObject no-undo.
        define variable oData as JsonObject no-undo.
        define variable oType as JsonObject no-undo.
        define variable oFilters as JsonArray no-undo.
        define variable resolvedType as class Progress.Lang.Class no-undo.
        
        define buffer lbLogger for Logger.
        define buffer lbFilter for LogFilter.
        
        Assert:NotNull(poJson, 'JSON config').
        
        if poJson:Has(ConfigFileLoggerBuilder:PROP_DEFAULT_LOGGER) and poJson:GetType(ConfigFileLoggerBuilder:PROP_DEFAULT_LOGGER) eq JsonDataType:STRING then
            assign ConfigFileLoggerBuilder:DefaultLogger = poJson:GetCharacter(ConfigFileLoggerBuilder:PROP_DEFAULT_LOGGER).
        
        if poJson:Has(PROP_LOGGER) and poJson:GetType(PROP_LOGGER) eq JsonDataType:OBJECT then
        do:
            assign oConfig = poJson:GetJsonObject(PROP_LOGGER)
                   cNames  = oConfig:GetNames()
                   iMax    = extent(cNames)
                   .
            do iLoop = 1 to iMax:
                if not oConfig:GetType(cNames[iLoop]) eq JsonDataType:OBJECT then
                    next.
                
                // first in wins
                if can-find(lbLogger where lbLogger.LoggerName eq cNames[iLoop]) then
                    next.
                
                create lbLogger.
                assign oData               = oConfig:GetJsonObject(cNames[iLoop])
                       lbLogger.LoggerName = cNames[iLoop]
                       .
                if oData:Has(PROP_LEVEL) and oData:GetType(PROP_LEVEL) eq JsonDataType:STRING then
                    assign lbLogger.LogLevel = oData:GetCharacter(PROP_LEVEL).
                
                if oData:Has(PROP_FILTER_LIST) and oData:GetType(PROP_FILTER_LIST) eq JsonDataType:ARRAY then
                do:
                    assign oFilters  = oData:GetJsonArray(PROP_FILTER_LIST)
                           iInnerMax = oFilters:Length.
                    // there should be at least one, but if not, then this is a no-op logger (not even void)
                    do iInnerLoop = 1 to iInnerMax:
                         create lbFilter.
                         assign lbFilter.LoggerName = lbLogger.LoggerName
                                lbFilter.Order      = iInnerLoop
                                .
                         case oFilters:GetType(iInnerLoop):
                             when JsonDataType:OBJECT then
                             do:
                                 assign oData = oFilters:GetJsonObject(iInnerLoop)
                                        lbFilter.FilterOptions = oData
                                        lbFilter.FilterName    = oData:GetCharacter(PROP_NAME)
                                        .
                                // strip the filterName property from the options 
                                oData:Remove(PROP_NAME).
                             end.
                             when JsonDataType:STRING then
                                 assign lbFilter.FilterName = oFilters:GetCharacter(iInnerLoop).
                         end case.
                     end.
                end.
            end.
        end.
        
        // Register FORMAT filters
        if poJson:Has(PROP_FILTER_GROUP) and poJson:GetType(PROP_FILTER_GROUP) eq JsonDataType:OBJECT then
        do:
            assign oConfig = poJson:GetJsonObject(PROP_FILTER_GROUP)
                   extent(cNames) = ?
                   cNames  = oConfig:GetNames()
                   iMax    = extent(cNames)
                   .
            do iLoop = 1 to iMax:
                // this will give us the filter's type 
                assign resolvedType = GetABLType(oConfig, cNames[iLoop]).                    
                if valid-object(resolvedType) then
                    ConfigFileLoggerBuilder:Filters:Put(cNames[iLoop], resolvedType).
                
                // is there a builder for the filter?
                if oConfig:GetType(cNames[iLoop]) eq JsonDataType:OBJECT then
                do:
                    assign oData        = oConfig:GetJsonObject(cNames[iLoop])
                           resolvedType = GetABLType(oData, PROP_BUILDER)
                           .                    
                    if valid-object(resolvedType) then
                        ConfigFileLoggerBuilder:FilterBuilders:Put(cNames[iLoop], resolvedType).
                end.    // is an Object
           end.
       end.
    end method.
    
    /* Constructs the actual logger instance
       
       @return ILogWriter A new or cached logged */
    method override protected ILogWriter GetLoggerInstance():
        define variable logWriter as ILogWriter no-undo.
        define variable filter as ILoggerFilter no-undo.
        define variable filterList as LoggerFilterList no-undo.
        define variable logLevel as LogLevelEnum no-undo.
        define variable filterBuilder as LogFilterBuilder no-undo.
        define variable loggerOptions as JsonObject no-undo.
        
        define buffer lbLogger for Logger.
        define buffer lbFilter for LogFilter.

        // reload on every logger request. Will no-op if the file hasn't changed
        LoadFromFile(ConfigFileLoggerBuilder:CONFIG_FILE_NAME).
        
        if FindLogger(this-object:LoggerType, buffer lbLogger) then
        do:
            if HasOption(PROP_LEVEL) then
                assign logLevel = cast(GetOptionObjectValue(PROP_LEVEL), LogLevelEnum).
            
            if not valid-object(logLevel) then
                assign logLevel = FindLevel(lbLogger.LoggerName).
                                        
            assign filterList  = new LoggerFilterList().
            for each lbFilter where
                     lbFilter.LoggerName eq lbLogger.LoggerName
                     by lbFilter.Order:
                
                if ConfigFileLoggerBuilder:FilterBuilders:Has(lbFilter.FilterName) then
                    assign filterBuilder = LogFilterBuilder:Build(lbFilter.FilterName, ConfigFileLoggerBuilder:FilterBuilders).
                else
                    assign filterBuilder = LogFilterBuilder:Build(lbFilter.FilterName).
                
                if ConfigFileLoggerBuilder:Filters:Has(lbFilter.FilterName) then
                    filterBuilder:FromRegistry(ConfigFileLoggerBuilder:Filters).
                
                if valid-object(lbFilter.FilterOptions) then
                do:
                    assign loggerOptions = cast(lbFilter.FilterOptions, JsonObject).
                    
                    // Extract the filter options we know about
                    if     loggerOptions:Has(PROP_FILE_NAME) 
                       and loggerOptions:GetType(PROP_FILE_NAME) eq JsonDataType:STRING 
                       then
                        filterBuilder:WriteTo(loggerOptions:GetCharacter(PROP_FILE_NAME)).
                    
                    if     loggerOptions:Has(PROP_FORMAT_STRING) 
                       and loggerOptions:GetType(PROP_FORMAT_STRING) eq JsonDataType:STRING 
                       then
                        filterBuilder:FormatAs(loggerOptions:GetCharacter(PROP_FORMAT_STRING)).
                    
                    if     loggerOptions:Has(PROP_APPEND_LOG) 
                       and loggerOptions:GetType(PROP_APPEND_LOG) eq JsonDataType:BOOLEAN 
                       then
                        filterBuilder:Append(loggerOptions:GetLogical(PROP_APPEND_LOG)).
                    
                    // write all the options anyway, for those we don't know about
                    filterBuilder:Options(loggerOptions).
                end.
                
                assign filter = filterBuilder:Filter.
                if valid-object(filter) then
                    filterList:InsertLast(new LoggerFilterNode(filter)).
            end.
            
            // If there are no filters, this is a void logger
            if valid-object(filterList:First) then
                assign logWriter = new Logger(lbLogger.LoggerName, logLevel, filterList).
            else
                assign logWriter = new VoidLogger(lbLogger.LoggerName).
        end.
        else
            // if we don't have config for it, try the default (which is typically log-manager-based) 
            assign logWriter = super:GetLoggerInstance().
        
        return logWriter.
    end method.
    
    /* Finds the log level for a logger to use, based on the logger type
       
       Algorithm is
       1) exact match
       2) chop off the trailing .-delimited entry, repeating
       3) find the logger defined as DEFAULT_LOGGER, folling steps 1 & 2
       
       @param  character The logger type to find
       @return LogLevelEnum returns a log level , if any */
    method private LogLevelEnum FindLevel(input pcLoggerType as character):
        define variable logLevel as LogLevelEnum no-undo.
        define variable dotPos as integer no-undo.
        
        define buffer lbLogger for Logger.
        
        find lbLogger where
             lbLogger.LoggerName eq pcLoggerType
             no-error.
        if available lbLogger then
            assign logLevel = LogLevelEnum:GetEnum(lbLogger.LogLevel)
                   no-error.
        if valid-object(logLevel) then
            return logLevel.

        assign dotPos = r-index(pcLoggerType, '.':u).
        // if there's only one entry then we've checked already
        do while not valid-object(logLevel) and dotPos gt 0:
            assign pcLoggerType = substring(pcLoggerType, 1, dotPos - 1)
                   dotPos       = r-index(pcLoggerType, '.':u).
            find lbLogger where
                 lbLogger.LoggerName eq pcLoggerType
                 no-error.
            if available lbLogger then
                assign logLevel = LogLevelEnum:GetEnum(lbLogger.LogLevel)
                       no-error.
        end.
        
        if not valid-object(logLevel) 
           // don't loop forever
           and ConfigFileLoggerBuilder:DefaultLogger ne pcLoggerType then 
            assign logLevel = FindLevel(ConfigFileLoggerBuilder:DefaultLogger).
        
        if not valid-object(logLevel) then
            assign logLevel = LogLevelEnum:DEFAULT.
        
        return logLevel.
    end method.
    
    /* Returns a type name from a property we expect to have a type. Basically resolving the
       typeName / typeProperty values into an P.L.C 
          "definitions": {
            "typeName": {
              "type": "string",
              "description": "An OOABL type name",
              "pattern": "^[A-Za-z]+[A-Za-z$0-9-&#%.]+[A-Za-z$0-9-&#%]*$"
            },
            "typeProperty": {
              "type": "object",
              "properties": {
                "type": {"$ref": "#/definitions/typeName"},
                "hash": {
                  "type": "string",
                  "description": "A hash value to validate that the OOABL type is the expected version."
                }
              },
              "required": ["type"]
            },
            "builderProperty": {
              "oneOf": [
                {"$ref": "#/definitions/typeProperty"},
                {"$ref": "#/definitions/typeName"}
              ]
            }
          },
      
      @param JsonObject The JSON containign the type property
      @param character  The name of the propert
      @return P.L.Class A resolve ABL type name. May be unknown */
    method static private class Progress.Lang.Class GetABLType(input poParent as JsonObject,
                                                               input pcPropName as character):
        define variable typeName as character no-undo.
        define variable typeData as JsonObject no-undo.
        
        if    pcPropName eq '':u 
           or pcPropName eq ? 
           or not valid-object(poParent) then
            return ?.
        
        if poParent:Has(pcPropName) then
        do:
            case poParent:GetType(pcPropName):
                when JsonDataType:STRING then
                    assign typeName = poParent:GetCharacter(pcPropName).
                
                when JsonDataType:OBJECT then
                do:
                    assign typeData = poParent:GetJsonObject(pcPropName)
                           typeName = typeData:GetCharacter(PROP_TYPE)
                           .
                    if typeData:Has(PROP_HASH) and typeData:GetType(PROP_HASH) eq JsonDataType:STRING then
                        ValidateFilter(typeName, typeData:GetCharacter(PROP_HASH)).
                end.
                otherwise
                    assign typeName = ?.
            end case.
            
            if typeName ne ? then
                return Progress.Lang.Class:GetClass(typeName).
        end.
        
        return ?.
    end method.
    
    /* Find a temp-table record/config for a logger to use
       
       Algorithm is
       1) exact match
       2) chop off the trailing .-delimited entry, repeating
       3) find the logger defined as DEFAULT_LOGGER, following steps 1 & 2
       4) return a void logger (just to have a reference)
       
       @param  character The logger type to find
       @param  buffer A buffer reference to the logger temp-table
       @return logical TRUE if a logger record was found. If TRUE, the 
                       buffer will AVAILABLE; if false, not     */
    method private logical FindLogger(input pcLoggerType as character,
                                      buffer pbLogger for Logger):
        define variable dotPos as integer no-undo.
        
        find pbLogger where
             pbLogger.LoggerName eq pcLoggerType
             no-error.
        if available pbLogger then
            return true.
        
        // if there's only one entry then we've checked already
        assign dotPos = r-index(pcLoggerType, '.':u).
        do while dotPos gt 0:
            assign pcLoggerType = substring(pcLoggerType, 1, dotPos - 1)
                   dotPos       = r-index(pcLoggerType, '.':u).
            find pbLogger where
                 pbLogger.LoggerName eq pcLoggerType
                 no-error.
            if available pbLogger then
                return true.
        end.
        
        // don't recurse
        if ConfigFileLoggerBuilder:DefaultLogger ne pcLoggerType then
            return FindLogger(ConfigFileLoggerBuilder:DefaultLogger, buffer pbLogger).
            
        return false.
    end method.
    
    /* Ensures that a Filter type is the one we were expecting. 
        
       @param character (mandatory) The ABL Filter name used to process the event
       @param character (optional) A hash used to verify the Filter's authenticity
       @throws AppError If a hash is passed and the Filter type's hash does not match */
    method static private void ValidateFilter(input pcFilterType as character,
                                              input pcFilterHash as character ):
        if pcFilterHash eq '':u or pcFilterHash eq ? then
            return.
        
        Assert:NotNullOrEmpty(pcFilterType, 'Filter type').
        
        assign rcode-info:file-name = replace(pcFilterType, '.':u, '/':u).
        if rcode-info:md5-value ne pcFilterHash then
            return error new AppError(substitute('Filter error: invalid Filter &1', pcFilterType), 0).
    end method.
    
end class.
/************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : ILogWriter
    Purpose     : Interface for loggers (log writers)
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Tue Jun 07 16:09:44 EDT 2016
    Notes       : * Based on the slf4j.org Logger interface 
                    www.slf4j.org/api/org/slf4j/Logger.html
  ----------------------------------------------------------------------*/

using Ccs.Common.Support.ICharacterArrayHolder.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.LogMessage.

interface OpenEdge.Logging.ILogWriter:
    // (mandatory) Name for this logger
    define public property Name as character no-undo get.
    
    // (mandatory) The level being logged at
    define public property LogLevel as LogLevelEnum no-undo get.
    
/** FATAL **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Fatal(input pcMessage as character).
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Fatal(input pcMessageGroup as character,
                             input pcMessage as character).
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Fatal(input poMessage as LogMessage).

    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Fatal(input pcMessageGroup as character,
                             input pcMessage as character,
                             input poError as Progress.Lang.Error).

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Fatal(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error).
    
    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Fatal(input pcMessage as character,
                             input poError as Progress.Lang.Error).
    
/** ERROR **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Error(input pcMessage as character).
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Error(input pcMessageGroup as character,
                             input pcMessage as character).

    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Error(input poMessage as LogMessage).

    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Error(input pcMessageGroup as character,
                             input pcMessage as character,
                             input poError as Progress.Lang.Error).

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Error(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error).
    
    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Error(input pcMessage as character,
                             input poError as Progress.Lang.Error).
    
/** WARN **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Warn(input pcMessage as character).
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Warn(input pcMessageGroup as character,
                            input pcMessage as character).
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Warn(input poMessage as LogMessage).
        
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Warn(input pcMessageGroup as character,
                            input pcMessage as character,
                            input poError as Progress.Lang.Error).

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Warn(input poMessage as LogMessage,
                            input poError as Progress.Lang.Error).

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Warn(input pcMessage as character,
                            input poError as Progress.Lang.Error).
    
/** INFO **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Info(input pcMessage as character).
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Info(input pcMessageGroup as character,
                            input pcMessage as character).
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Info(input poMessage as LogMessage).
        
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Info(input pcMessageGroup as character,
                            input pcMessage as character,
                            input poError as Progress.Lang.Error).

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Info(input poMessage as LogMessage,
                            input poError as Progress.Lang.Error).
    
    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Info(input pcMessage as character,
                            input poError as Progress.Lang.Error).
    
/** DEBUG **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Debug(input pcMessage as character).
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Debug(input pcMessageGroup as character,
                             input pcMessage as character).
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Debug(input poMessage as LogMessage).

    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Debug(input pcMessageGroup as character,
                             input pcMessage as character,
                             input poError as Progress.Lang.Error).

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Debug(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error).

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Debug(input pcMessage as character,
                             input poError as Progress.Lang.Error).
    
/** TRACE **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Trace(input pcMessage as character).
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Trace(input pcMessageGroup as character,
                             input pcMessage as character).

    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Trace(input poMessage as LogMessage).

    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Trace(input pcMessageGroup as character,
                             input pcMessage as character,
                             input poError as Progress.Lang.Error).


    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Trace(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error).

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Trace(input pcMessage as character,
                             input poError as Progress.Lang.Error).

end interface.
/* *************************************************************************************************************************
Copyright (c) 2016 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : ISupportLogging
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-14
    Notes       : 
  ----------------------------------------------------------------------*/

using OpenEdge.Logging.ILogWriter.

interface OpenEdge.Logging.ISupportLogging:
    // A reference to the Logger in use by an implementer
    define public property Logger as ILogWriter no-undo get. set.
    
end interface.
/************************************************
Copyright (c) 2016-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LogEvent
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 16 14:03:05 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.StringConstant.
using OpenEdge.Logging.ILogWriter.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.LogMessage.

class OpenEdge.Logging.LogEvent serializable:
    // (optional) The logger that initiated this event
    define public property Logger as ILogWriter no-undo get. set.
    
    // (optional) The name of the logger
    define public property LoggerName as character no-undo get. set.
    
    // (mandatory) THe level of this event
    define public property LogLevel as LogLevelEnum no-undo get. private set.
    
    // The more-or-less exact time when the log event occurred 
    define public property TimeStamp as datetime-tz no-undo get. private set.
    
    // The log message
    define public property Message as LogMessage no-undo get. private set.
    
    // An error to log
    define public property Error as Progress.Lang.Error no-undo get. private set.
    
    // The current stack trace, of where the LOG event occurred. Not the error stack trace
    define public property CallStack as character extent no-undo get. private set.
    
    /* (optional) The user logging this event */
    define public property LoggedBy as handle no-undo get. set.
    
    /* (optional) The short-name of the logger logging this event. The short name is the logger name */
    define public property LoggerShortName as character no-undo get. set.
    
    /* (optional) The short-name-format of the logger logging this event */
    define public property ShortNameFormat as character no-undo get. set.
    
    /* Constructor
       
       @param LogLevelEnum The level this log event was at 
       @param LogMessage The message to log
       @param P.L.Error The error being logged
       @param datetime-tz The timestamp of the log event */
    constructor public LogEvent(input poLevel as LogLevelEnum, 
                                input poMessage as LogMessage,
                                input poError as Progress.Lang.Error,
                                input ptTimeStamp as datetime-tz):
        this-object(poLevel, poMessage, poError).
        
        assign this-object:TimeStamp = ptTimeStamp.
    end constructor.

    /* Constructor
       
       @param LogLevelEnum The level this log event was at
       @param LogMessage The message to log
       @param datetime-tz The timestamp of the log event */
    constructor public LogEvent(input poLevel as LogLevelEnum,
                                input poMessage as LogMessage,
                                input ptTimeStamp as datetime-tz):
        this-object(poLevel, poMessage).
        
        assign this-object:TimeStamp = ptTimeStamp.
    end constructor.
    
    /* Constructor
       
       @param LogLevelEnum The level this log event was at
       @param LogMessage The message to log
       @param P.L.Error The error being logged */
    constructor public LogEvent(input poLevel as LogLevelEnum,
                                input poMessage as LogMessage,
                                input poError as Progress.Lang.Error):
        this-object(poLevel, poMessage).
        
        assign this-object:Error = poError.
    end constructor.
                                        
    /* Constructor
       
       @param LogLevelEnum The level this log event was at
       @param LogMessage The message to log */
    constructor public LogEvent(input poLevel as LogLevelEnum,
                                input poMessage as LogMessage):
        if not valid-object(poMessage) then
            assign poMessage = new LogMessage('':u, '':u).
            
        if not valid-object(poLevel) then
            assign poLevel = LogLevelEnum:DEFAULT.
        
        assign this-object:Message   = poMessage
               this-object:TimeStamp = now
               this-object:LogLevel  = poLevel
               .
        BuildStack().
    end constructor.
    
    /* Destructor */
    destructor public LogEvent():
        if valid-handle(this-object:LoggedBy) then
            delete object this-object:LoggedBy no-error.
    end destructor.
    
    /* Builds the calls stack of the log event */
    method private character extent BuildStack():
        define variable iMax as integer no-undo.
        define variable iLoop as integer no-undo.
        define variable cStack as character no-undo.
        define variable cDelim as character no-undo.
        define variable cProgName as character no-undo.
        
        // we want the line that did the logging. If -debugalert is set, always show
        if not session:debug-alert
           and this-object:LogLevel lt LogLevelEnum:DEBUG 
           then
            assign iMax = 1.
        
        assign cDelim = '':u
               iLoop  = 1
               .
        do while program-name(iLoop) ne ?:
            assign cProgName = program-name(iLoop)
                   iLoop     = iLoop + 1
                   .
            // don't add the logging infrastructure to the log stack
            if num-entries(cProgName, StringConstant:SPACE) ge 2 then 
            case entry(2, cProgName, StringConstant:SPACE):
                when get-class(OpenEdge.Logging.Logger):TypeName or
                when this-object:GetClass():TypeName then
                    next.
            end case.
            
            assign cStack = cStack + cDelim + cProgName
                   cDelim = StringConstant:LF. 
            if iMax eq 1 then
                leave.
        end.
        
        if iMax eq 0 then
            assign iMax = num-entries(cStack, cDelim).
        
        assign extent(CallStack) = iMax.
        do iLoop = 1 to iMax:
            assign CallStack[iLoop] = entry(iLoop, cStack, StringConstant:LF).
        end.
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : LogFilterBuilderRegistry
    Purpose     : Registry for builders of filters
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-18
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Util.BuilderRegistry.
using OpenEdge.Logging.Filter.LogFilterBuilder.
using OpenEdge.Logging.LogFilterBuilderRegistry.
using OpenEdge.Logging.LoggerFilterRegistry.
using OpenEdge.Logging.Writer.FileLogWriterBuilder.

class OpenEdge.Logging.LogFilterBuilderRegistry:
    
    /** Registry for mapping build types to their implementations */
    define static public property Registry as BuilderRegistry no-undo
        get():
            define variable oRegistry as BuilderRegistry no-undo.
            if not valid-object(LogFilterBuilderRegistry:Registry) then
            do:
                assign oRegistry = new BuilderRegistry(get-class(LogFilterBuilder)).
                LogFilterBuilderRegistry:InitializeRegistry(oRegistry).                
                assign LogFilterBuilderRegistry:Registry = oRegistry.
            end.
            return LogFilterBuilderRegistry:Registry.
        end get.
        private set.
    
    /** Adds initial values into the registry 
        
        @param BuilderRegistry The registry to populate */
    method static private void InitializeRegistry(input poRegistry as BuilderRegistry):
        poRegistry:Put(LoggerFilterRegistry:LOG_MANAGER_WRITER, get-class(FileLogWriterBuilder)).
        poRegistry:Put(LoggerFilterRegistry:NAMED_FILE_WRITER,  get-class(FileLogWriterBuilder)).
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016-2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : Logger
    Purpose     : Public logger implementation
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-10
    Notes       : * This implementation is the only implementation of the ILogWriter.
                    It acts as a facade to a ILoggerImplementation which may be
                    a single type or a facade/decorator or filter chain.
                  * We don't want to throw any errors except from the constructor
  ----------------------------------------------------------------------*/
// NO THROW EVAH
//block-level on error undo, throw.

using OpenEdge.Logging.Filter.LoggerFilterList.
using OpenEdge.Logging.Format.ISupportFormatting.
using OpenEdge.Logging.ILogWriter.
using OpenEdge.Logging.LogEvent.
using OpenEdge.Logging.Logger.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.LogMessage.
using OpenEdge.Logging.TokenResolver.

class OpenEdge.Logging.Logger final implements ILogWriter, ISupportFormatting:
    // (mandatory) Holds filters for formatting the messagesto this logger
    define private variable moLogFilters as LoggerFilterList no-undo.
    
    // (mandatory) The level being logged at
    define public property LogLevel as LogLevelEnum no-undo get. private set. 
        
    // (mandatory) Name for this logger
    define public property Name as character no-undo get. private set.
    
    /* (optional) The short-name of this logger. The short name is the 
        logger name with the ShortNameFormat applied. This property is a cheat/optimisation
        to prevent having to re-calculate a formatted name */
    define protected property ShortName as character no-undo get. private set.
    
    /* (optional) The short-name-format of the logger logging this event. 
       See the TokenResolve class for more detail */ 
    define public property Format as character no-undo
        get. 
        set(input pFormat as character):
            if pFormat ne this-object:Format then
                assign this-object:Format    = pFormat
                       this-object:ShortName = TokenResolver:ResolveName(pFormat, this-object:Name)
                       .
        end set.
    
    /* Constructor
           
       @param character The name of this logger implementation
       @param LogLevelEnum The level we're logging at
       @param LoggerFilterList A list of filters to format and write the log data */
    constructor public Logger(input pcName as character,
                              input poLevel as LogLevelEnum,
                              input poLogFilters as LoggerFilterList):
        if not valid-object(poLevel) then
            assign poLevel = LogLevelEnum:DEFAULT.
            
        assign this-object:Name     = pcName
               this-object:Format   = '1C':u
               moLogFilters         = poLogFilters
               this-object:LogLevel = poLevel
               .
    end constructor.
    
/** FATAL **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Fatal(input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:FATAL then
            return.
        
        WriteMessage(LogLevelEnum:FATAL, new LogMessage(this-object:Name, pcMessage), ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Fatal(input pcMessageGroup as character,
                             input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:FATAL then
            return.
        
        WriteMessage(LogLevelEnum:FATAL, new LogMessage( pcMessageGroup, pcMessage), ?).
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Fatal(input poMessage as LogMessage):
        if this-object:LogLevel lt LogLevelEnum:FATAL then
            return.
        
        WriteMessage(LogLevelEnum:FATAL, poMessage, ?).
    end method.
        
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Fatal(input pcMessageGroup as character,
                             input pcMessage as character,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:FATAL then
            return.
        
        WriteMessage(LogLevelEnum:FATAL, new LogMessage(pcMessageGroup, pcMessage), poError).
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Fatal(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:FATAL then
            return.
        
        WriteMessage(LogLevelEnum:FATAL, poMessage, poError).
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Fatal(input pcMessage as character,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:FATAL then
            return.
        
        WriteMessage(LogLevelEnum:FATAL, new LogMessage(this-object:Name, pcMessage), poError).
    end method.

/** ERROR **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Error(input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:ERROR then
            return.
            
        WriteMessage(LogLevelEnum:ERROR, new LogMessage(this-object:Name, pcMessage), ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Error(input pcMessageGroup as character,
                             input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:ERROR then
            return.
            
        WriteMessage(LogLevelEnum:ERROR, new LogMessage(pcMessageGroup, pcMessage), ?).
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Error(input poMessage as LogMessage):
        if this-object:LogLevel lt LogLevelEnum:ERROR then
            return.
        
        WriteMessage(LogLevelEnum:ERROR, poMessage, ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Error(input pcMessageGroup as character,
                             input pcMessage as character,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:ERROR then
            return.
        
        WriteMessage(LogLevelEnum:ERROR, new LogMessage(pcMessageGroup, pcMessage), poError).
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Error(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:ERROR then
            return.
        
        WriteMessage(LogLevelEnum:ERROR, poMessage, poError).
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Error(input pcMessage as character,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:ERROR then
            return.
        
        WriteMessage(LogLevelEnum:ERROR, new LogMessage(this-object:Name, pcMessage), poError).
    end method.

/** WARN **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Warn(input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:WARN then
            return.
            
        WriteMessage(LogLevelEnum:WARN, new LogMessage(this-object:Name, pcMessage), ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Warn(input pcMessageGroup as character,
                             input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:WARN then
            return.
        
        WriteMessage(LogLevelEnum:WARN, new LogMessage(pcMessageGroup, pcMessage), ?).
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Warn(input poMessage as LogMessage):
        if this-object:LogLevel lt LogLevelEnum:WARN then
            return.
        
        WriteMessage(LogLevelEnum:WARN, poMessage, ?).
    end method.

    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Warn(input pcMessageGroup as character,
                            input pcMessage as character,
                            input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:WARN then
            return.
        
        WriteMessage(LogLevelEnum:WARN, new LogMessage(pcMessageGroup, pcMessage), poError).
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Warn(input poMessage as LogMessage,
                            input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:WARN then
            return.
        
        WriteMessage(LogLevelEnum:WARN, poMessage, poError).
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Warn(input pcMessage as character,
                            input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:WARN then
            return.
        
        WriteMessage(LogLevelEnum:WARN, new LogMessage(this-object:Name, pcMessage), poError).
    end method.

/** INFO **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Info(input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:INFO then
            return.
            
        WriteMessage(LogLevelEnum:INFO, new LogMessage(this-object:Name, pcMessage), ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Info(input pcMessageGroup as character,
                             input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:INFO then
            return.
            
        WriteMessage(LogLevelEnum:INFO, new LogMessage(pcMessageGroup, pcMessage), ?).
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Info(input poMessage as LogMessage):
        if this-object:LogLevel lt LogLevelEnum:INFO then
            return.
        
        WriteMessage(LogLevelEnum:INFO, poMessage, ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Info(input pcMessageGroup as character,
                            input pcMessage as character,
                            input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:INFO then
            return.
        
        WriteMessage(LogLevelEnum:INFO, new LogMessage(pcMessageGroup, pcMessage), poError).
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Info(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:INFO then
            return.
        
        WriteMessage(LogLevelEnum:INFO, poMessage, poError).
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Info(input pcMessage as character,
                            input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:INFO then
            return.
        
        WriteMessage(LogLevelEnum:INFO, new LogMessage(this-object:Name, pcMessage), poError).
    end method.
    
/** DEBUG **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Debug(input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:DEBUG then
            return.
            
        WriteMessage(LogLevelEnum:DEBUG, new LogMessage(this-object:Name, pcMessage), ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Debug(input pcMessageGroup as character,
                             input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:DEBUG then
            return.
            
        WriteMessage(LogLevelEnum:DEBUG, new LogMessage(pcMessageGroup, pcMessage), ?).
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Debug(input poMessage as LogMessage):
        if this-object:LogLevel lt LogLevelEnum:DEBUG then
            return.
        
        WriteMessage(LogLevelEnum:DEBUG, poMessage, ?).
    end method.

    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Debug(input pcMessageGroup as character,
                             input pcMessage as character,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:DEBUG then
            return.
        
        WriteMessage(LogLevelEnum:DEBUG, new LogMessage(pcMessageGroup, pcMessage), poError).
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Debug(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:DEBUG then
            return.
        
        WriteMessage(LogLevelEnum:DEBUG, poMessage, poError).
    end method.
               
    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Debug(input pcMessage as character,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:DEBUG then
            return.
        
        WriteMessage(LogLevelEnum:DEBUG, new LogMessage(this-object:Name, pcMessage), poError).
    end method.

/** TRACE **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Trace(input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:TRACE then
            return.
       
        WriteMessage(LogLevelEnum:TRACE, new LogMessage(this-object:Name, pcMessage), ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Trace(input pcMessageGroup as character,
                             input pcMessage as character):
        if this-object:LogLevel lt LogLevelEnum:TRACE then
            return.
        
        WriteMessage(LogLevelEnum:TRACE, new LogMessage(pcMessageGroup, pcMessage), ?).
    end method.
    
       /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Trace(input poMessage as LogMessage):
        if this-object:LogLevel lt LogLevelEnum:TRACE then
            return.
        
        WriteMessage(LogLevelEnum:TRACE, poMessage, ?).
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Trace(input pcMessageGroup as character,
                             input pcMessage as character,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:TRACE then
            return.
        
        WriteMessage(LogLevelEnum:TRACE, new LogMessage(pcMessageGroup, pcMessage), poError).
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Trace(input poMessage as LogMessage,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:TRACE then
            return.
        
        WriteMessage(LogLevelEnum:TRACE, poMessage, poError).
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Trace(input pcMessage as character,
                             input poError as Progress.Lang.Error):
        if this-object:LogLevel lt LogLevelEnum:TRACE then
            return.
        
        WriteMessage(LogLevelEnum:TRACE, new LogMessage(this-object:Name, pcMessage), poError).
    end method.
    
    /* Writes a log message
       
       @param LogMessage the message to be written */
    method private void WriteMessage(input poLogLevel as LogLevelEnum,
                                     input poMessage as LogMessage,
                                     input poError as Progress.Lang.Error):
        define variable oEvent as LogEvent no-undo.
        
        if valid-object(poError) then
            assign oEvent = new LogEvent(poLogLevel, poMessage, poError, now).
        else
            assign oEvent = new LogEvent(poLogLevel, poMessage, now).
        
        assign oEvent:Logger     = this-object
               
               oEvent:LoggerName      = this-object:Name
               oEvent:ShortNameFormat = this-object:Format
               oEvent:LoggerShortName = this-object:ShortName
               
               oEvent:LoggedBy = security-policy:get-client()
               .
        moLogFilters:ExecuteFilter(oEvent).
        
        catch oError as Progress.Lang.Error :
            // CATCH & SWALLOW. we can't have an error being logged so, yeah
        end catch.
    end method.

    /* Compares two instances
       
       Loggers are equal iff
       - they have the same obejct reference ('handle'), or
       - they are both instances of OpenEdge.Logging.Logger and
         the Name property value is identical on both (= match)
       
       @param P.L.Object
       @return logical TRUE if these are the same logger object */
    method override public logical Equals( input poRef as Progress.Lang.Object ):
        if super:Equals(poRef) then
            return true.
          
        if not type-of(poRef, Logger) then
            return false.
        
        return (cast(poRef, Logger):Name eq this-object:Name).             
    end method.
    
end class./************************************************
Copyright (c) 2016-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LoggerBuilder
    Purpose     : A factory for creating loggers
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 16 21:43:11 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.ISupportInitialize.
using OpenEdge.Core.StringConstant.
using OpenEdge.Core.Util.BuilderRegistry.
using OpenEdge.Core.Util.ConfigBuilder.
using OpenEdge.Logging.ConfigFileLoggerBuilder.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.Filter.LogFilterBuilder.
using OpenEdge.Logging.Filter.LoggerFilterList.
using OpenEdge.Logging.Filter.LoggerFilterNode.
using OpenEdge.Logging.ILogWriter.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.Logger.
using OpenEdge.Logging.LoggerBuilder.
using OpenEdge.Logging.LoggerFilterRegistry.
using OpenEdge.Logging.VoidLogger.

class OpenEdge.Logging.LoggerBuilder inherits ConfigBuilder:
    /* Private variable with the enum (int64) vaues in the OpenEdge.Logging.LogLevelEnum type. Used
       when we get the default log-manager-based logger */
    define static private variable mLogLevels as character no-undo.
    
    /* Holds the maximum log level in the OpenEdge.Logging.LogLevelEnum type. Used
       when we get the default log-manager-based logger*/
    define static private variable mMaxLogLevel as int64 no-undo.
    
    /* returns a logger instance */
    define public property Logger as ILogWriter no-undo 
        get():
            return GetLoggerInstance(). 
        end get.
    
    /* (mandatory) The logger type that we want to build */ 
    define public property LoggerType as character no-undo get. private set.
    
    /* The name of the default logger to use in the GetLogger() method. */
    define static public property DefaultLogger as character no-undo get. set.
    
    /** Registry for mapping builder types to their implementations
        
        This is the registry of LoggerBuilders */
    define static public property Registry as BuilderRegistry no-undo
        get():
            if not valid-object(LoggerBuilder:Registry) then
            do:
                assign LoggerBuilder:Registry = new BuilderRegistry(get-class(LoggerBuilder)).
                // Use the config file as a default (with a 'name' of *) 
                LoggerBuilder:Registry:Put('*':u, get-class(ConfigFileLoggerBuilder)).
            end.
            
            return LoggerBuilder:Registry.
        end get.
        private set.
    
    /* Static constructor */
    constructor static LoggerBuilder():
        define variable cnt as integer no-undo.
        
        assign mLogLevels   = get-class(LogLevelEnum):GetEnumValues()
               mMaxLogLevel = 0
               .
        do cnt = num-entries(mLogLevels) to 1 by -1:
            assign mMaxLogLevel = max(mMaxLogLevel, int64(entry(cnt, mLogLevels))).
        end.
    end constructor.
    
    /* Constructor
       
       @param character The logger type being built */
    constructor public LoggerBuilder (input pcLoggerType as character):
        Assert:NotNull(pcLoggerType, 'Logger type').
        assign this-object:LoggerType = pcLoggerType.
    end method.
    
    /** Returns a logger (ILogWriter). 
        
        @param P.L.Class The typename for which to find a logger
        @return ILogWriter An instance of the default logger */
    method static public ILogWriter GetLogger(input poLoggerType as class Progress.Lang.Class):
        Assert:NotNull(poLoggerType, 'Logger type':u).
        
        return LoggerBuilder:Build(poLoggerType:TypeName):Logger.
    end method.
    
    /** Returns a logger (ILogWriter). 
        
        @param handle The procedure for which to find a logger
        @return ILogWriter An instance of the default logger */
    method static public ILogWriter GetLogger(input pLoggerType as handle):
        define variable loggerName as character no-undo.
        
        if    valid-handle(pLoggerType)
           and can-query(pLoggerType, 'FILE-NAME':U)
           then
            assign loggerName = replace(pLoggerType:file-name,'/':u, '.':u)
                   loggerName = replace(loggerName, StringConstant:BACKSLASH, '.':u)
                   loggerName = substring(loggerName, 1, r-index(loggerName, '.':u) - 1)
                   .
        else
            assign loggerName = LoggerBuilder:DefaultLogger.
        
        return LoggerBuilder:Build(loggerName):Logger.
    end method.
    
    /** Returns a logger (ILogWriter)
        
        @param character The logger name 
        @return ILogWriter An instance of the default logger */
    method static public ILogWriter GetLogger(input pcLoggerType as character):
        if pcLoggerType eq '':u or pcLoggerType eq ? then
            assign pcLoggerType = LoggerBuilder:DefaultLogger.
        
        return LoggerBuilder:Build(pcLoggerType):Logger.
    end method.
    
    /* Returns a builder for a logger
        
       @param character The logger type
       @param  BuilderRegistry A registry of Filter writers to user
       @return LoggerBuilder A builder for that logger */
    method static public LoggerBuilder Build(input pcLoggerType as character,
                                             input poBuilders as BuilderRegistry):
        define variable builder as LoggerBuilder no-undo.
        define variable builderType as Progress.Lang.Class no-undo.
        define variable dotPos as integer no-undo.
        define variable searchLogger as character no-undo.
        
        Assert:NotNull(pcLoggerType, 'Logger type').
        if valid-object(poBuilders) then
        do:
            Assert:NotNull(poBuilders, 'Logger builder registry').
            Assert:IsType(poBuilders:ValueType, get-class(LoggerBuilder)).
            
            assign builderType = poBuilders:Get(pcLoggerType).
            if not valid-object(builderType) then
                assign dotPos       = r-index(pcLoggerType, '.':u)
                       searchLogger = pcLoggerType
                       .
            // if there's only one entry then we've checked already    
            do while not valid-object(builderType) and dotPos gt 0:
                assign searchLogger = substring(searchLogger, 1, dotPos - 1)
                       dotPos       = r-index(searchLogger, '.':u)
                       builderType  = poBuilders:Get(searchLogger)
                       .
            end.
            // search for the default '*' value
            if not valid-object(builderType) then
                assign builderType = poBuilders:Get('*':u).
        end.
        
        // default is this class
        if not valid-object(builderType) then
            assign builderType = get-class(LoggerBuilder).
        
        builder = dynamic-new string(builderType:TypeName) (pcLoggerType).
        
        if type-of(builder, ISupportInitialize) then
            cast(builder, ISupportInitialize):Initialize().
        
        return builder.
    end method.
    
    /* Returns a builder for a logger
       
       @param character The logger type
       @return LoggerBuilder A builder for that logger */
    method static public LoggerBuilder Build(input pcLoggerType as character):
        return LoggerBuilder:Build(pcLoggerType, LoggerBuilder:Registry).
    end method.
    
    /* Sets the log level for this logger.
       
       @param  LogLevelEnum the level to log at  
       @return LoggerBuilder This builder object  */
    method public LoggerBuilder LogAt(input poLevel as LogLevelEnum):
        Assert:NotNull(poLevel, 'Log level').
        
        SetOption('logLevel':u, poLevel).
        
        return this-object.
    end method.
    
    /* Adds a filter to the logger being built
       
       @param  character The filter name to add  
       @return LoggerBuilder This builder object  */
    method public LoggerBuilder AddFilter(input pcFilterName as character):
        Assert:NotNullOrEmpty(pcFilterName, 'Log filter name').
        
        AppendArrayCharacterValue('filterName':u, pcFilterName).
                        
        return this-object.
    end method.
        
    /* Constructs the actual logger instance
       
       @return ILogWriter A new or cached logged */
    method protected ILogWriter GetLoggerInstance():
        define variable logWriter as ILogWriter no-undo.
        define variable logAt as LogLevelEnum no-undo.
        
        if log-manager:logfile-name ne ? then
        do:
            // use the specified/configured value first 
            if not HasOption('logLevel':u) then
            do:
                if log-manager:logging-level gt mMaxLogLevel then
                    assign logAt = LogLevelEnum:GetEnum(mMaxLogLevel).
                else
                if lookup(string(log-manager:logging-level), mLogLevels) gt 0 then
                    assign logAt = LogLevelEnum:GetEnum(log-manager:logging-level).
                else
                    assign logAt = LogLevelEnum:DEFAULT.
                
                LogAt(logAt).
            end.
            
            // If the debug-alert flag is set, then write the log stack
            if session:debug-alert then
                AddFilter(LoggerFilterRegistry:STACK_WRITER_FORMAT).
            
            AddFilter(LoggerFilterRegistry:ABL_SUBSTITUTE_FORMAT).
            AddFilter(LoggerFilterRegistry:ERROR_FORMAT).
            AddFilter(LoggerFilterRegistry:LOG_MANAGER_FORMAT).
            AddFilter(LoggerFilterRegistry:LOG_MANAGER_WRITER).
        end.
        
        if HasOption('filterName':u) then
            assign logWriter = BuildFilterLogger(). 
        
        if not valid-object(logWriter) then 
            assign logWriter = new VoidLogger(this-object:LoggerType).
        
        return logWriter.
    end method.
    
    /* Creates a default logger based that uses the config in this class
       
       @return ILogWriter A logger */
    method protected ILogWriter BuildFilterLogger():
        define variable filterList as LoggerFilterList no-undo.
        define variable filter as ILoggerFilter no-undo.
        define variable logLevel as LogLevelEnum no-undo.
        define variable filterNames as character extent no-undo.
        define variable loop as integer no-undo.
        define variable numFilters as integer no-undo.
        
        if not HasOption('filterName':u) then
            return ?.
        
        // get the logging level. first check for a set option, then derive it
        if HasOption('logLevel':u) then
            assign logLevel = cast(GetOptionObjectValue('logLevel':u), LogLevelEnum).
        if not valid-object(logLevel) then
            assign logLevel = LogLevelEnum:DEFAULT.
        
        assign filterList  = new LoggerFilterList()
               filterNames = GetOptionStringArrayValue('filterName':u)
               numFilters  = extent(filterNames)
               .
        if    numFilters eq 0 
           or numFilters eq ? then
            return ?.
        
        do loop = 1 to numFilters:
            assign filter = LogFilterBuilder:Build(filterNames[loop])
                                :Filter.
            filterList:InsertLast(new LoggerFilterNode(filter)).
        end.
        
        return new OpenEdge.Logging.Logger(this-object:LoggerType, logLevel, filterList).
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : LoggerFilterRegistry
    Purpose     : Registry for types that hold log writers
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-14
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Util.BuilderRegistry.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.Format.ABLSubstituteFormat.
using OpenEdge.Logging.Format.ErrorFormat.
using OpenEdge.Logging.Format.FullTextFormat.
using OpenEdge.Logging.Format.LogManagerFormat.
using OpenEdge.Logging.Format.ResolvedTokenFormat.
using OpenEdge.Logging.Format.StackWriterFormat.
using OpenEdge.Logging.LoggerFilterRegistry.
using OpenEdge.Logging.Writer.LogManagerWriter.
using OpenEdge.Logging.Writer.MessageStatementWriter.
using OpenEdge.Logging.Writer.NamedFileWriter.
using OpenEdge.Logging.Writer.VoidWriter.

class OpenEdge.Logging.LoggerFilterRegistry:
    // Key for log manager logger implementations
    define static public property LOG_MANAGER_WRITER as character initial 'LOG_MANAGER_WRITER':u no-undo get.
    define static public property NAMED_FILE_WRITER  as character initial 'NAMED_FILE_WRITER':u  no-undo get.
    define static public property VOID_WRITER        as character initial 'VOID_WRITER':u        no-undo get.
    define static public property DEFAULT_WRITER     as character initial 'DEFAULT_WRITER':u     no-undo get.
    define static public property MSG_STMT_WRITER    as character initial 'MSG_STMT_WRITER':u    no-undo get.    
    
    // Default filter configs    
    define static public property ABL_SUBSTITUTE_FORMAT as character initial 'ABL_SUBSTITUTE_FORMAT':u  no-undo get.
    define static public property LOG_MANAGER_FORMAT    as character initial 'LOG_MANAGER_FORMAT':u     no-undo get.
    define static public property STACK_WRITER_FORMAT   as character initial 'STACK_WRITER_FORMAT':u    no-undo get.
    define static public property FULL_TEXT_FORMAT      as character initial 'FULL_TEXT_FORMAT':u       no-undo get.
    define static public property ERROR_FORMAT          as character initial 'ERROR_FORMAT':u           no-undo get.
    define static public property TOKEN_FORMAT          as character initial 'TOKEN_FORMAT':u           no-undo get.
    
    /** Registry for mapping build types to their implementations */
    define static public property Registry as BuilderRegistry no-undo
        get():
            define variable oRegistry as BuilderRegistry no-undo.
            if not valid-object(LoggerFilterRegistry:Registry) then
            do:
                assign oRegistry = new BuilderRegistry(get-class(ILoggerFilter)).
                LoggerFilterRegistry:InitializeRegistry(oRegistry).                
                assign LoggerFilterRegistry:Registry = oRegistry.
            end.
            return LoggerFilterRegistry:Registry.
        end get.
        private set.
    
    /** Adds initial values into the registry 
        
        @param BuilderRegistry The registry to populate */
    method static private void InitializeRegistry(input poRegistry as BuilderRegistry):
        // WRITERS
        poRegistry:Put(LOG_MANAGER_WRITER, get-class(LogManagerWriter)).
        poRegistry:Put(NAMED_FILE_WRITER,  get-class(NamedFileWriter)).
        poRegistry:Put(VOID_WRITER,        get-class(VoidWriter)).
        poRegistry:Put(MSG_STMT_WRITER,    get-class(MessageStatementWriter)).
        
        // Default to LOG-MANAGER for appservers 
        case session:client-type:
            when 'APPSERVER':u or
            when 'MULTI-SESSION-AGENT':u or
            when 'WEBSPEED':u then
                poRegistry:Put(DEFAULT_WRITER, get-class(LogManagerWriter)).
            otherwise
                poRegistry:Put(DEFAULT_WRITER, get-class(VoidWriter)).
        end case.
        
        // FORMATS
        poRegistry:Put(ABL_SUBSTITUTE_FORMAT,   get-class(ABLSubstituteFormat)).
        poRegistry:Put(LOG_MANAGER_FORMAT,      get-class(LogManagerFormat)).
        poRegistry:Put(FULL_TEXT_FORMAT,        get-class(FullTextFormat)).
        poRegistry:Put(STACK_WRITER_FORMAT,     get-class(StackWriterFormat)).
        poRegistry:Put(ERROR_FORMAT,            get-class(ErrorFormat)).
        poRegistry:Put(TOKEN_FORMAT,            get-class(ResolvedTokenFormat)).
        
    end method.
    
end class.
{
  "DEFAULT_LOGGER": "OpenEdge",
  "logger": {
    "OpenEdge": {
      "logLevel": "OFF",
      "filters": ["VOID_WRITER"]
    },
    "OpenEdge.Web.DataObject.DataObjectHandler": {
      "logLevel": "WARN",
      "filters": [
        "ABL_SUBSTITITE_FORMAT",
        "ERROR_FORMAT",
        "LOG_MANAGER_FORMAT",
        {
          "filterName": "LOG_MANAGER_WRITER",
          "fileName": "",
          "appendTo": true
        }
      ]
    }
  }
}{
  "$schema": "http://json-schema.org/draft-04/schema#",
  "description": "Schema for OpenEdge.Logging.ConfigFileLoggerBuilder configuration, v. 1.0.0",
  "definitions": {
    "typeName": {
      "type": "string",
      "description": "An OOABL type name",
      "pattern": "^[A-Za-z]+[A-Za-z$0-9-&#%.]+[A-Za-z$0-9-&#%]*$"
    },
    "typeProperty": {
      "type": "object",
      "properties": {
        "type": {"$ref": "#/definitions/typeName"},
        "hash": {
          "type": "string",
          "description": "A hash value to validate that the OOABL type is the expected version."
        }
      },
      "required": ["type"]
    },
    "builderProperty": {
      "oneOf": [
        {"$ref": "#/definitions/typeProperty"},
        {"$ref": "#/definitions/typeName"}
      ]
    }
  },
  "DEFAULT_LOGGER": {"type": "string"},
  "logger": {
    "type": "object",
    "patternProperties": {
      "^[A-Za-z]+[A-Za-z$0-9-&#%.]+[A-Za-z$0-9-&#%]*$": {
        "type": "object",
        "properties": {
          "logLevel": {
            "type": "string",
            "enum": [
              "OFF",
              "FATAL",
              "ERROR",
              "WARN",
              "INFO",
              "DEBUG",
              "TRACE",
              "DEFAULT"
            ]
          },
          "filters": {
            "type": "array",
            "minItems": 1,
            "items": {
              "oneOf": [
                {"type": "string",
                  "description": "A filterName reference to a in-the-box or registered filter, or an entry in the filters property in this config"
                },
                {
                  "type": "object",
                  "properties": {
                    "name": {"type": "string"},
                    "format": {
                        "type": "string",
                        "description": "A string to format that the filter uses to format the message (or part thereof)"
                    }
                  },
                  "required": ["name"]
                }
              ]
            }
          },
          "required": ["filters"]
        }
      }
    }
  },
  "filter": {
    "type": "object",
    "patternProperties": {
      "^[A-Za-z]+[A-Za-z$0-9-&#%.]+[A-Za-z$0-9-&#%]*$": {
        "type": "object",
        "properties": {
          "oneOf": [
            {
              "$ref": "#/definitions/typeName",
              "description": "The OOABL type name that implements this filter. Must implement OpenEdge.Logging.Filter.ILoggerFilter"
            },
            {
              "allOf": [
                {
                  "$ref": "#/definitions/typeProperty",
                  "description": "The OOABL type name that implements this filter. Must implement OpenEdge.Logging.Filter.ILoggerFilter"
                },
                {
                  "properties": {
                    "builder": {
                      "$ref": "#/definitions/builderProperty",
                      "description": "The OOABL type name that can build this filter. Must inherit from OpenEdge.Logging.Filter.LogFilterBuilder"
                    }
                  }
                }
              ]
            }
          ]
        }
      }
    }
  }
}/************************************************
  Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LogLevelEnum
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Feb 24 10:00:26 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

enum OpenEdge.Logging.LogLevelEnum:
    define enum     // The highest possible rank and is intended to turn off logging.
                    OFF = 0 

                    // Severe errors that cause premature termination. Expect these to be immediately visible on a status console.
                    FATAL

                    // Other runtime errors or unexpected conditions. Expect these to be immediately visible on a status console.
                    ERROR
                    
                    // Use of deprecated APIs, poor use of API, 'almost' errors, other runtime situations that are undesirable 
                    // or unexpected, but not necessarily "wrong". Expect these to be immediately visible on a status console.
                    WARN   

                    // Interesting runtime events (startup/shutdown). Expect these to be immediately visible on a console, 
                    // so be conservative and keep to a minimum.
                    INFO

                    // Detailed information on the flow through the system. Expect these to be written to logs only.
                    DEBUG

                    // Most detailed information. Expect these to be written to logs only.
                    TRACE
                    
                    DEFAULT = WARN
                .
end enum.
/************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : LogMessage
    Purpose     : A data container/value object for a message to be logged, including
                  substitution args 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 16 12:01:34 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

class OpenEdge.Logging.LogMessage serializable:
    // (mandatory) The group for this log message 
    define public property GroupName as character no-undo get. private set.
    
    // (mandatory) The base text of the message. May contain substitution parameters like &1 or {}
    define public property BaseText as character no-undo get. private set.
    
    // (optional) An array of values to substitute into the base text
    define public property Arguments as character extent no-undo get. private set.
    
    // (mutable) The formatted message for writing to the logger target
    define public property Message as character no-undo get. set.
    
    /* Constructor
       
       @param character The message group
       @param character the message text */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessage as character):
        assign this-object:GroupName = pcGroup
               this-object:BaseText  = pcMessage
               this-object:Message   = pcMessage
               .
    end constructor.

    /* Constructor
       
       @param character The message group
       @param character the message text */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArgs as character extent):
        this-object(pcGroup, pcMessageBase).
        
        assign this-object:Arguments = pcArgs.
    end method.

    /* Constructor
       
       @param character The message group
       @param character The message base text 
       @param character The first argument  */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character     ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 1
               this-object:Arguments[1] = pcArg1
               .
    end method.
    
    /* Constructor
       
       
       @param character The message group
       @param character The message base text 
       @param character The first argument 
       @param character The second argument   */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character,
                                  input pcArg2 as character     ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 2
               this-object:Arguments[1] = pcArg1
               this-object:Arguments[2] = pcArg2
               .
    end method.
    
    /* Constructor
       
       @param character The message group
       @param character The message base text 
       @param character The first argument 
       @param character The second argument
       @param character The third argument   */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character,
                                  input pcArg2 as character,
                                  input pcArg3 as character     ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 3
               this-object:Arguments[1] = pcArg1
               this-object:Arguments[2] = pcArg2
               this-object:Arguments[3] = pcArg3
               .
    end method.
    
    /* Constructor
       
       @param character The message group
       @param character The message base text 
       @param character The first argument 
       @param character The second argument
       @param character The third argument
       @param character The fourth argument  */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character,
                                  input pcArg2 as character,
                                  input pcArg3 as character,
                                  input pcArg4 as character     ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 4
               this-object:Arguments[1] = pcArg1
               this-object:Arguments[2] = pcArg2
               this-object:Arguments[3] = pcArg3
               this-object:Arguments[4] = pcArg4
               .
    end method.
    
    /* Constructor
       
       @param character The message group
       @param character The message base text 
       @param character The first argument 
       @param character The second argument
       @param character The third argument
       @param character The fourth argument
       @param character The fifth argument */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character,
                                  input pcArg2 as character,
                                  input pcArg3 as character,
                                  input pcArg4 as character,
                                  input pcArg5 as character  ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 5
               this-object:Arguments[1] = pcArg1
               this-object:Arguments[2] = pcArg2
               this-object:Arguments[3] = pcArg3
               this-object:Arguments[4] = pcArg4
               this-object:Arguments[5] = pcArg5
               .
    end method.
    
    /* Constructor
       
       @param character The message group
       @param character The message base text 
       @param character The first argument 
       @param character The second argument
       @param character The third argument
       @param character The fourth argument
       @param character The fifth argument
       @param character The sixth argument  */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character,
                                  input pcArg2 as character,
                                  input pcArg3 as character,
                                  input pcArg4 as character,
                                  input pcArg5 as character,
                                  input pcArg6 as character     ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 6
               this-object:Arguments[1] = pcArg1
               this-object:Arguments[2] = pcArg2
               this-object:Arguments[3] = pcArg3
               this-object:Arguments[4] = pcArg4
               this-object:Arguments[5] = pcArg5
               this-object:Arguments[6] = pcArg6
               .
    end method.
    
    /* Constructor
       
       @param character The message group
       @param character The message base text 
       @param character The first argument 
       @param character The second argument
       @param character The third argument
       @param character The fourth argument
       @param character The fifth argument
       @param character The sixth argument
       @param character The seventh argument */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character,
                                  input pcArg2 as character,
                                  input pcArg3 as character,
                                  input pcArg4 as character,
                                  input pcArg5 as character,
                                  input pcArg6 as character,
                                  input pcArg7 as character       ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 7
               this-object:Arguments[1] = pcArg1
               this-object:Arguments[2] = pcArg2
               this-object:Arguments[3] = pcArg3
               this-object:Arguments[4] = pcArg4
               this-object:Arguments[5] = pcArg5
               this-object:Arguments[6] = pcArg6
               this-object:Arguments[7] = pcArg7
               .
    end method.
    
    /* Constructor
       
       @param character The message group
       @param character The message base text 
       @param character The first argument 
       @param character The second argument
       @param character The third argument
       @param character The fourth argument
       @param character The fifth argument
       @param character The sixth argument
       @param character The seventh argument
       @param character The eighth argument  */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character,
                                  input pcArg2 as character,
                                  input pcArg3 as character,
                                  input pcArg4 as character,
                                  input pcArg5 as character,
                                  input pcArg6 as character,
                                  input pcArg7 as character,
                                  input pcArg8 as character     ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 8
               this-object:Arguments[1] = pcArg1
               this-object:Arguments[2] = pcArg2
               this-object:Arguments[3] = pcArg3
               this-object:Arguments[4] = pcArg4
               this-object:Arguments[5] = pcArg5
               this-object:Arguments[6] = pcArg6
               this-object:Arguments[7] = pcArg7
               this-object:Arguments[8] = pcArg8
               .
    end method.
    
    /* Constructor
       
       @param character The message group
       @param character The message base text 
       @param character The first argument 
       @param character The second argument
       @param character The third argument
       @param character The fourth argument
       @param character The fifth argument
       @param character The sixth argument
       @param character The seventh argument
       @param character The eighth argument
       @param character The ninth argument  */
    constructor public LogMessage(input pcGroup as character,
                                  input pcMessageBase as character,
                                  input pcArg1 as character,
                                  input pcArg2 as character,
                                  input pcArg3 as character,
                                  input pcArg4 as character,
                                  input pcArg5 as character,
                                  input pcArg6 as character,
                                  input pcArg7 as character,
                                  input pcArg8 as character,
                                  input pcArg9 as character     ):
        this-object(pcGroup, pcMessageBase).
        
        assign extent(this-object:Arguments) = 9
               this-object:Arguments[1] = pcArg1
               this-object:Arguments[2] = pcArg2
               this-object:Arguments[3] = pcArg3
               this-object:Arguments[4] = pcArg4
               this-object:Arguments[5] = pcArg5
               this-object:Arguments[6] = pcArg6
               this-object:Arguments[7] = pcArg7
               this-object:Arguments[8] = pcArg8
               this-object:Arguments[9] = pcArg9
               .
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016-2018 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : TokenResolver
    Purpose     : Resolves certain known token names into useful values.
                  Wraps calls to the OpenEdge.Core.Util.TokenResolver
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 16 13:02:52 EST 2016
    Notes       : 
 ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.TokenResolverEventArgs.
using OpenEdge.Logging.TokenResolver.

class OpenEdge.Logging.TokenResolver:
    
    /* Event published after a token is resolved by this resolver. Allows a listener to override the value */
    define static public event TokenResolved signature void (input pSender as Progress.Lang.Object,
                                                             input pArgs as TokenResolverEventArgs). 
    
    /* Resolves a NAME-based token arg, based on the type/logger name given
       
       @param character  The token argument for ${NAME.*} tokens
       @param character  The (type) name to resolve
       @return character The resolved string  */
    method static public character ResolveName(input pTokenArg  as character,
                                               input pName as character):
        return OpenEdge.Core.Util.TokenResolver:ResolveName(pTokenArg, pName).
    end method.
    
    /* Resolves a time-based token arg, based on the timestamp given
       
       @param character   The token argument for ${T.*} tokens
       @param datetime-tz The timestamp to use to resolve the token
       @return character  The resolved string */
    method static public character ResolveTime(input pTokenArg  as character,
                                               input pTimestamp as datetime-tz):
        return OpenEdge.Core.Util.TokenResolver:ResolveTime(pTokenArg, pTimestamp).
    end method.
    
    /* Resolves a time-based token arg, based on the timestamp given
       
       @param character     The token argument for ${T.*} tokens
       @param character[12] The long-form month names (ie January)
       @param character[12] The short-form month names (ie Jan)
       @param character[7]  The long-form weekday names (ie Thursday)
       @param character[7]  The short-form weekday names (ie Thurs)
       @param datetime-tz   The timestamp to use to resolve the token
       @return character    The resolved string */
    method static public character ResolveTime(input pTokenArg  as character,
                                               input pMonthLong as character extent 12,
                                               input pMonthShort as character extent 12,
                                               input pWeekdayLong as character extent 7,
                                               input pWeekdayShort as character extent 7,
                                               input pTimestamp as datetime-tz ):
        return OpenEdge.Core.Util.TokenResolver:ResolveTime(pTokenArg,
                                                            pMonthLong,
                                                            pMonthShort,
                                                            pWeekdayLong,
                                                            pWeekdayShort,
                                                            pTimestamp).
    end method.
    
    /* Resolves a CP-based token arg, based on the client-principal.
       
       It is the CALLER's responsibility to clean up the C-P object represented by this handle
       
       @param character The token argument for ${CP.*} tokens
       @param handle     A user represented by a client-principal 
       @return character The resolved string  */
    method static public character ResolveUser(input pTokenArg as character,
                                               input pUser as handle):
        return OpenEdge.Core.Util.TokenResolver:ResolveUser(pTokenArg, pUser).
    end method.
    
    /* Resolves any tokens in the file name into appropriate values
       
       @param character The source string
       @return character The resolved string */
    method static public character Resolve(input pcBaseString as character):
        OpenEdge.Core.Util.TokenResolver:TokenResolved:Subscribe(TokenResolvedHandler).
        
        return OpenEdge.Core.Util.TokenResolver:Resolve(pcBaseString).
        finally:
            OpenEdge.Core.Util.TokenResolver:TokenResolved:Unsubscribe(TokenResolvedHandler).
        end finally.
    end method.
    
    /* Callback to handle token replacement 
       
       @param Object The sender
       @param OpenEdge.Core.Util.TokenResolverEventArgs The token resolution args  */
    method static public void TokenResolvedHandler (input pSender as Progress.Lang.Object,
                                                    input pArgs as OpenEdge.Core.Util.TokenResolverEventArgs):
        define variable loggingArgs as TokenResolverEventArgs no-undo.
        
        assign loggingArgs             = new TokenResolverEventArgs(pArgs:TokenGroup, pArgs:TokenArg, pArgs:TokenValue)
               loggingArgs:SourceValue = pArgs:SourceValue
               .    
        OpenEdge.Logging.TokenResolver:TokenResolved:Publish(get-class(OpenEdge.Logging.TokenResolver), loggingArgs).
        
        // Set the values for the originating event arg 
        assign pArgs:TokenValue  = loggingArgs:TokenValue
               pArgs:SourceValue = loggingArgs:SourceValue
               .
    end method.
    
end class.
/************************************************
Copyright (c) 2017-2018 by Progress Software Corporation. All rights reserved.
*************************************************/
 /*------------------------------------------------------------------------
    File        : TokenResolverEventArgs
    Purpose     : Arguments for events published when an individual token is resolved.
                  Wraps the general OpenEdge.Core.Util.TokenResolverEventArgs 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2017-02-15
    Notes       : * See OE.Core.Util.TokenResolver for info about the type and args
                  * Token substitutions are allowed for file names
                    the token format is ${<token>}, where
                        token = group "." arg
                    groups = session | env | guid | t[ime] | web | ver[sion]
                             cp | req[uest] | name 
                    
                    If a token cannot be resovled, or resolves to a value of
                    ? (unknown) then the token name is used.   
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.EventArgs.
using OpenEdge.Core.Assert.

class OpenEdge.Logging.TokenResolverEventArgs inherits OpenEdge.Core.Util.TokenResolverEventArgs :
    /* Constructor
       
       @param character The base token (mandatory) */
    constructor public TokenResolverEventArgs(input pToken as character):
        super(pToken).
    end constructor.
    
    /* Constructor
       
       @param character The token group (mandatory)
       @param character The token arguments (if any) */
    constructor public TokenResolverEventArgs(input pGroup as character,
                                              input pArg as character):
        super(pGroup, pArg, ?).
    end constructor.
    
    /* Constructor
       
       @param character The token group (mandatory)
       @param character The token arguments (if any)
       @param character The token value     */
    constructor public TokenResolverEventArgs(input pGroup as character,
                                              input pArg as character,
                                              input pValue as character):
        super(pGroup, pArg, pValue).
    end constructor.
         
end class./* *************************************************************************************************************************
Copyright (c) 2016 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : VoidLogger
    Purpose     : Empty/null logger. Does nothing.
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-12-05
    Notes       : 
  ----------------------------------------------------------------------*/
// NO THROW EVAH
//block-level on error undo, throw.

using OpenEdge.Logging.ILogWriter.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.LogMessage.
using OpenEdge.Logging.VoidLogger.
using OpenEdge.Core.Assert.

class OpenEdge.Logging.VoidLogger final implements ILogWriter:
    // (mandatory) The level being logged at
    define public property LogLevel as LogLevelEnum no-undo get. private set. 
    
    // (mandatory) Name for this logger
    define public property Name as character no-undo get. private set.
    
    /* Constructor
           
       @param character The name of this logger implementation */
    constructor public VoidLogger(input pcName as character):
        Assert:NotNull(pcName, 'Logger name').
        
        assign this-object:Name     = pcName               
               this-object:LogLevel = LogLevelEnum:OFF
               .
    end constructor.
    
/** FATAL **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Fatal(input pcMessage as character):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Fatal(input pcMessageGroup as character, input pcMessage as character):
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Fatal(input poMessage as LogMessage):
    end method.
        
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Fatal(input pcMessageGroup as character, input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Fatal(input poMessage as LogMessage, input poError as Progress.Lang.Error):
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Fatal(input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

/** ERROR **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Error(input pcMessage as character):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Error(input pcMessageGroup as character, input pcMessage as character):
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Error(input poMessage as LogMessage):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Error(input pcMessageGroup as character, input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Error(input poMessage as LogMessage, input poError as Progress.Lang.Error):
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Error(input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

/** WARN **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Warn(input pcMessage as character):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Warn(input pcMessageGroup as character, input pcMessage as character):
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Warn(input poMessage as LogMessage):
    end method.

    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Warn(input pcMessageGroup as character, input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Warn(input poMessage as LogMessage, input poError as Progress.Lang.Error):
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Warn(input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

/** INFO **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Info(input pcMessage as character):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Info(input pcMessageGroup as character, input pcMessage as character):
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Info(input poMessage as LogMessage):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Info(input pcMessageGroup as character, input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Info(input poMessage as LogMessage, input poError as Progress.Lang.Error):
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Info(input pcMessage as character, input poError as Progress.Lang.Error):
    end method.
    
/** DEBUG **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Debug(input pcMessage as character):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Debug(input pcMessageGroup as character, input pcMessage as character):
    end method.
    
    /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Debug(input poMessage as LogMessage):
    end method.

    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Debug(input pcMessageGroup as character, input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Debug(input poMessage as LogMessage, input poError as Progress.Lang.Error):
    end method.
               
    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Debug(input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

/** TRACE **/
    /* Log for a simple message 
       
       @param character The message to log. */
    method public void Trace(input pcMessage as character):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. */    
    method public void Trace(input pcMessageGroup as character, input pcMessage as character):
    end method.
    
       /* Log for a simple message 
       
       @param LogMessage The message to log. */
    method public void Trace(input poMessage as LogMessage):
    end method.
    
    /* Log for a group and a simple message
        
       @param character The message group for this message 
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Trace(input pcMessageGroup as character, input pcMessage as character, input poError as Progress.Lang.Error):
    end method.

    /* Log for a message and error
       
       @param LogMessage The message to log. 
       @param Progress.Lang.Error An error to log */    
    method public void Trace(input poMessage as LogMessage, input poError as Progress.Lang.Error):
    end method.

    /* Log for a simple message 
       
       @param character The message to log. 
       @param Progress.Lang.Error An error to log */
    method public void Trace(input pcMessage as character, input poError as Progress.Lang.Error):
    end method.
    
    /* Compares two instances
       
       Loggers are equal iff
       - they have the same obejct reference ('handle'), or
       - they are both instances of OpenEdge.Logging.Logger and
         the Name property value is identical on both (= match)
       
       @param P.L.Object
       @return logical TRUE if these are the same logger object */
    method override public logical Equals( input poRef as Progress.Lang.Object ):
        if super:Equals(poRef) then
          return true.
          
        if not type-of(poRef, VoidLogger) then
            return false.
            
        return (cast(poRef, VoidLogger):Name eq this-object:Name).             
    end method.
    
end class.
/************************************************
Copyright (c) 2016-2017 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : ILoggerFilter
    Purpose     : Filter functionality definition for a message
    Author(s)   : pjudge
    Created     : 2016-11-16
    Notes       : * Implementers of this interface can be
                        - message formatters
                        - message writers (to disk, file, db etc)
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.LogEvent.

interface OpenEdge.Logging.Filter.ILoggerFilter:
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogEvent The log event to filter. */
    method public void ExecuteFilter(input poEvent as LogEvent).
    
end interface.
/* *************************************************************************************************************************
Copyright (c) 2016-2018 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : LogFilterBuilder
    Purpose     : Builder for Filter filters (writers, formatters)
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-14
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.ISupportInitialize.
using OpenEdge.Core.Util.BuilderRegistry.
using OpenEdge.Core.Util.ConfigBuilder.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.Filter.LogFilterBuilder.
using OpenEdge.Logging.Format.ISupportFormatting.
using OpenEdge.Logging.LogFilterBuilderRegistry.
using OpenEdge.Logging.LoggerFilterRegistry.
using Progress.IO.FileOutputStream.
using Progress.IO.OutputStream.
using Progress.Json.ObjectModel.JsonDataType.
using Progress.Json.ObjectModel.JsonObject.

class OpenEdge.Logging.Filter.LogFilterBuilder inherits ConfigBuilder:
    /** The filter being built */ 
    define public property Filter as ILoggerFilter no-undo
        get():
            if not valid-object(this-object:Filter) then
                assign this-object:Filter = NewFilter().
            
            return this-object:Filter.
        end get.
        private set.
        
    /** (mandatory) The Filter type for which we want to log */
    define public property FilterType as character no-undo get. private set.
    
    /** Returns log writer build for a logging type
        
        @param  P.L.Class The Filter type for which to build the logger
        @return LogFilterBuilder The entity writer builder to use  */
    method static public LogFilterBuilder Build(input pfilterType as class Progress.Lang.Class):
        Assert:NotNull(pfilterType, 'Filter type').
        
        return LogFilterBuilder:Build(pfilterType:TypeName).
    end method.
    
    /** Returns log writer build for a logging type
        
        @param  character The Filter type for which to build the logger
        @return LogFilterBuilder The entity writer builder to use  */
    method static public LogFilterBuilder Build(input pcFilterType as character):
        return LogFilterBuilder:Build(pcFilterType, LogFilterBuilderRegistry:Registry). 
    end method.
    
    /** Returns log writer build for a logging type
        
        @param  character The Filter type for which to build the logger
        @param  BuilderRegistry A registry of Filter writers to user
        @return LogFilterBuilder The entity writer builder to use  */
    method static public LogFilterBuilder Build(input pcFilterType as character,
                                                input poWriters as BuilderRegistry):
        define variable oBuilderType as Progress.Lang.Class no-undo.
        define variable oBuilder as LogFilterBuilder no-undo.
        
        Assert:NotNull(pcFilterType, 'Filter type').
        Assert:NotNull(poWriters, 'Writer builder registry').
        Assert:IsType(poWriters:ValueType, get-class(LogFilterBuilder)).
        
        assign oBuilderType = poWriters:Get(pcFilterType).
        if valid-object(oBuilderType) then
            Assert:IsType(oBuilderType, get-class(LogFilterBuilder)).        
        else
            // default is this class 
            assign oBuilderType = get-class(LogFilterBuilder).
        
        oBuilder = dynamic-new string(oBuilderType:TypeName) (pcFilterType).
        
        if type-of(oBuilder, ISupportInitialize) then
            cast(oBuilder, ISupportInitialize):Initialize().
        
        return oBuilder.
    end method.

    /* Constructor */
    constructor public LogFilterBuilder (input pcFilterType as character):
        Assert:NotNull(pcFilterType, 'Filter type').
        assign this-object:FilterType = pcFilterType.
    end method.
    
     /** Adds or overwrites an option for the client library.
        
        @param  JsonObject The Filter options (can be anything)
        @return LogFilterBuilder This builder object. */
    method public LogFilterBuilder Options(input poValue as JsonObject):
        Assert:NotNull(poValue, 'Filter options').
        
        SetOption('loggerOptions':u, poValue).
        
        return this-object.
    end method.
    
    /** Sets the output destination
        
        @param  character The filename to write to
        @return LogFilterBuilder This builder object. */
    method public LogFilterBuilder WriteTo(input pcLogFile as character ):
        Assert:NotNullOrEmpty(pcLogFile, 'Logfile name').
        
        SetOption('writeToFileName':u, pcLogFile).
        
        return this-object.
    end method.

    /** Indicates whether to append to the log
        
        @param  character The filename to write to
        @return LogFilterBuilder This builder object. */
    method public LogFilterBuilder Append(input plAppendToLog as logical):
        Assert:NotUnknown(plAppendToLog, 'Append to log').
        
        SetOption('appendToLog':u, plAppendToLog).
        
        return this-object.
    end method.
    
    /** Sets the output destination
        
        @param  FileOutputStream The filename to write to
        @return LogFilterBuilder This builder object. */
    method public LogFilterBuilder WriteTo(input poLogFile as FileOutputStream ):
        Assert:NotNull(poLogFile, 'Logfile name').
        
        SetOption('writeToFileStream':u, poLogFile).
        
        return this-object.
    end method.
    
    /** Sets the output destination
        
        @param  OutputStream The filename to write to
        @return LogFilterBuilder This builder object. */
    method public LogFilterBuilder WriteTo(input poOutput as OutputStream ):
        Assert:NotNull(poOutput, 'Log output destination').
        
        SetOption('writeToStream':u, poOutput).
        
        return this-object.
    end method.
    
    /** Sets a format string for a filter
        
        @param  character The filename to write to
        @return LogFilterBuilder This builder object. */
    method public LogFilterBuilder FormatAs(input pcFormat as character):
        Assert:NotNullOrEmpty(pcFormat, 'Filter format string').
        
        SetOption('formatString':u, pcFormat).
        
        return this-object.
    end method.    
    
    /** Sets the logging level for the logger
        
        @param  BuilderRegistry The registry containing the map of log writers
        @return LogFilterBuilder This builder object. */
    method public LogFilterBuilder FromRegistry(input poLoggerFilterRegistry as BuilderRegistry):
        Assert:NotNull(poLoggerFilterRegistry, 'Filter registry').
        Assert:IsType(poLoggerFilterRegistry:ValueType, get-class(ILoggerFilter)).
        
        SetOption('filterRegistry':u, poLoggerFilterRegistry).
        
        return this-object.
    end method.
    
    /** Returns a filter writer from a registry; either the optional one set via loggerFilterRegistry or
        the default LoggerFilterRegistry:Registry. It's the caller's responsibility to invoke and 
        use the filter type returned. 
        
        @param character The filter type name 
        @return Progress.Lang.Class The type of the filter writer. */
    method protected class Progress.Lang.Class GetFilterType(input filterTypeName as character):
        define variable filterType as class Progress.Lang.Class no-undo.
        define variable filterRegistry as BuilderRegistry no-undo.
        
        Assert:NotNull(filterTypeName, 'Filter type name').
        
        if HasOption('filterRegistry':u) then
            assign filterRegistry = cast(GetOptionObjectValue('filterRegistry':u), BuilderRegistry).
        else
            assign filterRegistry = LoggerFilterRegistry:Registry.
        
        Assert:IsType(filterRegistry:ValueType, get-class(ILoggerFilter)).
        
        assign filterType = filterRegistry:Get(filterTypeName).
        
        if valid-object(filterType) then
            Assert:IsType(filterType, get-class(ILoggerFilter)).
        
        return filterType.
    end method.
    
    /* Creates the instance.
       
       @return ILoggerFilter A filter instance  */
    method protected ILoggerFilter NewFilter():
        define variable logFilter as ILoggerFilter no-undo.
        define variable filterType as class Progress.Lang.Class no-undo.
        define variable formatString as character no-undo.
        define variable filterOptions as JsonObject no-undo.
        
        assign filterType = GetFilterType(this-object:FilterType).
        if not valid-object(filterType) then
            return logFilter.
        
        logFilter = dynamic-new string(filterType:TypeName) ().
        
        if type-of(logFilter, ISupportFormatting) then
        do:
            assign formatString = GetOptionStringValue('formatString':u).
            if     formatString eq ? 
               and HasOption('loggerOptions':u) then
            do:
                assign filterOptions = cast(GetOptionObjectValue('loggerOptions':u), JsonObject).
                if     valid-object(filterOptions) 
                   and filterOptions:Has('format':u) 
                   and filterOptions:GetType('format':u) eq JsonDataType:STRING then
                    assign formatString = filterOptions:GetCharacter('format':u).                        
            end.
            
            if formatString ne ? then
                assign cast(logFilter, ISupportFormatting):Format = formatString. 
        end.
        
        if type-of(logFilter, ISupportInitialize) then
            cast(logFilter, ISupportInitialize):Initialize().
        
        return logFilter.
    end method.
    
end class.
/************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : LoggerFilterList
    Purpose     : A list of filter nodes to process
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-16
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Logging.Filter.LoggerFilterNode.
using OpenEdge.Logging.LogEvent.

{OpenEdge/Core/Collections/typedlinkedlist.i
    &Package    = OpenEdge.Logging.Filter
    &ListType   = LoggerFilterList
    &NodeType   = LoggerFilterNode
    &NoEndClass = false
}

    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter(input poEvent as LogEvent):
        define variable oNode as LoggerFilterNode no-undo.
        
        Assert:NotNull(poEvent, 'Log event').
        
        assign oNode = this-object:First.
        do while valid-object(oNode):
            oNode:Data:ExecuteFilter(poEvent).
            
            /* pass it on */
            assign oNode = oNode:Next.
        end.
    end method.
    
end class.
/************************************************
Copyright (c) 2016 by Progress Software Corporation. All rights reserved.
*************************************************/ 
/*------------------------------------------------------------------------
    File        : LoggerFilterNode
    Purpose     : A node on the logging message filter chain
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-16
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.Filter.ILoggerFilter.



    
        
                    
    




class OpenEdge.Logging.Filter.LoggerFilterNode : 
    define public property Next as class OpenEdge.Logging.Filter.LoggerFilterNode no-undo get. set.
    define public property Data as class ILoggerFilter no-undo get. set.
    
    constructor public LoggerFilterNode(input poData as class ILoggerFilter):
        this-object:Data = poData.
    end constructor.


end class. 


 
/* *************************************************************************************************************************
Copyright (c) 2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : ABLSubstituteFormat
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 16 13:03:48 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.LogEvent.

class OpenEdge.Logging.Format.ABLSubstituteFormat implements ILoggerFilter:
    
        /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter( input poEvent as LogEvent ):
        define variable iSize as integer no-undo.
        define variable iLoop as integer no-undo.
        
        if not valid-object(poEvent) then
            return.
        
        assign iSize = extent(poEvent:Message:Arguments).
        if iSize eq ? then
            return.
        assign poEvent:Message:Message = substitute(poEvent:Message:Message,
                                    (if iSize ge 1 then poEvent:Message:Arguments[1] else ?),
                                    (if iSize ge 2 then poEvent:Message:Arguments[2] else ?),
                                    (if iSize ge 3 then poEvent:Message:Arguments[3] else ?),
                                    (if iSize ge 4 then poEvent:Message:Arguments[4] else ?),
                                    (if iSize ge 5 then poEvent:Message:Arguments[5] else ?),
                                    (if iSize ge 6 then poEvent:Message:Arguments[6] else ?),
                                    (if iSize ge 7 then poEvent:Message:Arguments[7] else ?),
                                    (if iSize ge 8 then poEvent:Message:Arguments[8] else ?),
                                    (if iSize ge 9 then poEvent:Message:Arguments[9] else ?)).

        if iSize gt 9 then
        do iLoop = 10 to iSize:
            assign poEvent:Message:Message = substitute(poEvent:Message:Message + '; &1 ':u,
                                                    poEvent:Message:Arguments[iLoop]).
        end.
    end method.
        
end class.
/* *************************************************************************************************************************
Copyright (c) 2016-2018 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : ErrorFormat
    Purpose     : Formats any errors
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-21
    Notes       : * Written for all events
                    - the error messages and their number
                    - the return value (if an AppError)
                    - any errors contained in a InnerError property of type P.L.Error
                  * Written for DEBUG events
                    - the error type name
                  * Written for TRACE events
                    - the error's call stack
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.LogEvent.
using OpenEdge.Logging.LogLevelEnum.
using Progress.Lang.AppError.
using Progress.Reflect.DataType.
using OpenEdge.Core.StringConstant.

class OpenEdge.Logging.Format.ErrorFormat implements ILoggerFilter:
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter(input poEvent as LogEvent):
        define variable errLoop as integer no-undo.
        define variable errMax as integer no-undo.
        define variable ex as Progress.Lang.Error no-undo.
        define variable errProp as Progress.Reflect.Property no-undo.
        define variable errHeader as character no-undo.
        
        // only do error stuff
        assign ex        = poEvent:Error
               errHeader = 'Error(s) raised:'
               .
        do while valid-object(ex):
            // only log error type for DEBUG logging
            assign poEvent:Message:Message = poEvent:Message:Message
                                           + StringConstant:LF + StringConstant:TAB
                                           + errHeader.
            if  (     valid-object(poEvent:Logger) 
                  and poEvent:Logger:LogLevel ge LogLevelEnum:DEBUG )
               or poEvent:LogLevel ge LogLevelEnum:DEBUG then
                assign poEvent:Message:Message = poEvent:Message:Message + StringConstant:TAB + ex:GetClass():TypeName.
                
            assign errMax = poEvent:Error:NumMessages.
            do errLoop = 1 to errMax:
                assign poEvent:Message:Message = poEvent:Message:Message
                                               + StringConstant:LF + StringConstant:TAB + StringConstant:TAB
                                               + ex:GetMessage(errLoop)
                                               + substitute(' (&1)':u, ex:GetMessageNum(errLoop) ).
            end.
            
            if     type-of(poEvent:Error, AppError) 
               and cast(ex, AppError):ReturnValue ne '':u then
                assign poEvent:Message:Message = poEvent:Message:Message
                                               + StringConstant:LF + StringConstant:TAB
                                               + substitute('ReturnValue: &1' , cast(ex, AppError):ReturnValue).
            
            assign errMax = num-entries(ex:CallStack, StringConstant:LF).
            // Log error stacks for TRACE logging
            if (  (     valid-object(poEvent:Logger) 
                    and poEvent:Logger:LogLevel ge LogLevelEnum:TRACE )
                 or poEvent:LogLevel ge LogLevelEnum:TRACE 
                 or session:debug-alert                                )
               and errMax gt 0
            then
            do:
                assign poEvent:Message:Message = poEvent:Message:Message
                                               + StringConstant:LF + StringConstant:TAB
                                               + 'Error stack:'.
                do errLoop = 1 to errMax:
                    assign poEvent:Message:Message = poEvent:Message:Message
                                                   + StringConstant:LF + StringConstant:TAB + StringConstant:TAB
                                                   + entry(errLoop, ex:CallStack, StringConstant:LF).
                end.
            end.
            
            assign errProp = ex:GetClass():GetProperty('InnerError':u).
            if     valid-object(errProp) 
               and errProp:DataType eq DataType:Object 
               and Progress.Lang.Class:GetClass(errProp:DataTypeName):IsA(get-class(Progress.Lang.Error)) then
                assign errHeader = 'Caused by:'
                       ex        = errProp:Get(ex).
            else
                leave.
        end.
        end method.
        
end class.
/* *************************************************************************************************************************
Copyright (c) 2016-2018 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : FullTextFormat
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 16 13:02:52 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.StringConstant.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.Format.ISupportFormatting.
using OpenEdge.Logging.LogEvent.
using OpenEdge.Logging.TokenResolver.

class OpenEdge.Logging.Format.FullTextFormat implements ILoggerFilter, ISupportFormatting:
    
    /* Format for the logger name. See the TokenResolve class for more */
    define public property Format as character initial '1C':u no-undo get. set.
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter( input poEvent as LogEvent ):
        define variable messageGroup as character no-undo.
        
        if poEvent:Message:GroupName eq '':u then
        do: 
            if this-object:Format eq poEvent:ShortNameFormat then
                assign messageGroup = poEvent:LoggerShortName.
            else
                assign messageGroup = TokenResolver:ResolveName(this-object:Format, poEvent:LoggerName).
        end.
        else
            assign messageGroup = poEvent:Message:GroupName.
        
        assign poEvent:Message:Message = substitute('[&1] &3 &2: &4&5':U,
                            /*1*/ iso-date(poEvent:TimeStamp),
                            /*2*/ string(poEvent:LogLevel),
                            /*3*/ messageGroup,
                            /*4*/ poEvent:Message:Message,
                            /*5*/ StringConstant:CRLF).
        end method.
        
end class.
/* *************************************************************************************************************************
Copyright (c) 2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : ISupportFormatting
    Purpose     : Indicates that an implementer supports format strings 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2017-02-14
    Notes       : 
  ----------------------------------------------------------------------*/
interface OpenEdge.Logging.Format.ISupportFormatting:
    
    /* Format for the filter. See the TokenResolve class for more */
    define public property Format as character no-undo get. set.
    
end interface./* *************************************************************************************************************************
Copyright (c) 2016-2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : LogManagerFormat
    Purpose     : Provides a standard format for writing log-manager messages via write-message()
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-17
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.StringConstant.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.Format.ISupportFormatting.
using OpenEdge.Logging.LogEvent.
using OpenEdge.Logging.TokenResolver.

class OpenEdge.Logging.Format.LogManagerFormat implements ILoggerFilter, ISupportFormatting:
    
    /* Format for the logger name. See the TokenResolve class for more */
    define public property Format as character initial '1C':u no-undo get. set.
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter( input poEvent as LogEvent):
        define variable loggerShortName as character no-undo.
        
        if this-object:Format eq poEvent:ShortNameFormat then
            assign loggerShortName = poEvent:LoggerShortName.
        else
            assign loggerShortName = TokenResolver:ResolveName(this-object:Format, poEvent:LoggerName).
        
        assign poEvent:Message:Message = substitute('[&3 &1] &2':u,
                                                string(poEvent:LogLevel), 
                                                poEvent:Message:Message,
                                                loggerShortName        ).
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016-2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : ResolvedTokenFormat
    Purpose     : Formats a token-based message using the OE.Logging.TokenResolver
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Wed Nov 16 13:02:52 EST 2016
    Notes       : - The Format string in this
                    ${msg}
                        (LogMessage.Message)
                    ${msg.[sub-token]}
                    sub-token
                        grp                 LogMessage.GroupName
                        logger[.format]     LogEvent.LoggerName
                        level               LogEvent.LogLevel
                        stack.depth         LogEvent.Callstack[depth]; the lesser of the size of the stack or <depth>; set to 1 if not specified 
                        t.[arg]             LogEvent.TimeStamp
                            arg is * Group args for T (T= time). from TokenResolver
                        cp.[arg]            LogEvent.LoggedBy
                        err         LogEvent.Error
                   - All of the msg.[sub-token] messages are fully-resolved here except
                     for the ts.[arg] tokens which are passed into the TokenResolver
                           
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.Format.ISupportFormatting.
using OpenEdge.Logging.LogEvent.
using OpenEdge.Logging.TokenResolver.
using OpenEdge.Logging.TokenResolverEventArgs.

class OpenEdge.Logging.Format.ResolvedTokenFormat implements ILoggerFilter,ISupportFormatting:
    // stateful variable so we know which event we're dealing with in the callback 
    define private variable mCurrentEvent as LogEvent no-undo.
    
    /* Format for the logger name. See the TokenResolve class for more */
    define public property Format as character no-undo get. set.
    
    /* Default constructor */
    constructor public ResolvedTokenFormat ():
        TokenResolver:TokenResolved:Subscribe(this-object:TokenResolvedHandler).
    end constructor.        
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter( input poEvent as LogEvent ):
        if not valid-object(poEvent) then
            return.
        
        assign mCurrentEvent           = poEvent
               // pass the input message through in case it has tokens itself
               poEvent:Message:Message = TokenResolver:Resolve(poEvent:Message:Message)
               // now format per this filter's Format
               poEvent:Message:Message = TokenResolver:Resolve(this-object:Format)
               .
        finally:
            assign mCurrentEvent = ?.
        end finally.
    end method.
    
    /* Callback to handle token replacement with LogEvent/LogMessage context
       
       @param Object The sender
       @param TokenResolverEventArgs The token resolution args  */
    method public void TokenResolvedHandler (input pSender as Progress.Lang.Object,
                                             input pArgs as TokenResolverEventArgs):
        define variable formatString as character no-undo.
        define variable idx as integer no-undo.
        
        if not valid-object(mCurrentEvent) then
            return.
        
        // only care about what we know
        if not pArgs:TokenGroup eq 'msg':u then
            return.
        
        // we may have child tokens
        case entry(1, pArgs:TokenArg, '.':u):
            when '':u or
            when 'msg':u  then
                assign pArgs:TokenValue = mCurrentEvent:Message:Message.
            when 'grp':u  then
                assign pArgs:TokenValue = mCurrentEvent:Message:GroupName.
            when 'logger':u  then
            do:
                if num-entries(pArgs:TokenArg, '.':u) gt 1 then
                    assign formatString = trim(entry(2, pArgs:TokenArg, '.':u)).
                else
                    assign formatString = '':u.
                
                // use the pre-formatted logger name if possible
                if mCurrentEvent:ShortNameFormat eq formatString then
                    assign pArgs:TokenValue = mCurrentEvent:LoggerShortName.
                else
                    assign pArgs:TokenValue = TokenResolver:ResolveName(formatString, mCurrentEvent:LoggerName).
            end.    //logger
            
            when 'stack':u then
            do:
                case true:
                    when extent(mCurrentEvent:CallStack) eq ? then
                        assign idx = 0.
                    when num-entries(pArgs:TokenArg, '.':u) gt 1 then
                        // the number cannot be larger than the actual callstack size
                        assign idx = min(integer(entry(2, pArgs:TokenArg, '.':u)), extent(mCurrentEvent:CallStack)). 
                    otherwise
                        assign idx = 1.
                end case.
                
                if idx gt 0 then                
                    assign pArgs:TokenValue = mCurrentEvent:CallStack[idx].
            end.    // stack 
            
            when 'level':u  then
                assign pArgs:TokenValue = mCurrentEvent:LogLevel:ToString().
            when 'err':u  then
                assign pArgs:TokenValue = mCurrentEvent:Error:ToString().
            when 't':u then
                assign pArgs:TokenValue = TokenResolver:ResolveTime(entry(2, pArgs:TokenArg, '.':u), mCurrentEvent:TimeStamp).
            when 'cp':u then
                assign pArgs:TokenValue = TokenResolver:ResolveUser(entry(2, pArgs:TokenArg, '.':u), mCurrentEvent:LoggedBy).
            // leave it alone otherwise 
        end case.
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016-2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : StackWriterFormat
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-17
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.LogEvent.
using OpenEdge.Core.StringConstant.

class OpenEdge.Logging.Format.StackWriterFormat implements ILoggerFilter: 
    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter( input poEvent as LogEvent):
        define variable stackCnt as integer no-undo.
        define variable stackSize as integer no-undo.
        define variable delim as character no-undo.
        
        assign stackSize = extent(poEvent:CallStack).
        if stackSize ne ? then
        do:
            assign poEvent:Message:Message = poEvent:Message:Message
                                           + StringConstant:LF + StringConstant:TAB
                                           + 'Log stack:'.
            do stackCnt = 1 to stackSize:
                assign poEvent:Message:Message = poEvent:Message:Message
                                               + StringConstant:LF + StringConstant:TAB + StringConstant:TAB
                                               + poEvent:CallStack[stackCnt]. 
            end.
        end.
        end method.
        
end class.
/************************************************
Copyright (c) 2016-2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : FileLogFilterBuilder
    Purpose     : Builds a (named) file logger
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-14
    Notes       : * Token substitutions are allowed for file names
                    the token format is ${<token>}, where
                    token = group "." arg
                  * See OpenEdge.Logging.TokenResolver for more info about supported tokens
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.ISupportInitialize.
using OpenEdge.Core.StringConstant.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.Filter.LogFilterBuilder.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.LoggerFilterRegistry.
using OpenEdge.Logging.TokenResolver.
using OpenEdge.Logging.Writer.IFileWriter.
using OpenEdge.Logging.Writer.VoidWriter.
using Progress.IO.FileOutputStream.
using Progress.Json.ObjectModel.JsonDataType.
using Progress.Json.ObjectModel.JsonObject.
using Progress.Lang.AppError.

class OpenEdge.Logging.Writer.FileLogWriterBuilder inherits LogFilterBuilder:
    // illegal characters for file names (on windows). 
    define protected property illegalChars as character extent 7 no-undo 
        initial ['<','>',':','"','|','?','*':u]
        get.
    
    /* Constructor */
    constructor public FileLogWriterBuilder(input filterName as character):
        super(filterName).
    end method.
    
    /** Returns a filter writer from a registry; either the optional one set via loggerFilterRegistry or
        the default LoggerFilterRegistry:Registry. It's the caller's responsibility to invoke and 
        use the filter type returned. 
        
        @return Progress.Lang.Class The type of the filter writer. */
    method override protected Progress.Lang.Class GetFilterType(input filterTypeName as character):
        define variable filterType as class Progress.Lang.Class no-undo.                
        
        assign filterType = super:GetFilterType(this-object:FilterType).
        
        /* If we get the VoidWriter when we didn't ask for it AND if the
           log-manager is running, use the log manager instead.       */
        if not valid-object(filterType) or
          ( filterType:IsA(get-class(VoidWriter)) 
            and this-object:FilterType ne LoggerFilterRegistry:VOID_WRITER 
            and log-manager:logfile-name ne ?                              ) then
            assign filterType = this-object:GetFilterType(LoggerFilterRegistry:LOG_MANAGER_WRITER).
        
        return filterType.            
    end method.
        
    /* Creates the instance.
       
       @return ILoggerFilter A filter instance  */
    method override protected ILoggerFilter NewFilter(  ):
        define variable filter as ILoggerFilter no-undo.
        define variable filterType as class Progress.Lang.Class no-undo.
        define variable fileStream as FileOutputStream no-undo.
        define variable appendToFile as logical no-undo.
        define variable logLevel as LogLevelEnum no-undo.
        define variable logfileName as character no-undo.
        define variable filterOptions as JsonObject no-undo.
        define variable chrLoop as integer no-undo.
        define variable chrMax as integer no-undo.
        define variable chrStart as integer no-undo.
        
        assign filterType = GetFilterType(this-object:FilterType).
        
        case true:
            when not valid-object(filterType) then
                return filter.
            
            // if this is not a file writer then let the default writer take over
            when not filterType:IsA(get-class(IFileWriter)) then
                return super:newFilter().
            
            when HasOption('writeToFileStream':u) then
            do:
                assign fileStream = cast(GetOptionObjectValue('writeToFileStream':u), FileOutputStream).
                filter = dynamic-new string(filterType:TypeName) (fileStream).
            end.
            
            otherwise
            do:
                assign logfileName = GetOptionStringValue('writeToFileName':u).
                if logfileName eq ? then
                do:
                    assign filterOptions = cast(GetOptionObjectValue('loggerOptions':u), JsonObject).
                    if     valid-object(filterOptions) 
                       and filterOptions:Has('fileName':u) 
                       and filterOptions:GetType('fileName':u) eq JsonDataType:STRING then
                        assign logfileName = filterOptions:GetCharacter('fileName':u).                        
                end.
                assign logfileName = replace(TokenResolver:Resolve(logfileName), StringConstant:BACKSLASH, '/':u).
                
                // certain characters are illegal on windows
                if opsys eq 'win32':u then
                do:
                    assign chrMax   = extent(illegalChars)
                           chrStart = 3.
                    if logfileName begins '/':u then
                        assign chrStart = 1.
                    
                    do chrLoop = 1 to chrMax:
                        if index(logfileName, illegalChars[chrLoop], chrStart) gt 0 then
                            return error new AppError(substitute('Illegal character &1 in filename &2',
                                                        illegalChars[chrLoop],
                                                        logfileName),
                                                     0). 
                    end.
                end.
                
                assign appendToFile = GetOptionLogicalValue('appendToLog':u).
                if appendToFile eq ? then
                do:
                    if not valid-object(filterOptions) then
                        assign filterOptions = cast(GetOptionObjectValue('loggerOptions':u), JsonObject).
                        
                    if valid-object(filterOptions) 
                       and filterOptions:Has('appendTo':u) 
                       and filterOptions:GetType('appendTo':u) eq JsonDataType:BOOLEAN then
                        assign appendToFile = filterOptions:GetLogical('appendTo':u).                        
                    else
                        assign appendToFile = true.
                end.
                
                filter = dynamic-new string(filterType:TypeName) (logfileName, appendToFile).
            end.
        end case.
        
        if type-of(filter, ISupportInitialize) then
            cast(filter, ISupportInitialize):Initialize().
        
        return filter.
    end method.
        
end class.
/************************************************
Copyright (c)  2016 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : IFileWriter
    Purpose     : Indicates whether we're writing to a file
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Thu Nov 17 11:21:34 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
interface OpenEdge.Logging.Writer.IFileWriter:
    // The output location

    define public property FileName as character no-undo get.
        
    // TRUE if we are appending to an existing file

    define public property Append as logical no-undo get. 
  
end interface.
/* *************************************************************************************************************************
Copyright (c) 2016-2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : LogManagerWriter
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : Mon May 23 09:39:34 EDT 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.LogEvent.
using OpenEdge.Logging.Writer.IFileWriter.

class OpenEdge.Logging.Writer.LogManagerWriter implements ILoggerFilter, IFileWriter:
    define private property SubSys as character no-undo initial 'LogMgrWrtr':u get.
    
    // TRUE when we're on an appserver/webspeed broker or we haven't passed in a filename  
    define private variable mlDefaultLog as logical no-undo.
    
    // (mandatory) The output location: The location of the log-manager
    define public property FileName as character no-undo
        get():
            return log-manager:logfile-name.
        end get.    
        
    // TRUE if we are appending to an existing file
    define public property Append as logical no-undo get. private set. 
    
    /* Constructor */
    constructor public LogManagerWriter():
        super().
        
        // For the default log we always append
        assign mlDefaultLog       = true
               this-object:Append = true.
    end constructor.
    
    /* Default destructor */
    destructor LogManagerWriter():
        if not mlDefaultLog then
            log-manager:close-log().
    end destructor.
    
    /* Constructor
       
       @param character The name of the logfile to use
       @param logical TRUE if log entries should be appended to an existing log */
    constructor public LogManagerWriter(input pcFile as character,
                                        input plAppend as logical):
        this-object().
        
        case session:client-type:
            when 'APPSERVER':u or 
            when 'MULTI-SESSION-AGENT':u or
            when 'WEBSPEED':u then
            do:
                assign mlDefaultLog       = true
                       this-object:Append = true.
                if log-manager:logging-level ge integer(LogLevelEnum:INFO) then                       
                    log-manager:write-message(
                                 substitute('INFO: Current session client type &1 does not support named logs', session:client-type),
                                 SubSys).
                return.
            end.
            otherwise
            case true:
                when log-manager:logfile-name eq ? and pcFile ne ? then
                do:
                    assign log-manager:logfile-name = pcFile
                           this-object:Append       = plAppend
                           mlDefaultLog             = true.
                    if not plAppend then
                        log-manager:clear-log(). 
                end.
                otherwise
                do:
                    if     log-manager:logfile-name ne pcFile 
                       and pcFile ne '':u 
                       and log-manager:logging-level ge integer(LogLevelEnum:INFO) then                       
                        log-manager:write-message(
                                substitute('INFO: Log-manager is already in use. Cannot write to &1', pcFile), 
                                SubSys).
                    assign mlDefaultLog       = true
                           this-object:Append = true.
                end.    // existing 
            end case.
        end case.
    end constructor.
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter( input poEvent as LogEvent):
        if log-manager:logfile-name eq ? then
            return.
        log-manager:write-message(poEvent:Message:Message, SubSys).
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : MessageStatementWriter
    Purpose     : Writes the message as a MESSAGE statement.
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-22
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.LogEvent.

class OpenEdge.Logging.Writer.MessageStatementWriter implements ILoggerFilter:
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
    method public void ExecuteFilter( input poEvent as LogEvent):
        message poEvent:Message:Message.
    end method.
        
end class.
/* *************************************************************************************************************************
Copyright (c) 2016-2017 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : NamedFileWriter
    Purpose     : 
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-08-23
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Logging.LogLevelEnum.
using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.LogEvent.
using Progress.IO.FileOutputStream.
using OpenEdge.Logging.Writer.IFileWriter.
using OpenEdge.Core.StringConstant.

class OpenEdge.Logging.Writer.NamedFileWriter implements ILoggerFilter, IFileWriter:
    /* The file we're writing to */
    define private variable moFileOutputStream as FileOutputStream  no-undo.

    /* (mandatory) The output location */
    define public property FileName as character no-undo
        get():
            if valid-object(moFileOutputStream) then
                return moFileOutputStream:FileName.
        end get.
        
    /* TRUE if we are appending to an existing file */
    define public property Append as logical no-undo get. private set. 
    
    /* Constructor
       
       @param FileOutputStream  A file for writing log entries into
       @param LoggerFilterList Formatting filters for this logger  */
    constructor public NamedFileWriter(input poFile as FileOutputStream):
        this-object().
        
        Assert:NotNull(poFile, 'Log file').
        assign moFileOutputStream = poFile
               this-object:Append = moFileOutputStream:Append
               .
    end constructor.
    
    /* Constructor
    
       @param character The file name to write into
       @param logical  TRUE if we are to append to this file */
    constructor public NamedFileWriter(input pcFileName as character,
                                       input plAppend as logical):
        this-object(new FileOutputStream(pcFileName, plAppend)).
    end constructor.
    
    /* Default constructor */
    constructor protected NamedFileWriter():
        super().
    end constructor.
    
    destructor NamedFileWriter():
        moFileOutputStream:Close().
    end destructor.
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogEvent The event to log. */
    method public void ExecuteFilter(input poEvent as LogEvent):
        define variable mLine as memptr no-undo.
        define variable iSize as integer no-undo.

        if moFileOutputStream:Closed then
            return.
            
        assign iSize = length(poEvent:Message:Message, 'raw':u) + 2.
        set-size(mLine) = iSize.
        put-string(mLine, 1) = poEvent:Message:Message + StringConstant:LF.
        
        moFileOutputStream:Write(mLine, 1, iSize - 1).
        
        // force a write 
        moFileOutputStream:Flush().
        finally:
            set-size(mLine) = 0.
        end finally.
    end method.
    
end class.
/* *************************************************************************************************************************
Copyright (c) 2016 by Progress Software Corporation and/or one of its subsidiaries or affiliates. All rights reserved.
************************************************************************************************************************** */
/*------------------------------------------------------------------------
    File        : VoidWriter
    Purpose     : No-op or VOID logger. Does nothing. Swallows everything.
    Syntax      : 
    Description : 
    Author(s)   : pjudge
    Created     : 2016-11-10
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Logging.Filter.ILoggerFilter.
using OpenEdge.Logging.LogEvent.

class OpenEdge.Logging.Writer.VoidWriter implements ILoggerFilter:
    
    /** Performs implementation-specific filtering for a logger type
        
        @param LogMessage The message to log. */
        method public void ExecuteFilter( input poEvent as LogEvent ):
            /* NOTHING HAPPENS HERE */
        end method.
        
end class.
/************************************************
  Copyright (c) 2016-2017 by Progress Software Corporation. All rights reserved.
*************************************************/
/*------------------------------------------------------------------------
    File        : Principal
    Purpose     : A wrapper/helper around a ABL Client-principal object 
    Author(s)   : pjudge
    Created     : Thu Feb 25 14:19:36 EST 2016
    Notes       : 
  ----------------------------------------------------------------------*/
block-level on error undo, throw.

using OpenEdge.Core.Assert.
using OpenEdge.Core.DataTypeEnum.
using OpenEdge.Security.Principal.
using Progress.Lang.AppError.
using OpenEdge.Core.AssertionFailedError.
using Progress.Lang.OERequestInfo.
using OpenEdge.Core.Memptr.

class OpenEdge.Security.Principal :
    /* Determines whether the contained token will be destroyed when this wrapper 
       is destroyed. Typically TRUE for Imports */
    define private variable mlAutoDestroy as logical no-undo.
    
    /* (mandatory) The C-P this class represents. */
    define public property Token as handle no-undo get. private set.
    
    /* Default constructor.
    
       Made private since we need this class to always hold a 
       client-principal */
    constructor private Principal():
    end constructor.
    
    /* Constructor.
    
       @param handle A valid client-principal (state not checked) */
    constructor public Principal(input phClientPrincipal as handle):
        this-object(phClientPrincipal, false).
    end method.
    
    /* Constructor.
       
       @param handle A valid client-principal (state not checked) 
       @param logical Determines whether the contained token will be destroyed 
                      when this wrapper is destroyed. Typically TRUE for Imports */ 
    constructor public Principal(input phClientPrincipal as handle,
                                 input plAutoDestroy as logical):
        Assert:IsType(phClientPrincipal, DataTypeEnum:ClientPrincipal, 'Token').
        Assert:NotUnknown(plAutoDestroy, 'Auto-destroy flag').
        
        assign this-object:Token = phClientPrincipal
               mlAutoDestroy     = plAutoDestroy.
    end constructor.
        
    destructor Principal():
        if     mlAutoDestroy 
           and valid-object(this-object:Token ) then
            delete object this-object:Token no-error.
        
        assign this-object:Token = ?.
    end destructor. 
    
    /* Validates the current token. 
       
       @return logical TRUE if the token is valid.      */
    method public logical Validate():
        return this-object:Token:validate-seal().
    end method.

    /* Validates the current token. 
       
       @param character The key used to seal the principal
       @return logical TRUE if the token is valid.      */
    method public logical Validate(input pcKey as character):
        Assert:NotNull(pcKey, 'Key').
        
        return this-object:Token:validate-seal(pcKey).
    end method.
    
    /* Authorises the current token for a particular role
       
       @param character A non-empty role
       @return logical TRUE if the user is authorised for the given role */
    method public logical Authorize(input pcRole as character):
        Assert:NotNullOrEmpty(pcRole, 'Role').
        
        return can-do(this-object:Token:roles, pcRole).
    end method.
    
    /* Authorises the current token for all given roles 
       
       @param character[] A non-empty array of roles
       @return logical TRUE if the user is authorised for ALL the given roles */
    method public logical Authorize(input pcRole as character extent):
        define variable lAllowed as logical no-undo.
        define variable iLoop as integer no-undo.
        
        do iLoop = extent(pcRole) to 1 by -1 
           while lAllowed:            
            assign lAllowed = Authorize(pcRole[iLoop]).
        end.
        
        return lAllowed.                                               
    end method.
    
    /* Asserts the user represented by this token in the current session.
       Will set for all connected dbs.
       
       @return logical TRUE if the assertion passed */
    method public logical AssertUser():
        return security-policy:set-client(this-object:Token).
    end method.

    /* Asserts the user represented by this token in the current session.
       Passing in a value of * results in asserting the user against all
       connected DB's.
       
       @param character The name of the connected database (logical or alias) 
                        into which the user is asserted.
       @return logical TRUE if the assertion passed */
    method public logical AssertUser(input pcDb as character):
        define variable lAsserted as logical no-undo.
        
        Assert:NotNullOrEmpty(pcDb, 'Database name').
        
        case pcDb:
            when '*':u then
                assign lAsserted = AssertUser(). 
            otherwise
            do:        
                if not connected(pcDb) then
                    return error new AppError(substitute('Database &1 not connected', pcDb), 0).
                
                assign lAsserted = set-db-client(this-object:Token, pcDb).
            end.
        end case.
        
        return lAsserted.
    end method.
    
    /* Creates a new Principal from RAW data
       
       @param raw An exported version of a CP 
       @return Principal A new object representing the input CP */
    method static public Principal Import(input prCP as raw):
        define variable hCP as handle no-undo.
        
        Assert:NotNull(prCP, 'Input token').
        
        create client-principal hCP.
        hCP:import-principal (prCP).
        
        return new Principal(hCP, true).        
    end method.

    /* Creates a new Principal from BASE64 data
       
       @param character An exported version of a CP, encoded as base64 
       @return Principal A new object representing the input CP */
    method static public Principal Import(input pcCP as character):
        define variable rCP as raw no-undo.
        
        Assert:NotNullOrEmpty(pcCP, 'Input token').
        
        assign rCP = base64-decode(pcCP).
                               
        return Principal:Import(rCP).
    end method.
    
    /* Creates a new Principal from the CP returned by a server. 
       
       @param OERequestInfo The request info containing the CP
       @return Principal A new object representing the input CP */
    method static public Principal Import(input poRequestInfo as OERequestInfo):
        define variable hCP as handle no-undo.
        
        Assert:NotNull(poRequestInfo, 'Server request info').
        assign hCP = poRequestInfo:GetClientPrincipal().
        
        Assert:NotNull(hCP, 'Input token').
        
        return new Principal(hCP, true).        
    end method.
    
    /* Creates a new Principal from a object-wrapper memptr 
    
       CALLER IS RESPONSIBLE FOR MEMORY DEALLOCATION
       
       @param Memptr The OO wrapper containing the CP
       @return Principal A new object representing the input CP */
    method static public Principal Import(input poCP as class Memptr):
        Assert:NotNull(poCP, 'Client principal').
        
        return Principal:Import(poCP:Value).
    end method.
    
    /* Creates a new Principal from a primitive memptr.
    
       CALLER IS RESPONSIBLE FOR MEMORY DEALLOCATION
       
       @param memptr The CP
       @return Principal A new object representing the input CP */
    method static public Principal Import(input pmCP as memptr):
        define variable rCP as raw no-undo.
        
        Assert:NotNull(get-size(pmCP), 'Client principal size').
        Assert:IsPositive(get-size(pmCP), 'Client principal size').
        
        assign rCP = pmCP.
        return Principal:Import(rCP).        
    end method.
    
end class.�OpenEdge/Core/Assert.clsǈ       *�  ��Z�:X���                        �&OpenEdge/Core/AssertionFailedError.cls��      ���  �Z�:Z.�                        �OpenEdge/Core/ByteBucket.clsvR      ���  z�Z�:Z��                        �OpenEdge/Core/DataTypeEnum.cls6�     .�  =Z�:V�9:                        � OpenEdge/Core/DataTypeHelper.clsF"     :X�  �Z�:V�97                        �!OpenEdge/Core/DateArrayHolder.cls�x     V��  �Z�:W���                        �                                �OpenEdge/Core/DateHolder.cls�     ]z�  �Z�:W��                        �)OpenEdge/Core/DateTimeAddIntervalEnum.clsh;     c�  �Z�:U���                        �%OpenEdge/Core/DateTimeArrayHolder.cls�B     f��  �Z�:W���                        � OpenEdge/Core/DateTimeHolder.cls�0     m��  �Z�:W��                        �'OpenEdge/Core/DateTimeTzArrayHolder.cls�     sr�  �Z�:W���                        �"OpenEdge/Core/DateTimeTzHolder.cls�&     {�  �Z�:W��                        �      �OpenEdge/Core/Decimal.cls�     ���  �Z�:Wr��                        �$OpenEdge/Core/DecimalArrayHolder.cls��     ���  �Z�:W���                        �OpenEdge/Core/EventArgs.cls�b     ���  Z�:Y�y�                        �#OpenEdge/Core/HandleArrayHolder.cls��     ���  
Z�:W���                        �#OpenEdge/Core/HashAlgorithmEnum.cls-(     ���  �Z�:U���                        �OpenEdge/Core/IAdaptable.cls��     �9�  �Z�:W�um                        �                               �OpenEdge/Core/Integer.cls�     ��  JZ�:W�Vo                        �$OpenEdge/Core/IntegerArrayHolder.cls�[     �V�  yZ�:W�Vr                        �OpenEdge/Core/IOModeEnum.clsB�     ���  OZ�:Y��                        �OpenEdge/Core/IOModeHelper.clsC+     ��  �Z�:Y��V                        �"OpenEdge/Core/ISupportEncoding.cls��     Ī�  �Z�:X���                        �$OpenEdge/Core/ISupportInitialize.cls�     ǡ�  �Z�:U���                        �                            �"OpenEdge/Core/JsonDataTypeEnum.cls��     ʋ�  �Z�:U���                        �OpenEdge/Core/KeyValuePair.cls��     ��  �Z�:Y��[                        �OpenEdge/Core/LogicalArray.cls�     ���  �Z�:Wr��                        �$OpenEdge/Core/LogicalArrayHolder.cls�7     �u�  �Z�:W���                        �OpenEdge/Core/LogicalValue.clsZ�     �8�  �Z�:Wr��                        �OpenEdge/Core/LogLevelEnum.cls"Z     ��  0Z�:WA�                        �                           �%OpenEdge/Core/LongcharArrayHolder.clsO�     ���  �Z�:W���                        �OpenEdge/Core/Memptr.cls�     ���  9�Z�:Z�92                        �#OpenEdge/Core/MemptrArrayHolder.cls�f     /��  �Z�:W���                        �#OpenEdge/Core/ObjectArrayHolder.cls�     4i�  ~Z�:W���                        �OpenEdge/Core/ReadModeEnum.clsJ=     :��  �Z�:Y.�                        �!OpenEdge/Core/RoutineTypeEnum.clsQe     >��  ~Z�:U���                        �                       �"OpenEdge/Core/RowidArrayHolder.clsU�     B4�  �Z�:W���                        �!OpenEdge/Core/SemanticVersion.cls��     H��  �Z�:Y�u�                        �)OpenEdge/Core/SerializationFormatEnum.cls�.     f��  FZ�:U���                        �'OpenEdge/Core/SerializationModeEnum.cls@�     i��  �Z�:U���                        �OpenEdge/Core/Session.clsW     m��  �Z�:S��                        �'OpenEdge/Core/SessionClientTypeEnum.cls��     �}�  -Z�:U���                        �      �OpenEdge/Core/String.cls��     ���  C%Z�:Z̢�                        �OpenEdge/Core/StringArray.cls�&     ���  �Z�:W���                        � OpenEdge/Core/StringConstant.cls<�     Υ�  +Z�:X���                        �OpenEdge/Core/TimeStamp.cls��     ���  /NZ�:W��                        �OpenEdge/Core/WidgetHandle.clsUO     
�  
Z�:X�h"                        �'OpenEdge/Core/Assertion/AssertArray.cls�     2�  ?eZ�:X��k                        �                                    �'OpenEdge/Core/Assertion/AssertError.clsM     S��  'Z�:U���                        �&OpenEdge/Core/Assertion/AssertFile.clsN     [��  	Z�:W�3                        �&OpenEdge/Core/Assertion/AssertJson.cls�     d��  �Z�:U���                        �(OpenEdge/Core/Assertion/AssertObject.cls�     tE�  SOZ�:W�-                        �2OpenEdge/Core/Collections/AbstractTTCollection.cls��     ǔ�  '�Z�:Z2Æ                        �                                                             �#OpenEdge/Core/Collections/Array.cls	     ��  )oZ�:Z.�                        �+OpenEdge/Core/Collections/ArrayIterator.cls�,     �  Z�:S~³                        �+OpenEdge/Core/Collections/ClassClassMap.cls��      �  _Z�:U���                        �(OpenEdge/Core/Collections/Collection.cls�     "|�  	�Z�:S��                        �&OpenEdge/Core/Collections/EntrySet.cls��     ,r�  Z�:Z.�	                        �                                                                   �.OpenEdge/Core/Collections/EntrySetIterator.cls�+     @��  uZ�:S~                        �)OpenEdge/Core/Collections/ICollection.clsb     E��  �Z�:S~�|                        �'OpenEdge/Core/Collections/IIterable.cls,�     V��  �Z�:S~�q                        �'OpenEdge/Core/Collections/IIterator.cls~�     Y��  �Z�:S~�f                        �#OpenEdge/Core/Collections/IList.cls5     ^��  �Z�:S~�Y                        �                                                                  �+OpenEdge/Core/Collections/IListIterator.cls�#     q�  RZ�:S~�K                        �"OpenEdge/Core/Collections/IMap.cls��     vc�  �Z�:S~�?                        �'OpenEdge/Core/Collections/IMapEntry.clsf;     �1�  gZ�:S��                        �"OpenEdge/Core/Collections/ISet.cls3{     ���  	Z�:S~�                        �/OpenEdge/Core/Collections/IStringCollection.cls)b     ���  /Z�:S�	H                        �                                                                     �-OpenEdge/Core/Collections/IStringKeyedMap.cls��     ���  ]Z�:W#z�                        �.OpenEdge/Core/Collections/IStringStringMap.clsTx     �-�  SZ�:S�	G                        �&OpenEdge/Core/Collections/Iterator.cls��     ���   Z�:S��                        �$OpenEdge/Core/Collections/KeySet.cls��     ���  �Z�:S~�                        �(OpenEdge/Core/Collections/LinkedList.clsQP     ɂ�  7Z�:TW��                        �                                                             �"OpenEdge/Core/Collections/List.clsE|     ̹�  9fZ�:Z��B                        �*OpenEdge/Core/Collections/ListIterator.cls��     �  	4Z�:S��                        �&OpenEdge/Core/Collections/ListNode.cls1�     S�  ]Z�:TW��                        �!OpenEdge/Core/Collections/Map.cls�b     ��  7�Z�:Z̥�                        �1OpenEdge/Core/Collections/MapBackedCollection.cls��     J9�  mZ�:Z/�                        �                                                                      �&OpenEdge/Core/Collections/MapEntry.cls>�     Z��  �Z�:S��                        �)OpenEdge/Core/Collections/ObjectStack.cls��     bl�  �Z�:S��                        �)OpenEdge/Core/Collections/ResizeError.clsr"     h�  :Z�:S~��                        �!OpenEdge/Core/Collections/Set.clsچ     nO�  �Z�:Z�0;                        �#OpenEdge/Core/Collections/Stack.clsE�     5�  0�Z�:U���                        �                                                                              �0OpenEdge/Core/Collections/StackOverflowError.cls�     �%�  uZ�:S��                        �1OpenEdge/Core/Collections/StackUnderflowError.cls(�     ���  wZ�:S��                        �.OpenEdge/Core/Collections/StringCollection.cls��     ��  
�Z�:S�	A                        �,OpenEdge/Core/Collections/StringKeyedMap.cls�     ì�  �Z�:W#z�                        �-OpenEdge/Core/Collections/StringStringMap.cls(�     �o�  �Z�:U���                        �                                  �0OpenEdge/Core/Collections/typedcollectionclass.id�     �N�  GZ�:TW��                        �4OpenEdge/Core/Collections/typedcollectioninterface.iZ;     ��  Z�:S��                        �+OpenEdge/Core/Collections/typedlinkedlist.i\�     ��  �Z�:TW��                        �*OpenEdge/Core/Collections/typedlistclass.i'`     H�  �Z�:TW��                        �.OpenEdge/Core/Collections/typedlistinterface.i�      85�  �Z�:X�c�                        �                                   �)OpenEdge/Core/Collections/typedlistnode.iF�     O�  
.Z�:TW��                        �)OpenEdge/Core/Collections/typedmapclass.i�G     YM�  FZ�:W#�                        �-OpenEdge/Core/Collections/typedmapinterface.iV=     x��  �Z�:S��                        �)OpenEdge/Core/Collections/typedsetclass.i��     �U�  �Z�:U���                        �-OpenEdge/Core/Collections/typedsetinterface.iB�     �N�  Z�:S��                        �                                                     �-OpenEdge/Core/Collections/ValueCollection.cls�     �l�  �Z�:S~��                        �7OpenEdge/Core/ServerConnection/ConnectionParameters.cls@     �'�  ! Z�:U���                        �1OpenEdge/Core/ServerConnection/FormatMaskEnum.cls �     �G�  *Z�:U���                        �3OpenEdge/Core/ServerConnection/FormatMaskHelper.cls��     �q�  Z�:U���                        �8OpenEdge/Core/ServerConnection/IConnectionParameters.clsl     ��  	|Z�:U���                        �          �4OpenEdge/Core/ServerConnection/IServerConnection.cls(Z     �	�  Z�:S~��                        �:OpenEdge/Core/ServerConnection/UrlConnectionParameters.cls�v     ��  rZ�:S~��                        �7OpenEdge/Core/ServerConnection/WebServiceConnection.clsL�     ��  $Z�:X�h$                        �AOpenEdge/Core/ServerConnection/WebServiceConnectionParameters.cls�     ,��  /Z�:S~��                        �                                                                                     �)OpenEdge/Core/System/ApplicationError.cls��     B��  �Z�:Z�08                        �&OpenEdge/Core/System/ArgumentError.cls��     _��  iZ�:S��                        �*OpenEdge/Core/System/ErrorSeverityEnum.cls�     e<�  �Z�:U��u                        �)OpenEdge/Core/System/InvalidCallError.clsK     i �  �Z�:S��                        �3OpenEdge/Core/System/InvalidValueSpecifiedError.cls�#     m��  /Z�:S��                        �                                                     �(OpenEdge/Core/System/InvocationError.cls�     u�  �Z�:S��                        �&OpenEdge/Core/System/NotFoundError.cls�@     {��  �Z�:S��                        �2OpenEdge/Core/System/UnsupportedOperationError.cls�     ���  Z�:U��p                        �&OpenEdge/Core/Util/BuilderRegistry.cls     ���  !�Z�:Z�0<                        �$OpenEdge/Core/Util/ConfigBuilder.cls0�     ���  ?�Z�:Z*�c                        �                                                                �OpenEdge/Core/Util/MathUtil.cls/�     �o�  &Z�:Z(G�                        �$OpenEdge/Core/Util/TokenResolver.cls�H     ���  x,Z�:Z�2�                        �-OpenEdge/Core/Util/TokenResolverEventArgs.cls��     u��  Z�:ZoRX                        �OpenEdge/Core/XML/SaxReader.cls�     ���  .bZ�:X��V                        �#OpenEdge/Core/XML/saxreaderfacade.pٖ     �/�  IZ�:X��X                        �OpenEdge/Core/XML/SaxWriter.cls��     �x�  =�Z�:U��e                        �        �+OpenEdge/Core/XML/SaxWriterDataTypeEnum.cls��     	�  �Z�:U��a                        �(OpenEdge/Core/XML/SaxWriteStatusEnum.cls�?     	��  
Z�:U��i                        �,OpenEdge/Logging/ConfigFileLoggerBuilder.clsxW     	&�  [�Z�:Z_��                        �OpenEdge/Logging/ILogWriter.cls�o     	t��  )�Z�:XA��                        �$OpenEdge/Logging/ISupportLogging.cls?     	�w�  �Z�:X4��                        �                                                                        �OpenEdge/Logging/LogEvent.cls�]     	��  TZ�:Z_��                        �-OpenEdge/Logging/LogFilterBuilderRegistry.cls�P     	�l�  |Z�:X4��                        �OpenEdge/Logging/Logger.clsj�     	���  U#Z�:Y�j�                        �"OpenEdge/Logging/LoggerBuilder.cls-�     
�  /"Z�:Z�0=                        �)OpenEdge/Logging/LoggerFilterRegistry.cls�H     
H-�  BZ�:XA��                        �'OpenEdge/Logging/logging.config.example�G     
[o�  �Z�:X=�U                        �  �&OpenEdge/Logging/logging.config.schemaK�     
]H�  !Z�:Y�C�                        �!OpenEdge/Logging/LogLevelEnum.cls�y     
ji�  yZ�:X4��                        �OpenEdge/Logging/LogMessage.clsj�     
q��  2�Z�:XE��                        �"OpenEdge/Logging/TokenResolver.cls��     
���  �Z�:Zo{�                        �+OpenEdge/Logging/TokenResolverEventArgs.cls��     
�l�  	�Z�:Zo{�                        �OpenEdge/Logging/VoidLogger.cls)8     
���  -�Z�:XE��                        �       �)OpenEdge/Logging/Filter/ILoggerFilter.clso�     
��  �Z�:YH$                        �,OpenEdge/Logging/Filter/LogFilterBuilder.clsE/     
���  (�Z�:Z_��                        �,OpenEdge/Logging/Filter/LoggerFilterList.cls      7�  �Z�:XA��                        �,OpenEdge/Logging/Filter/LoggerFilterNode.cls�:     %��  7Z�:X4��                        �/OpenEdge/Logging/Format/ABLSubstituteFormat.cls�D     *&�  
XZ�:X���                        �                                              �'OpenEdge/Logging/Format/ErrorFormat.cls�m     4~�  <Z�:Zo{�                        �*OpenEdge/Logging/Format/FullTextFormat.cls�.     H��  	Z�:Z_��                        �.OpenEdge/Logging/Format/ISupportFormatting.clsK�     Q��  �Z�:X�ک                        �,OpenEdge/Logging/Format/LogManagerFormat.cls;     U��  _Z�:Y�j�                        �/OpenEdge/Logging/Format/ResolvedTokenFormat.cls�@     ]��  %Z�:Y�y�                        �                                                �-OpenEdge/Logging/Format/StackWriterFormat.cls��     w�  �Z�:Y�C�                        �0OpenEdge/Logging/Writer/FileLogWriterBuilder.cls��     ~��  Z�:YG�                        �'OpenEdge/Logging/Writer/IFileWriter.cls�     ���  KZ�:X4��                        �,OpenEdge/Logging/Writer/LogManagerWriter.cls�?     �:�  �Z�:Y�C�                        �2OpenEdge/Logging/Writer/MessageStatementWriter.clsx%     ��  �Z�:XA��                        �                                        �+OpenEdge/Logging/Writer/NamedFileWriter.cls��     ���  �Z�:Z_��                        �&OpenEdge/Logging/Writer/VoidWriter.cls56     �b�  �Z�:X4��                        �OpenEdge/Security/Principal.cls�U     �+�   Z�:X�h                        �                                                �                                                                                                                                                                                                           